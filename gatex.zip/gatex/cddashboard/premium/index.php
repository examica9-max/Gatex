<?php
// Start session with 1 year lifetime
session_start();
ini_set('session.gc_maxlifetime', 31536000); // 1 year
session_set_cookie_params(31536000);

require_once __DIR__ . '/admin/secret-manager.php';

$manager = new SecretManager();
$error = '';
$success = '';

$isPremium = isset($_SESSION['premium_access']) && $_SESSION['premium_access'] === true;

// Check if session has expired
if ($isPremium && isset($_SESSION['code_expiry'])) {
    $expiry = strtotime($_SESSION['code_expiry']);
    $today = strtotime(date('Y-m-d'));
    
    if ($today > $expiry) {
        session_destroy();
        session_start();
        $isPremium = false;
        $error = 'Your premium access has expired. Please purchase a new code.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['secret_code'])) {
    $secretCode = trim(strtoupper($_POST['secret_code']));
    
    if (!file_exists(__DIR__ . '/admin/secrets.xml')) {
        $error = 'System error: Database not found.';
    } else {
        try {
            if ($manager->verifySecret($secretCode)) {
                // Get code details including expiry
                $codeDetails = $manager->getSecretDetails($secretCode);
                
                // Store in session - will persist until expiry
                $_SESSION['premium_access'] = true;
                $_SESSION['secret_code'] = $secretCode;
                $_SESSION['activated_at'] = time();
                $_SESSION['code_expiry'] = $codeDetails['expiry'];
                $_SESSION['user_ip'] = $_SERVER['REMOTE_ADDR'];
                
                $expiryDate = date('M d, Y', strtotime($codeDetails['expiry']));
                $success = "Premium access activated! Valid until: $expiryDate";
                $isPremium = true;
                
                header("Refresh: 2; url=dashboard.php");
            } else {
                $error = 'Invalid, expired, or inactive secret code.';
            }
        } catch (Exception $e) {
            $error = 'System error: ' . $e->getMessage();
        }
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GATEX Premium - Computer Science</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); min-height: 100vh; color: #f8fafc; overflow-x: hidden; }
        .animated-bg { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; }
        .gradient-orb { position: absolute; border-radius: 50%; filter: blur(80px); opacity: 0.3; animation: float 20s ease-in-out infinite; }
        .orb1 { width: 500px; height: 500px; background: #6366f1; top: -100px; left: -100px; }
        .orb2 { width: 400px; height: 400px; background: #ec4899; bottom: -100px; right: -100px; animation-delay: -5s; }
        .orb3 { width: 350px; height: 350px; background: #8b5cf6; top: 50%; left: 50%; animation-delay: -10s; }
        @keyframes float { 0%, 100% { transform: translate(0, 0); } 33% { transform: translate(50px, -50px); } 66% { transform: translate(-50px, 50px); } }
        .container { position: relative; z-index: 1; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .card { background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(20px); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 30px; padding: 50px; max-width: 650px; width: 100%; box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3); animation: slideUp 0.6s ease; }
        @keyframes slideUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        .logo { text-align: center; margin-bottom: 30px; }
        .logo h1 { font-size: 48px; font-weight: 900; background: linear-gradient(135deg, #6366f1 0%, #ec4899 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 10px; }
        .logo p { font-size: 16px; color: #94a3b8; }
        .status-premium { background: linear-gradient(135deg, rgba(34, 197, 94, 0.2), rgba(16, 185, 129, 0.2)); border: 2px solid #22c55e; border-radius: 20px; padding: 30px; text-align: center; margin-bottom: 30px; }
        .status-premium .icon { font-size: 64px; margin-bottom: 15px; }
        .status-premium h2 { font-size: 28px; margin-bottom: 10px; color: #86efac; }
        .status-premium p { color: #d1fae5; margin-bottom: 20px; }
        .pricing-box { background: rgba(99, 102, 241, 0.1); border: 2px solid rgba(99, 102, 241, 0.3); border-radius: 20px; padding: 30px; margin-bottom: 30px; text-align: center; }
        .price { font-size: 64px; font-weight: 900; background: linear-gradient(135deg, #6366f1 0%, #ec4899 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 10px; }
        .price-label { font-size: 18px; color: #94a3b8; margin-bottom: 20px; }
        .features { background: rgba(255, 255, 255, 0.03); border-radius: 15px; padding: 25px; margin-bottom: 30px; }
        .features h3 { font-size: 20px; margin-bottom: 15px; color: #a78bfa; }
        .feature-list { list-style: none; }
        .feature-list li { padding: 10px 0; border-bottom: 1px solid rgba(255, 255, 255, 0.05); color: #cbd5e1; }
        .feature-list li:last-child { border-bottom: none; }
        .feature-list li::before { content: '✓'; color: #22c55e; font-weight: bold; margin-right: 10px; font-size: 18px; }
        .whatsapp-section { text-align: center; margin: 30px 0; }
        .whatsapp-section h3 { font-size: 22px; margin-bottom: 15px; color: #e0e7ff; }
        .whatsapp-section p { color: #94a3b8; margin-bottom: 25px; line-height: 1.6; }
        .whatsapp-btn { display: inline-flex; align-items: center; gap: 12px; padding: 18px 40px; background: linear-gradient(135deg, #25D366 0%, #128C7E 100%); color: white; text-decoration: none; border-radius: 15px; font-weight: 700; font-size: 18px; transition: all 0.3s; box-shadow: 0 10px 30px rgba(37, 211, 102, 0.3); }
        .whatsapp-btn:hover { transform: translateY(-3px); box-shadow: 0 15px 40px rgba(37, 211, 102, 0.4); }
        .whatsapp-icon { font-size: 28px; }
        .divider { display: flex; align-items: center; margin: 30px 0; color: #64748b; }
        .divider::before, .divider::after { content: ''; flex: 1; height: 1px; background: rgba(255, 255, 255, 0.1); }
        .divider span { padding: 0 15px; font-weight: 600; }
        .secret-form { margin-top: 20px; }
        .secret-form h3 { font-size: 20px; margin-bottom: 15px; text-align: center; color: #e0e7ff; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: 600; color: #cbd5e1; }
        input[type="text"] { width: 100%; padding: 15px 20px; background: rgba(255, 255, 255, 0.05); border: 2px solid rgba(255, 255, 255, 0.1); border-radius: 12px; color: white; font-size: 16px; font-family: 'Inter', sans-serif; font-weight: 600; text-align: center; letter-spacing: 2px; transition: all 0.3s; text-transform: uppercase; }
        input[type="text"]:focus { outline: none; border-color: #6366f1; box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1); }
        button[type="submit"] { width: 100%; padding: 15px; background: linear-gradient(135deg, #6366f1 0%, #ec4899 100%); color: white; border: none; border-radius: 12px; font-size: 16px; font-weight: 700; cursor: pointer; transition: all 0.3s; }
        button[type="submit"]:hover { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(99, 102, 241, 0.4); }
        .message { padding: 15px 20px; border-radius: 12px; margin-bottom: 20px; text-align: center; animation: slideDown 0.3s ease; }
        .message.error { background: rgba(239, 68, 68, 0.2); border: 2px solid #ef4444; color: #fca5a5; }
        .message.success { background: rgba(34, 197, 94, 0.2); border: 2px solid #22c55e; color: #86efac; }
        @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
        .access-btn { display: inline-block; padding: 15px 40px; background: linear-gradient(135deg, #6366f1 0%, #ec4899 100%); color: white; text-decoration: none; border-radius: 12px; font-weight: 700; font-size: 16px; transition: all 0.3s; margin: 10px; }
        .access-btn:hover { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(99, 102, 241, 0.4); }
        .logout-link { display: inline-block; margin-top: 15px; color: #94a3b8; text-decoration: none; font-size: 14px; }
        .logout-link:hover { color: #f87171; }
        @media (max-width: 768px) { .card { padding: 30px 20px; } .logo h1 { font-size: 36px; } .price { font-size: 48px; } .whatsapp-btn { padding: 15px 30px; font-size: 16px; } }
    </style>
</head>
<body>
    <div class="animated-bg">
        <div class="gradient-orb orb1"></div>
        <div class="gradient-orb orb2"></div>
        <div class="gradient-orb orb3"></div>
    </div>

    <div class="container">
        <div class="card">
            <div class="logo">
                <h1>🚀 GATEX Premium</h1>
                <p>Computer Science • GATE Preparation</p>
            </div>

            <?php if ($error): ?>
                <div class="message error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="message success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>

            <?php if ($isPremium): ?>
                <div class="status-premium">
                    <div class="icon">🎉</div>
                    <h2>Premium Activated!</h2>
                    <p>Welcome to unlimited GATE Computer Science preparation</p>
                    <a href="dashboard.php" class="access-btn">Access Dashboard →</a>
                    <br>
                    <a href="?logout" class="logout-link">Logout</a>
                </div>
            <?php else: ?>
                <div class="pricing-box">
                    <div class="price">₹ &nbsp;&nbsp; 99</div>
                    <div class="price-label">One-time • Lifetime Access</div>
                </div>

                <div class="features">
                    <h3>🌟 Premium Features</h3>
                    <ul class="feature-list">
                        <li>Unlimited AI Generated Questions</li>
                        <li>Unlimited AI Full Papers</li>
                        <li>Previous Year Papers (2022-2025)</li>
                        <li>Advanced Performance Analytics</li>
                        <li>Premium AI Study Notes</li>
                        <li>Priority AI Processing</li>
                        <li>Zero Interruptions</li>
                        <li>24/7 Access</li>
                    </ul>
                </div>

                <div class="whatsapp-section">
                    <h3>Get Premium Access</h3>
                    <p>Contact us on WhatsApp for payment details and your secret access code.</p>
                    <a href="https://wa.me/7011612892?text=Hi,%20I%20want%20to%20purchase%20GATEX%20Premium%20Computer%20Science%20for%20₹99" 
                       class="whatsapp-btn" 
                       target="_blank">
                        <span class="whatsapp-icon">💬</span>
                        Contact on WhatsApp
                    </a>
                </div>

                <div class="divider">
                    <span>Already Purchased?</span>
                </div>

                <div class="secret-form">
                    <h3>Enter Your Secret Code</h3>
                    <form method="POST">
                        <div class="form-group">
                            <label for="secret_code">Secret Code</label>
                            <input type="text" 
                                   id="secret_code" 
                                   name="secret_code" 
                                   placeholder="GATEX-XXXXXXXX" 
                                   required 
                                   autocomplete="off">
                        </div>
                        <button type="submit">Activate Premium Access</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
