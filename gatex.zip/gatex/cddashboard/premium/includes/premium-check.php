<?php
// Premium Access Protection
session_start();

function checkPremiumAccess() {
    if (!isset($_SESSION['premium_access']) || $_SESSION['premium_access'] !== true) {
        header('Location: ../index.php');
        exit;
    }
}

function isPremiumUser() {
    return isset($_SESSION['premium_access']) && $_SESSION['premium_access'] === true;
}

function getPremiumUserInfo() {
    if (isPremiumUser()) {
        return [
            'code' => $_SESSION['secret_code'] ?? '',
            'activated_at' => $_SESSION['activated_at'] ?? '',
            'session_id' => session_id()
        ];
    }
    return null;
}
?>
