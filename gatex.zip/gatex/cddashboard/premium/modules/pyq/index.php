<?php
/* === PERSISTENT SESSION PROTECTION === */

// Start session with 1 year lifetime
if (session_status() === PHP_SESSION_NONE) {
    ini_set("session.gc_maxlifetime", 31536000); // 1 year
    session_set_cookie_params(31536000);
    session_start();
}

// Check if user has premium access
if (!isset($_SESSION["premium_access"]) || $_SESSION["premium_access"] !== true) {
    header("Location: ../../index.php");
    exit;
}

// Validate code has not expired
if (isset($_SESSION["code_expiry"])) {
    $expiry = strtotime($_SESSION["code_expiry"]);
    $today = strtotime(date("Y-m-d"));
    
    if ($today > $expiry) {
        session_destroy();
        header("Location: ../../index.php?error=expired");
        exit;
    }
}

/* === END PERSISTENT SESSION PROTECTION === */
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GATE CS 2025 Dashboard | GATEX by Tech Eagles</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --secondary: #ec4899;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #3b82f6;
            --dark: #1e293b;
            --light: #f8fafc;
            --gray: #64748b;
            --border: #e2e8f0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            line-height: 1.6;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Header */
        .header {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(20px);
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.15);
            margin-bottom: 30px;
            animation: slideDown 0.6s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .logo-section {
            flex: 1;
        }

        .logo-section h1 {
            font-size: 36px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
            font-weight: 800;
        }

        .logo-section p {
            color: var(--gray);
            font-size: 15px;
        }

        .header-stats {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        .stat-card {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            padding: 20px 30px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 10px 25px rgba(99, 102, 241, 0.3);
            animation: fadeIn 0.8s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .stat-value {
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 14px;
            opacity: 0.9;
        }

        /* Welcome Banner */
        .welcome-banner {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.95), rgba(236, 72, 153, 0.95));
            color: white;
            padding: 40px;
            border-radius: 20px;
            margin-bottom: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.15);
            animation: slideUp 0.6s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .welcome-banner h2 {
            font-size: 32px;
            margin-bottom: 15px;
        }

        .welcome-banner p {
            font-size: 18px;
            opacity: 0.95;
            line-height: 1.8;
        }

        /* Section Title */
        .section-title {
            font-size: 28px;
            color: white;
            margin: 40px 0 20px 0;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .section-title::before {
            content: '';
            width: 6px;
            height: 40px;
            background: linear-gradient(180deg, var(--primary), var(--secondary));
            border-radius: 10px;
        }

        /* Papers Grid */
        .papers-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .paper-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            animation: cardFadeIn 0.8s ease backwards;
        }

        @keyframes cardFadeIn {
            from {
                opacity: 0;
                transform: scale(0.9);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .paper-card:nth-child(1) { animation-delay: 0.1s; }
        .paper-card:nth-child(2) { animation-delay: 0.2s; }
        .paper-card:nth-child(3) { animation-delay: 0.3s; }
        .paper-card:nth-child(4) { animation-delay: 0.4s; }

        .paper-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
        }

        .paper-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 60px rgba(0,0,0,0.2);
        }

        .paper-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 20px;
        }

        .paper-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            box-shadow: 0 8px 20px rgba(99, 102, 241, 0.3);
        }

        .paper-info h3 {
            font-size: 22px;
            color: var(--dark);
            margin-bottom: 5px;
        }

        .paper-info p {
            color: var(--gray);
            font-size: 14px;
        }

        .paper-status {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-top: 10px;
        }

        .status-new {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .status-in-progress {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning);
        }

        .status-completed {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info);
        }

        .paper-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin: 20px 0;
        }

        .paper-stat {
            text-align: center;
            padding: 15px;
            background: var(--light);
            border-radius: 12px;
        }

        .paper-stat-value {
            font-size: 24px;
            font-weight: bold;
            color: var(--primary);
            margin-bottom: 5px;
        }

        .paper-stat-label {
            font-size: 12px;
            color: var(--gray);
        }

        .paper-progress {
            margin: 20px 0;
        }

        .progress-label {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 14px;
            color: var(--gray);
        }

        .progress-bar {
            height: 8px;
            background: var(--border);
            border-radius: 10px;
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            border-radius: 10px;
            transition: width 0.6s ease;
        }

        .paper-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }

        .btn {
            flex: 1;
            padding: 14px 20px;
            border: none;
            border-radius: 12px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            box-shadow: 0 5px 15px rgba(99, 102, 241, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(99, 102, 241, 0.4);
        }

        .btn-secondary {
            background: var(--light);
            color: var(--dark);
            border: 2px solid var(--border);
        }

        .btn-secondary:hover {
            background: var(--border);
            transform: translateY(-2px);
        }

        /* Performance Section */
        .performance-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .performance-card {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            animation: cardFadeIn 0.8s ease backwards;
        }

        .performance-card h3 {
            font-size: 20px;
            color: var(--dark);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .chart-container {
            height: 250px;
            position: relative;
        }

        /* Quick Stats */
        .quick-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .quick-stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            text-align: center;
            transition: all 0.3s;
            animation: cardFadeIn 0.6s ease backwards;
        }

        .quick-stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
        }

        .quick-stat-icon {
            width: 60px;
            height: 60px;
            margin: 0 auto 15px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            box-shadow: 0 8px 20px rgba(99, 102, 241, 0.3);
        }

        .quick-stat-value {
            font-size: 36px;
            font-weight: bold;
            color: var(--primary);
            margin-bottom: 5px;
        }

        .quick-stat-label {
            color: var(--gray);
            font-size: 14px;
        }

        /* Tips Section */
        .tips-section {
            background: rgba(255, 255, 255, 0.98);
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            margin-bottom: 40px;
        }

        .tips-section h3 {
            font-size: 24px;
            color: var(--dark);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .tips-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .tip-card {
            padding: 20px;
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.05), rgba(236, 72, 153, 0.05));
            border-radius: 12px;
            border-left: 4px solid var(--primary);
        }

        .tip-card h4 {
            color: var(--primary);
            margin-bottom: 10px;
            font-size: 16px;
        }

        .tip-card p {
            color: var(--gray);
            font-size: 14px;
            line-height: 1.6;
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 30px;
            color: white;
            margin-top: 40px;
        }

        .footer-content {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 20px;
        }

        .footer a {
            color: white;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        .social-links {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
        }

        .social-icon {
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .social-icon:hover {
            background: white;
            transform: scale(1.1);
        }

        /* Leaderboard */
        .leaderboard {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            margin-bottom: 40px;
        }

        .leaderboard h3 {
            font-size: 24px;
            color: var(--dark);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .leaderboard-item {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid var(--border);
            transition: all 0.3s;
        }

        .leaderboard-item:hover {
            background: var(--light);
        }

        .rank {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-right: 15px;
        }

        .leaderboard-info {
            flex: 1;
        }

        .leaderboard-name {
            font-weight: 600;
            color: var(--dark);
        }

        .leaderboard-score {
            color: var(--primary);
            font-weight: bold;
            font-size: 18px;
        }

        /* Responsive */
        @media (max-width: 968px) {
            .header-content {
                flex-direction: column;
                text-align: center;
            }

            .papers-grid {
                grid-template-columns: 1fr;
            }

            .logo-section h1 {
                font-size: 28px;
            }

            .welcome-banner {
                padding: 25px;
            }

            .welcome-banner h2 {
                font-size: 24px;
            }
        }

        @media (max-width: 640px) {
            body {
                padding: 10px;
            }

            .header {
                padding: 20px;
            }

            .paper-stats {
                grid-template-columns: 1fr;
            }

            .quick-stats {
                grid-template-columns: repeat(2, 1fr);
            }

            .tips-grid {
                grid-template-columns: 1fr;
            }
        }

        /* Animations */
        @keyframes pulse {
            0%, 100% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
            }
        }

        .pulse-animation {
            animation: pulse 2s infinite;
        }

        /* Loading States */
        .skeleton {
            background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
            background-size: 200% 100%;
            animation: loading 1.5s infinite;
        }

        @keyframes loading {
            0% {
                background-position: 200% 0;
            }
            100% {
                background-position: -200% 0;
            }
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            padding: 40px;
            border-radius: 20px;
            max-width: 600px;
            width: 100%;
            animation: modalSlide 0.3s ease;
        }

        @keyframes modalSlide {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .modal-header h3 {
            font-size: 24px;
            color: var(--dark);
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 28px;
            cursor: pointer;
            color: var(--gray);
            transition: all 0.3s;
        }

        .close-btn:hover {
            color: var(--danger);
            transform: rotate(90deg);
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>🎓 GATE CS 2025 Dashboard</h1>
                    <p>© 2025 GATEX | Product of Tech Eagles under Mahakumbrix Innovation | Powered By Rocket Examica</p>
                </div>
                <div class="header-stats">
                    <div class="stat-card">
                        <div class="stat-value" id="totalAttempts">0</div>
                        <div class="stat-label">Total Attempts</div>
                    </div>
                    <div class="stat-card" style="background: linear-gradient(135deg, #10b981, #059669);">
                        <div class="stat-value" id="avgScore">0%</div>
                        <div class="stat-label">Avg Score</div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Welcome Banner -->
        <div class="welcome-banner">
            <h2>👋 Welcome to GATE CS 2025 Practice Platform!</h2>
            <p>Master your preparation with our comprehensive collection of GATE CS papers. Practice, analyze, and improve your performance with detailed insights and personalized recommendations.</p>
        </div>

        <!-- Quick Stats -->
        <div class="quick-stats">
            <div class="quick-stat-card" style="animation-delay: 0.1s;">
                <div class="quick-stat-icon">📝</div>
                <div class="quick-stat-value" id="totalQuestions">260</div>
                <div class="quick-stat-label">Total Questions</div>
            </div>
            <div class="quick-stat-card" style="animation-delay: 0.2s;">
                <div class="quick-stat-icon">✅</div>
                <div class="quick-stat-value" id="questionsAttempted">0</div>
                <div class="quick-stat-label">Questions Attempted</div>
            </div>
            <div class="quick-stat-card" style="animation-delay: 0.3s;">
                <div class="quick-stat-icon">⏱️</div>
                <div class="quick-stat-value" id="timeSpent">0h</div>
                <div class="quick-stat-label">Time Spent</div>
            </div>
            <div class="quick-stat-card" style="animation-delay: 0.4s;">
                <div class="quick-stat-icon">🎯</div>
                <div class="quick-stat-value" id="accuracy">0%</div>
                <div class="quick-stat-label">Overall Accuracy</div>
            </div>
        </div>

        <!-- Papers Section -->
        <h2 class="section-title">📚 Previous Year Papers</h2>
        <div class="papers-grid">
            <!-- GATE CS 2025 -->
            <div class="paper-card">
                <div class="paper-header">
                    <div class="paper-icon">🎓</div>
                    <div class="paper-info">
                        <h3>GATE CS 2025</h3>
                        <p>IIT Roorkee</p>
                        <span class="paper-status status-new">Latest</span>
                    </div>
                </div>
                <div class="paper-stats">
                    <div class="paper-stat">
                        <div class="paper-stat-value">65</div>
                        <div class="paper-stat-label">Questions</div>
                    </div>
                    <div class="paper-stat">
                        <div class="paper-stat-value">100</div>
                        <div class="paper-stat-label">Marks</div>
                    </div>
                    <div class="paper-stat">
                        <div class="paper-stat-value">180</div>
                        <div class="paper-stat-label">Minutes</div>
                    </div>
                </div>
                <div class="paper-progress">
                    <div class="progress-label">
                        <span>Progress</span>
                        <span id="progress-2025">0%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" id="progress-bar-2025" style="width: 0%"></div>
                    </div>
                </div>
                <div class="paper-actions">
                    <button class="btn btn-primary" onclick="startPaper('gate-cs-2025-exam.php')">
                        🚀 Start Paper
                    </button>
                    <button class="btn btn-secondary" onclick="showDetails(2025)">
                        📊 Details
                    </button>
                </div>
            </div>

            <!-- GATE CS 2024 -->
            <div class="paper-card">
                <div class="paper-header">
                    <div class="paper-icon" style="background: linear-gradient(135deg, #ec4899, #be185d);">🎓</div>
                    <div class="paper-info">
                        <h3>GATE CS 2024</h3>
                        <p>IIT Kharagpur</p>
                    <!-- <span class="paper-status status-new">Coming Soon</span> -->

                    </div>
                </div>
                <div class="paper-stats">
                    <div class="paper-stat">
                        <div class="paper-stat-value">65</div>
                        <div class="paper-stat-label">Questions</div>
                    </div>
                    <div class="paper-stat">
                        <div class="paper-stat-value">100</div>
                        <div class="paper-stat-label">Marks</div>
                    </div>
                    <div class="paper-stat">
                        <div class="paper-stat-value">180</div>
                        <div class="paper-stat-label">Minutes</div>
                    </div>
                </div>
                <div class="paper-progress">
                    <div class="progress-label">
                        <span>Progress</span>
                        <span>0%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: 0%"></div>
                    </div>
                </div>
                <div class="paper-actions">
                    <button class="btn btn-primary" onclick="startPaper('gate-cs-2024-exam.php')">
                        🚀 Start Paper
                    </button>
                    <button class="btn btn-secondary" onclick="showDetails(2024)">
                        📊 Details
                    </button>
                </div>
            </div>

            <!-- GATE CS 2023 -->
            <div class="paper-card">
                <div class="paper-header">
                    <div class="paper-icon" style="background: linear-gradient(135deg, #10b981, #059669);">🎓</div>
                    <div class="paper-info">
                        <h3>GATE CS 2023</h3>
                        <p>IIT Kanpur</p>
                       
                    </div>
                </div>
                <div class="paper-stats">
                    <div class="paper-stat">
                        <div class="paper-stat-value">65</div>
                        <div class="paper-stat-label">Questions</div>
                    </div>
                    <div class="paper-stat">
                        <div class="paper-stat-value">100</div>
                        <div class="paper-stat-label">Marks</div>
                    </div>
                    <div class="paper-stat">
                        <div class="paper-stat-value">180</div>
                        <div class="paper-stat-label">Minutes</div>
                    </div>
                </div>
                <div class="paper-progress">
                    <div class="progress-label">
                        <span>Progress</span>
                        <span>0%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: 0%"></div>
                    </div>
                </div>
                <div class="paper-actions">
                    <button class="btn btn-primary" onclick="startPaper('gate-cs-2023-exam.php')">
                        🚀 Start Paper
                    </button>
                    <button class="btn btn-secondary" onclick="showDetails(2023)">
                        📊 Details
                    </button>
                </div>
            </div>

            <!-- GATE CS 2022 -->
            <div class="paper-card">
                <div class="paper-header">
                    <div class="paper-icon" style="background: linear-gradient(135deg, #f59e0b, #d97706);">🎓</div>
                    <div class="paper-info">
                        <h3>GATE CS 2022</h3>
                        <p>IIT Bombay</p>
                       
                    </div>
                </div>
                <div class="paper-stats">
                    <div class="paper-stat">
                        <div class="paper-stat-value">65</div>
                        <div class="paper-stat-label">Questions</div>
                    </div>
                    <div class="paper-stat">
                        <div class="paper-stat-value">100</div>
                        <div class="paper-stat-label">Marks</div>
                    </div>
                    <div class="paper-stat">
                        <div class="paper-stat-value">180</div>
                        <div class="paper-stat-label">Minutes</div>
                    </div>
                </div>
                <div class="paper-progress">
                    <div class="progress-label">
                        <span>Progress</span>
                        <span>0%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: 0%"></div>
                    </div>
                </div>
                <div class="paper-actions">
                    <button class="btn btn-primary" onclick="startPaper('gate-cs-2022-exam.php')">
                        🚀 Start Paper
                    </button>
                    <button class="btn btn-secondary" onclick="showDetails(2022)">
                        📊 Details
                    </button>
                </div>
            </div>
        </div>

        <!-- Performance Section -->
        <h2 class="section-title">📈 Performance Analytics</h2>
        <div class="performance-section">
            <div class="performance-card">
                <h3>📊 Score Trends</h3>
                <div class="chart-container">
                    <canvas id="scoreChart"></canvas>
                </div>
            </div>
            <div class="performance-card">
                <h3>🎯 Section-wise Performance</h3>
                <div class="chart-container">
                    <canvas id="sectionChart"></canvas>
                </div>
            </div>
            <div class="performance-card">
                <h3>⏱️ Time Management</h3>
                <div class="chart-container">
                    <canvas id="timeChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Tips Section -->
        <div class="tips-section">
            <h3>💡 Preparation Tips</h3>
            <div class="tips-grid">
                <div class="tip-card">
                    <h4>🎯 Focus on Weak Areas</h4>
                    <p>Identify your weak subjects and allocate more time to practice them. Use our analytics to track improvement.</p>
                </div>
                <div class="tip-card">
                    <h4>⏰ Time Management</h4>
                    <p>Practice completing papers within the 3-hour time limit. This helps you manage time effectively in the actual exam.</p>
                </div>
                <div class="tip-card">
                    <h4>📝 Regular Practice</h4>
                    <p>Solve at least one full paper every week. Consistency is key to maintaining and improving your performance.</p>
                </div>
                <div class="tip-card">
                    <h4>🔄 Review Mistakes</h4>
                    <p>Always review your incorrect answers. Understanding mistakes helps prevent them in future attempts.</p>
                </div>
            </div>
        </div>

        <!-- Leaderboard -->
        <div class="leaderboard">
            <h3>🏆 Your Best Scores</h3>
            <div class="leaderboard-item">
                <div class="rank" style="background: linear-gradient(135deg, #fbbf24, #f59e0b);">1</div>
                <div class="leaderboard-info">
                    <div class="leaderboard-name">GATE CS 2025</div>
                    <div style="color: var(--gray); font-size: 14px;">IIT Roorkee</div>
                </div>
                <div class="leaderboard-score">--/100</div>
            </div>
            <div class="leaderboard-item">
                <div class="rank">2</div>
                <div class="leaderboard-info">
                    <div class="leaderboard-name">GATE CS 2024</div>
                    <div style="color: var(--gray); font-size: 14px;">IIT Kharagpur</div>
                </div>
                <div class="leaderboard-score">--/100</div>
            </div>
            <div class="leaderboard-item">
                <div class="rank">3</div>
                <div class="leaderboard-info">
                    <div class="leaderboard-name">GATE CS 2023</div>
                    <div style="color: var(--gray); font-size: 14px;">IIT Kanpur</div>
                </div>
                <div class="leaderboard-score">--/100</div>
            </div>
            <div class="leaderboard-item">
                <div class="rank">4</div>
                <div class="leaderboard-info">
                    <div class="leaderboard-name">GATE CS 2022</div>
                    <div style="color: var(--gray); font-size: 14px;">IIT Bombay</div>
                </div>
                <div class="leaderboard-score">--/100</div>
            </div>
        </div>

        <!-- Footer -->
        <footer class="footer">
            <div class="footer-content">
                <p style="font-size: 18px; margin-bottom: 15px;">🎓 <strong>GATEX</strong> - Your Gateway to GATE Success</p>
                <p>© 2025 GATEX | Product of <a href="#">Tech Eagles</a> under <a href="#">Mahakumbrix Innovation</a></p>
                <p style="margin-top: 10px;">Powered By <a href="#">Rocket Examica</a> | All Rights Reserved</p>
                <div class="social-links">
                    <div class="social-icon">📘</div>
                    <div class="social-icon">🐦</div>
                    <div class="social-icon">📷</div>
                    <div class="social-icon">💼</div>
                </div>
            </div>
            <p style="margin-top: 20px; opacity: 0.8;">Made with ❤️ for GATE Aspirants</p>
        </footer>
    </div>

    <!-- Details Modal -->
    <div class="modal" id="detailsModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>📊 Paper Details</h3>
                <button class="close-btn" onclick="closeModal()">&times;</button>
            </div>
            <div id="modalBody">
                <!-- Content will be dynamically added -->
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Initialize charts
        document.addEventListener('DOMContentLoaded', function() {
            initializeCharts();
            loadStats();
        });

        function initializeCharts() {
            // Score Trends Chart
            const scoreCtx = document.getElementById('scoreChart').getContext('2d');
            new Chart(scoreCtx, {
                type: 'line',
                data: {
                    labels: ['2022', '2023', '2024', '2025'],
                    datasets: [{
                        label: 'Score',
                        data: [0, 0, 0, 0],
                        borderColor: '#6366f1',
                        backgroundColor: 'rgba(99, 102, 241, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 100
                        }
                    }
                }
            });

            // Section-wise Performance
            const sectionCtx = document.getElementById('sectionChart').getContext('2d');
            new Chart(sectionCtx, {
                type: 'doughnut',
                data: {
                    labels: ['General Aptitude', 'Technical'],
                    datasets: [{
                        data: [0, 0],
                        backgroundColor: [
                            'rgba(99, 102, 241, 0.8)',
                            'rgba(236, 72, 153, 0.8)'
                        ],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });

            // Time Management
            const timeCtx = document.getElementById('timeChart').getContext('2d');
            new Chart(timeCtx, {
                type: 'bar',
                data: {
                    labels: ['2022', '2023', '2024', '2025'],
                    datasets: [{
                        label: 'Time (minutes)',
                        data: [0, 0, 0, 0],
                        backgroundColor: 'rgba(16, 185, 129, 0.8)',
                        borderRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 180
                        }
                    }
                }
            });
        }

        function loadStats() {
            // Load stats from localStorage
            const stats = JSON.parse(localStorage.getItem('gateStats')) || {
                totalAttempts: 0,
                avgScore: 0,
                questionsAttempted: 0,
                timeSpent: 0,
                accuracy: 0
            };

            document.getElementById('totalAttempts').textContent = stats.totalAttempts;
            document.getElementById('avgScore').textContent = stats.avgScore + '%';
            document.getElementById('questionsAttempted').textContent = stats.questionsAttempted;
            document.getElementById('timeSpent').textContent = stats.timeSpent + 'h';
            document.getElementById('accuracy').textContent = stats.accuracy + '%';
        }

        function startPaper(filename) {
            window.location.href = filename;
        }

        function comingSoon() {
            alert('🚀 This paper is coming soon! Stay tuned for updates.\n\nComplete the available papers and check back later for more practice materials.');
        }

        function showDetails(paperId) {
            const paperDetails = {
                2025: {
                    title: 'GATE CS 2025',
                    subtitle: 'IIT Roorkee',
                    description: 'Latest GATE Computer Science paper with 65 questions covering General Aptitude and Technical sections.',
                    details: [
                        '📝 Total Questions: 65',
                        '📊 Total Marks: 100',
                        '⏱️ Duration: 180 minutes',
                        '✅ General Aptitude: 10 questions (15 marks)',
                        '💻 Technical Section: 55 questions (85 marks)',
                        '📈 Difficulty: Medium to Hard',
                        '🎯 Topics: All CS subjects covered',
                        '🏛️ Conducting Institute: IIT Roorkee',
                        '📅 Year: 2025'
                    ]
                },
                2024: {
                    title: 'GATE CS 2024',
                    subtitle: 'IIT Kharagpur',
                    description: 'GATE Computer Science 2024 paper - comprehensive practice material coming soon!',
                    details: [
                        '📝 Total Questions: 65',
                        '📊 Total Marks: 100',
                        '⏱️ Duration: 180 minutes',
                        '🔜 Status: Coming Soon',
                        '💡 Similar pattern to 2025',
                        '🎯 Full coverage of syllabus',
                        '🏛️ Conducting Institute: IIT Kharagpur',
                        '📅 Year: 2024'
                    ]
                },
                2023: {
                    title: 'GATE CS 2023',
                    subtitle: 'IIT Kanpur',
                    description: 'GATE Computer Science 2023 paper - excellent practice material coming soon!',
                    details: [
                        '📝 Total Questions: 65',
                        '📊 Total Marks: 100',
                        '⏱️ Duration: 180 minutes',
                        '🔜 Status: Coming Soon',
                        '📚 Comprehensive coverage',
                        '🎯 High-quality questions',
                        '🏛️ Conducting Institute: IIT Kanpur',
                        '📅 Year: 2023'
                    ]
                },
                2022: {
                    title: 'GATE CS 2022',
                    subtitle: 'IIT Bombay',
                    description: 'GATE Computer Science 2022 paper - valuable practice resource coming soon!',
                    details: [
                        '📝 Total Questions: 65',
                        '📊 Total Marks: 100',
                        '⏱️ Duration: 180 minutes',
                        '🔜 Status: Coming Soon',
                        '🎓 Expert level questions',
                        '🎯 Essential preparation material',
                        '🏛️ Conducting Institute: IIT Bombay',
                        '📅 Year: 2022'
                    ]
                }
            };

            const paper = paperDetails[paperId];
            const modalBody = document.getElementById('modalBody');
            
            modalBody.innerHTML = `
                <h4 style="color: var(--primary); margin-bottom: 10px;">${paper.title}</h4>
                <p style="color: var(--gray); margin-bottom: 20px;">${paper.subtitle}</p>
                <p style="margin-bottom: 20px; line-height: 1.8;">${paper.description}</p>
                <div style="background: var(--light); padding: 20px; border-radius: 12px;">
                    ${paper.details.map(detail => `
                        <p style="margin-bottom: 10px; color: var(--dark);">${detail}</p>
                    `).join('')}
                </div>
            `;

            document.getElementById('detailsModal').classList.add('active');
        }

        function closeModal() {
            document.getElementById('detailsModal').classList.remove('active');
        }

        // Close modal on outside click
        window.onclick = function(event) {
            const modal = document.getElementById('detailsModal');
            if (event.target === modal) {
                closeModal();
            }
        }

        // Update stats periodically (example)
        function updateStats() {
            // This would be called after completing a paper
            const stats = {
                totalAttempts: 1,
                avgScore: 75,
                questionsAttempted: 65,
                timeSpent: 3,
                accuracy: 85
            };
            localStorage.setItem('gateStats', JSON.stringify(stats));
            loadStats();
        }
    </script>
</body>
</html>
