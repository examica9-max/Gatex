<?php
/* === PERSISTENT SESSION PROTECTION === */

// Start session with 1 year lifetime
if (session_status() === PHP_SESSION_NONE) {
    ini_set("session.gc_maxlifetime", 31536000); // 1 year
    session_set_cookie_params(31536000);
    session_start();
}

// Check if user has premium access
if (!isset($_SESSION["premium_access"]) || $_SESSION["premium_access"] !== true) {
    header("Location: ../../index.php");
    exit;
}

// Validate code has not expired
if (isset($_SESSION["code_expiry"])) {
    $expiry = strtotime($_SESSION["code_expiry"]);
    $today = strtotime(date("Y-m-d"));
    
    if ($today > $expiry) {
        session_destroy();
        header("Location: ../../index.php?error=expired");
        exit;
    }
}

/* === END PERSISTENT SESSION PROTECTION === */
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GATE CS 2025 - Set 1 Online Exam | GATEX by Tech Eagles</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --secondary: #ec4899;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --dark: #1e293b;
            --light: #f8fafc;
            --gray: #64748b;
            --border: #e2e8f0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Header Styles */
        .header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .logo-section h1 {
            font-size: 28px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 5px;
        }

        .logo-section p {
            color: var(--gray);
            font-size: 14px;
        }

        .timer {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            padding: 15px 25px;
            border-radius: 10px;
            font-size: 24px;
            font-weight: bold;
            box-shadow: 0 5px 15px rgba(99, 102, 241, 0.3);
        }

        /* Navigation */
        .nav-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .nav-tab {
            background: white;
            border: none;
            padding: 12px 24px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s;
            color: var(--gray);
        }

        .nav-tab.active {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            box-shadow: 0 5px 15px rgba(99, 102, 241, 0.3);
        }

        /* Main Content */
        .main-content {
            display: grid;
            grid-template-columns: 1fr 300px;
            gap: 20px;
        }

        .exam-section {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .question-card {
            margin-bottom: 30px;
            padding: 25px;
            border: 2px solid var(--border);
            border-radius: 12px;
            display: none;
        }

        .question-card.active {
            display: block;
            animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 10px;
        }

        .question-number {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 8px 16px;
            border-radius: 8px;
            font-weight: bold;
        }

        .marks-badge {
            background: var(--success);
            color: white;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 14px;
        }

        .question-text {
            font-size: 18px;
            line-height: 1.8;
            margin-bottom: 25px;
            color: var(--dark);
        }

        .options {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .option {
            background: var(--light);
            padding: 15px 20px;
            border: 2px solid var(--border);
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .option:hover {
            border-color: var(--primary);
            background: rgba(99, 102, 241, 0.05);
            transform: translateX(5px);
        }

        .option.selected {
            border-color: var(--primary);
            background: rgba(99, 102, 241, 0.1);
        }

        .option.correct {
            border-color: var(--success);
            background: rgba(16, 185, 129, 0.1);
        }

        .option.wrong {
            border-color: var(--danger);
            background: rgba(239, 68, 68, 0.1);
        }

        .option-radio {
            width: 20px;
            height: 20px;
            min-width: 20px;
            border: 2px solid var(--gray);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .option.selected .option-radio {
            border-color: var(--primary);
        }

        .option.selected .option-radio::after {
            content: '';
            width: 10px;
            height: 10px;
            background: var(--primary);
            border-radius: 50%;
        }

        .numerical-input {
            width: 100%;
            padding: 15px;
            border: 2px solid var(--border);
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s;
        }

        .numerical-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
        }

        /* Sidebar */
        .sidebar {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .sidebar-card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .sidebar-card h3 {
            margin-bottom: 15px;
            color: var(--dark);
            font-size: 18px;
        }

        .progress-bar {
            height: 10px;
            background: var(--border);
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 10px;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            border-radius: 10px;
            transition: width 0.3s;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-top: 15px;
        }

        .stat-item {
            background: var(--light);
            padding: 12px;
            border-radius: 8px;
            text-align: center;
        }

        .stat-value {
            font-size: 24px;
            font-weight: bold;
            color: var(--primary);
        }

        .stat-label {
            font-size: 12px;
            color: var(--gray);
            margin-top: 5px;
        }

        .question-palette {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 8px;
        }

        .palette-btn {
            padding: 10px;
            border: 2px solid var(--border);
            background: white;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s;
        }

        .palette-btn:hover {
            transform: scale(1.1);
        }

        .palette-btn.answered {
            background: var(--success);
            color: white;
            border-color: var(--success);
        }

        .palette-btn.marked {
            background: var(--warning);
            color: white;
            border-color: var(--warning);
        }

        .palette-btn.current {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 25px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
        }

        .btn-secondary {
            background: var(--light);
            color: var(--dark);
            border: 2px solid var(--border);
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-warning {
            background: var(--warning);
            color: white;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        /* Results Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            padding: 40px;
            border-radius: 20px;
            max-width: 600px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalSlide 0.3s ease;
        }

        @keyframes modalSlide {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .results-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .results-header h2 {
            font-size: 32px;
            color: var(--dark);
            margin-bottom: 10px;
        }

        .score-circle {
            width: 200px;
            height: 200px;
            margin: 30px auto;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            color: white;
            box-shadow: 0 10px 40px rgba(99, 102, 241, 0.3);
        }

        .score-circle .score {
            font-size: 48px;
            font-weight: bold;
        }

        .score-circle .total {
            font-size: 20px;
            opacity: 0.9;
        }

        .results-details {
            display: grid;
            gap: 15px;
            margin-top: 30px;
        }

        .result-item {
            display: flex;
            justify-content: space-between;
            padding: 15px;
            background: var(--light);
            border-radius: 10px;
        }

        .chart-container {
            margin-top: 30px;
            padding: 20px;
            background: var(--light);
            border-radius: 10px;
        }

        /* Footer */
        .footer {
            text-align: center;
            margin-top: 30px;
            padding: 20px;
            color: white;
            font-size: 14px;
        }

        .footer a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        /* Responsive */
        @media (max-width: 968px) {
            .main-content {
                grid-template-columns: 1fr;
            }

            .header-content {
                flex-direction: column;
                text-align: center;
            }

            .question-palette {
                grid-template-columns: repeat(4, 1fr);
            }
        }

        @media (max-width: 640px) {
            .container {
                padding: 10px;
            }

            .exam-section {
                padding: 20px;
            }

            .logo-section h1 {
                font-size: 22px;
            }

            .timer {
                font-size: 20px;
                padding: 12px 20px;
            }

            .question-palette {
                grid-template-columns: repeat(3, 1fr);
            }

            .action-buttons {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }
        }

        /* Loading Animation */
        .loading {
            text-align: center;
            padding: 40px;
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 4px solid var(--border);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Instructions Panel */
        .instructions {
            background: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 20px;
        }

        .instructions h2 {
            color: var(--dark);
            margin-bottom: 20px;
        }

        .instructions ul {
            list-style-position: inside;
            color: var(--gray);
            line-height: 2;
        }

        .instructions li {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="header-content">
                <div class="logo-section">
                    <h1>🎓 GATE CS 2025 - Set 1</h1>
                    <p>© 2025 GATEX | Product of Tech Eagles under Mahakumbrix Innovation | Powered By Rocket Examica</p>
                </div>
                <div class="timer" id="timer">
                    ⏱️ <span id="timeDisplay">03:00:00</span>
                </div>
            </div>
        </div>

        <!-- Instructions (shown initially) -->
        <div class="instructions" id="instructions">
            <h2>📋 Exam Instructions</h2>
            <ul>
                <li>Total Questions: 65 (10 General Aptitude + 55 Technical)</li>
                <li>Total Marks: 100 (General Aptitude: 15 marks, Technical: 85 marks)</li>
                <li>Duration: 3 hours (180 minutes)</li>
                <li>Questions with 1 mark each: Q1-Q5, Q11-Q35</li>
                <li>Questions with 2 marks each: Q6-Q10, Q36-Q65</li>
                <li>Multiple Choice Questions (MCQ) and Numerical Answer Type (NAT) questions</li>
                <li>No negative marking for NAT questions</li>
                <li>Negative marking for MCQ: 1/3 mark deduction for 1-mark questions, 2/3 mark deduction for 2-mark questions</li>
                <li>You can navigate between questions using the question palette</li>
                <li>Mark questions for review if needed</li>
                <li>Submit your exam when you're done</li>
            </ul>
            <div class="action-buttons">
                <button class="btn btn-primary" onclick="startExam()">
                    🚀 Start Exam
                </button>
            </div>
        </div>

        <!-- Main Content (hidden initially) -->
        <div id="examContent" style="display: none;">
            <!-- Navigation Tabs -->
            <div class="nav-tabs">
                <button class="nav-tab active" onclick="filterQuestions('all')">All Questions</button>
                <button class="nav-tab" onclick="filterQuestions('ga')">General Aptitude (15)</button>
                <button class="nav-tab" onclick="filterQuestions('technical')">Technical (85)</button>
                <button class="nav-tab" onclick="filterQuestions('answered')">Answered</button>
                <button class="nav-tab" onclick="filterQuestions('unanswered')">Unanswered</button>
                <button class="nav-tab" onclick="filterQuestions('marked')">Marked for Review</button>
            </div>

            <div class="main-content">
                <!-- Exam Section -->
                <div class="exam-section">
                    <div id="questionsContainer">
                        <!-- Questions will be loaded here by JavaScript -->
                    </div>

                    <!-- Action Buttons -->
                    <div class="action-buttons">
                        <button class="btn btn-secondary" onclick="previousQuestion()">
                            ⬅️ Previous
                        </button>
                        <button class="btn btn-warning" onclick="markForReview()">
                            🔖 Mark for Review
                        </button>
                        <button class="btn btn-secondary" onclick="clearResponse()">
                            ❌ Clear Response
                        </button>
                        <button class="btn btn-primary" onclick="nextQuestion()">
                            Next ➡️
                        </button>
                        <button class="btn btn-success" onclick="submitExam()">
                            ✅ Submit Exam
                        </button>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="sidebar">
                    <!-- Progress Card -->
                    <div class="sidebar-card">
                        <h3>📊 Progress</h3>
                        <div class="progress-bar">
                            <div class="progress-fill" id="progressBar"></div>
                        </div>
                        <p id="progressText">0 of 65 answered</p>
                        
                        <div class="stats">
                            <div class="stat-item">
                                <div class="stat-value" id="answeredCount">0</div>
                                <div class="stat-label">Answered</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value" id="markedCount">0</div>
                                <div class="stat-label">Marked</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value" id="visitedCount">0</div>
                                <div class="stat-label">Visited</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value" id="notVisitedCount">65</div>
                                <div class="stat-label">Not Visited</div>
                            </div>
                        </div>
                    </div>

                    <!-- Question Palette -->
                    <div class="sidebar-card">
                        <h3>🎯 Question Palette</h3>
                        <div class="question-palette" id="questionPalette">
                            <!-- Palette buttons will be generated by JavaScript -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>© 2025 GATEX - Product of <a href="#">Tech Eagles</a> under <a href="#">Mahakumbrix Innovation</a></p>
            <p>Powered By <a href="#">Rocket Examica</a> | All Rights Reserved</p>
        </div>
    </div>

    <!-- Results Modal -->
    <div class="modal" id="resultsModal">
        <div class="modal-content">
            <div class="results-header">
                <h2>🎉 Exam Completed!</h2>
                <p>Here's your performance summary</p>
            </div>

            <div class="score-circle">
                <div class="score" id="finalScore">0</div>
                <div class="total">out of 100</div>
            </div>

            <div class="results-details" id="resultsDetails">
                <!-- Results will be populated by JavaScript -->
            </div>

            <div class="chart-container">
                <canvas id="performanceChart"></canvas>
            </div>

            <div class="action-buttons">
                <button class="btn btn-primary" onclick="reviewAnswers()">
                    📝 Review Answers
                </button>
                <button class="btn btn-secondary" onclick="closeResults()">
                    ✖️ Close
                </button>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // GATE CS 2025 Question Data
        const questionData = [
            // General Aptitude Q1-Q5 (1 mark each)
            {
                id: 1,
                section: "GA",
                marks: 1,
                type: "MCQ",
                question: "Ravi had ______ younger brother who taught at ______ university. He was widely regarded as ______ honorable man. Select the option with the correct sequence of articles to fill in the blanks.",
                options: [
                    "a; a; an",
                    "the; an; a",
                    "a; an; a",
                    "an; an; a"
                ],
                correctAnswer: 0
            },
            {
                id: 2,
                section: "GA",
                marks: 1,
                type: "MCQ",
                question: "The CEO's decision to downsize the workforce was considered myopic because it sacrificed long-term stability to accommodate short-term gains. Select the most appropriate option that can replace the word 'myopic' without changing the meaning of the sentence.",
                options: [
                    "visionary",
                    "shortsighted",
                    "progressive",
                    "innovative"
                ],
                correctAnswer: 1
            },
            {
                id: 3,
                section: "GA",
                marks: 1,
                type: "MCQ",
                question: "The average marks obtained by a class in an examination were calculated as 30.8. However, while checking the marks entered, the teacher found that the marks of one student were entered incorrectly as 24 instead of 42. After correcting the marks, the average becomes 31.4. How many students does the class have?",
                options: [
                    "25",
                    "28",
                    "30",
                    "32"
                ],
                correctAnswer: 2
            },
            {
                id: 4,
                section: "GA",
                marks: 1,
                type: "MCQ",
                question: "Consider the relationships among P, Q, R, S, and T: P is the brother of Q, S is the daughter of Q, T is the sister of S, R is the mother of Q. The following statements are made: (1) R is the grandmother of S. (2) P is the uncle of S and T. (3) R has only one son. (4) Q has only one daughter. Which one of the following options is correct?",
                options: [
                    "Both (1) and (2) are true.",
                    "Both (1) and (3) are true.",
                    "Only (3) is true.",
                    "Only (4) is true."
                ],
                correctAnswer: 0
            },
            {
                id: 5,
                section: "GA",
                marks: 1,
                type: "MCQ",
                question: "According to the map shown, which one of the following statements is correct? (Map shows Library, Physics Lab, Canteen, Hospital, Chemistry Lab, Hostels, and Classrooms with their relative positions)",
                options: [
                    "The library is located to the northwest of the canteen.",
                    "The hospital is located to the east of the chemistry lab.",
                    "The chemistry lab is to the southeast of physics lab.",
                    "The classrooms and canteen are next to each other."
                ],
                correctAnswer: 2
            },
            // General Aptitude Q6-Q10 (2 marks each)
            {
                id: 6,
                section: "GA",
                marks: 2,
                type: "MCQ",
                question: "Based on the passage from G.K. Chesterton's 'A Piece of Chalk' about things in one's pocket, which one of the following statements is true?",
                options: [
                    "The author of the passage carries a mirror in his pocket to reflect upon things.",
                    "The author of the passage had decided to write a poem on epics.",
                    "The pocket-knife is described as the infant of the sword.",
                    "Epics are described as too inconvenient to write."
                ],
                correctAnswer: 2
            },
            {
                id: 7,
                section: "GA",
                marks: 2,
                type: "MCQ",
                question: "In the diagram, the lines QR and ST are parallel to each other. The shortest distance between these two lines is half the shortest distance between the point P and line QR. What is the ratio of the area of the triangle PST to the area of the trapezium SQRT?",
                options: [
                    "1/3",
                    "1/4",
                    "2/5",
                    "1/2"
                ],
                correctAnswer: 0
            },
            {
                id: 8,
                section: "GA",
                marks: 2,
                type: "MCQ",
                question: "A fair six-faced dice, with the faces labelled '1', '2', '3', '4', '5', and '6', is rolled thrice. What is the probability of rolling '6' exactly once?",
                options: [
                    "75/216",
                    "1/6",
                    "1/18",
                    "25/216"
                ],
                correctAnswer: 0
            },
            {
                id: 9,
                section: "GA",
                marks: 2,
                type: "MCQ",
                question: "A square paper is folded along dotted lines and then cuts are made. Which one of the following patterns will be obtained when the paper is unfolded?",
                options: [
                    "Pattern A (squares at corners and center)",
                    "Pattern B (diamonds at corners, center square)",
                    "Pattern C (squares at four sides)",
                    "Pattern D (single center square)"
                ],
                correctAnswer: 0
            },
            {
                id: 10,
                section: "GA",
                marks: 2,
                type: "MCQ",
                question: "A shop has 4 distinct flavors of ice-cream. One can purchase any number of scoops of any flavor. The order in which the scoops are purchased is inconsequential. If one wants to purchase 3 scoops of ice-cream, in how many ways can one make that purchase?",
                options: [
                    "4",
                    "20",
                    "24",
                    "48"
                ],
                correctAnswer: 1
            },
            // Technical Questions Q11-Q35 (1 mark each)
            {
                id: 11,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Suppose a program is running on a non-pipelined single processor computer system. The processor needs to execute the interrupt service routine (ISR) when an interrupt arrives. Which ONE of the following is the CORRECT sequence of steps? (i) Save program counter (ii) Load PC with ISR address (iii) Finish present instruction",
                options: [
                    "(iii), (i), (ii)",
                    "(i), (iii), (ii)",
                    "(i), (ii), (iii)",
                    "(iii), (ii), (i)"
                ],
                correctAnswer: 0
            },
            {
                id: 12,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Which ONE of the following statements is FALSE regarding the symbol table?",
                options: [
                    "Symbol table is responsible for keeping track of the scope of variables.",
                    "Symbol table can be implemented using a binary search tree.",
                    "Symbol table is not required after the parsing phase.",
                    "Symbol table is created during the lexical analysis phase."
                ],
                correctAnswer: 2
            },
            {
                id: 13,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Which ONE of the following techniques used in compiler code optimization uses live variable analysis?",
                options: [
                    "Run-time function call management",
                    "Register assignment to variables",
                    "Strength reduction",
                    "Constant folding"
                ],
                correctAnswer: 1
            },
            {
                id: 14,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Consider a demand paging memory management system with 32-bit logical address, 20-bit physical address, and page size of 2048 bytes. Assuming that the memory is byte addressable, what is the maximum number of entries in the page table?",
                options: [
                    "2²¹",
                    "2²⁰",
                    "2²²",
                    "2²⁴"
                ],
                correctAnswer: 0
            },
            {
                id: 15,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "A schedule of three database transactions T₁, T₂, and T₃ is shown: R₁(X) W₁(Y) R₂(X) R₂(Y) R₃(Y) ABORT(T₁). Transaction T₁ aborts at the end. Which other transaction(s) will be required to be rolled back?",
                options: [
                    "Only T₂",
                    "Only T₃",
                    "Both T₂ and T₃",
                    "Neither T₂ nor T₃"
                ],
                correctAnswer: 0
            },
            {
                id: 16,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Identify the ONE CORRECT matching between the OSI layers and their corresponding functionalities: (a) Network layer - (I) Packet routing, (b) Transport layer - (II) Framing and error handling, (c) Datalink layer - (III) Host to host communication",
                options: [
                    "(a)-(I), (b)-(II), (c)-(III)",
                    "(a)-(I), (b)-(III), (c)-(II)",
                    "(a)-(II), (b)-(I), (c)-(III)",
                    "(a)-(III), (b)-(II), (c)-(I)"
                ],
                correctAnswer: 1
            },
            {
                id: 17,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "g(.) is a function from A to B, f(.) is a function from B to C, and their composition is f(g(.)). If f(.) and f(g(.)) are onto (surjective) functions, which ONE of the following is TRUE about the function g(.)?",
                options: [
                    "g(.) must be an onto (surjective) function.",
                    "g(.) must be a one-to-one (injective) function.",
                    "g(.) must be a bijective function, that is, both one-to-one and onto.",
                    "g(.) is not required to be a one-to-one or onto function."
                ],
                correctAnswer: 0
            },
            {
                id: 18,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Let G be any undirected graph with positive edge weights, and T be a minimum spanning tree of G. For any two vertices, u and v, let d₁(u,v) and d₂(u,v) be the shortest distances between u and v in G and T, respectively. Which ONE of the options is CORRECT for all possible G, T, u and v?",
                options: [
                    "d₁(u,v) = d₂(u,v)",
                    "d₁(u,v) ≤ d₂(u,v)",
                    "d₁(u,v) ≥ d₂(u,v)",
                    "d₁(u,v) ≠ d₂(u,v)"
                ],
                correctAnswer: 1
            },
            {
                id: 19,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Consider the context-free grammar G with rules: S → aaB | Abb, A → a | aA, B → b | bB. Which ONE of the languages L(G) is accepted by G?",
                options: [
                    "L(G) = {a²ⁿbⁿ | n ≥ 1} ∪ {aⁿb² | n ≥ 1}",
                    "L(G) = {aⁿb²ⁿ | n ≥ 1} ∪ {a²ⁿbⁿ | n ≥ 1}",
                    "L(G) = {aⁿbⁿ | n ≥ 1}",
                    "L(G) = {a²ⁿb²ⁿ | n ≥ 1}"
                ],
                correctAnswer: 1
            },
            {
                id: 20,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Consider the recurrence relation: T(n) = 2T(n-1) + n2ⁿ for n > 0, T(0) = 1. Which ONE of the following options is CORRECT?",
                options: [
                    "T(n) = Θ(n²2ⁿ)",
                    "T(n) = Θ(n2ⁿ)",
                    "T(n) = Θ((log n)² 2ⁿ)",
                    "T(n) = Θ(4ⁿ)"
                ],
                correctAnswer: 1
            },
            // Continue with more questions...
            {
                id: 21,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "Consider the following B+ tree with 5 nodes, in which a node can store at most 3 key values. The value 23 is now inserted in the B+ tree. Which of the following options(s) is/are CORRECT?",
                options: [
                    "None of the nodes will split.",
                    "At least one node will split and redistribute.",
                    "The total number of nodes will remain same.",
                    "The height of the tree will increase."
                ],
                correctAnswer: [1]
            },
            {
                id: 22,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "Consider the 3-way handshaking protocol for TCP connection establishment. Let the three packets be P1, P2, and P3. Which of the following option(s) is/are TRUE with respect to TCP header flags?",
                options: [
                    "P3: SYN = 1, ACK = 1",
                    "P2: SYN = 1, ACK = 1",
                    "P2: SYN = 0, ACK = 1",
                    "P1: SYN = 1"
                ],
                correctAnswer: [1, 3]
            },
            {
                id: 23,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "Consider the given system of linear equations for variables x and y, where k is a real-valued constant: x + ky = 1, kx + y = -1. Which of the following option(s) is/are CORRECT?",
                options: [
                    "There is exactly one value of k for which the above system of equations has no solution.",
                    "There exist an infinite number of values of k for which the system of equations has no solution.",
                    "There exists exactly one value of k for which the system of equations has exactly one solution.",
                    "There exists exactly one value of k for which the system of equations has an infinite number of solutions."
                ],
                correctAnswer: [0, 3]
            },
            {
                id: 24,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "Let X be a 3-variable Boolean function that produces output as '1' when at least two of the input variables are '1'. Which of the following statement(s) is/are CORRECT?",
                options: [
                    "X(a,b,X(c,d,e)) = X(X(a,b,c),d,e)",
                    "X(a,b,X(a,b,c)) = X(a,b,c)",
                    "X(a,b,X(a,c,d)) = (X(a,b,a) AND X(c,d,c))",
                    "X(a,b,c) = X(a,X(a,b,c),X(a,c,c))"
                ],
                correctAnswer: [0, 1, 3]
            },
            {
                id: 25,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "The number −6 can be represented as 1010 in 4-bit 2's complement representation. Which of the following is/are CORRECT 2's complement representation(s) of −6?",
                options: [
                    "1000 1010 in 8-bits",
                    "1111 1010 in 8-bits",
                    "1000 0000 0000 1010 in 16-bits",
                    "1111 1111 1111 1010 in 16-bits"
                ],
                correctAnswer: [1, 3]
            },
            {
                id: 26,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "Which of the following statement(s) is/are TRUE for any binary search tree (BST) having n distinct integers?",
                options: [
                    "The maximum length of a path from the root node to any other node is (n-1).",
                    "An inorder traversal will always produce a sorted sequence of elements.",
                    "Finding an element takes O(log₂ n) time in the worst case.",
                    "Every BST is also a Min-Heap."
                ],
                correctAnswer: [0, 1]
            },
            {
                id: 27,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "A partial data path of a processor is given with RA, RB, and RZ as 32-bit registers. Which option(s) is/are CORRECT related to arithmetic operations using the data path?",
                options: [
                    "The data path can implement arithmetic operations involving two registers.",
                    "The data path can implement arithmetic operations involving one register and one immediate value.",
                    "The data path can implement arithmetic operations involving two immediate values.",
                    "The data path can only implement arithmetic operations involving one register and one immediate value."
                ],
                correctAnswer: [0, 1, 2]
            },
            {
                id: 28,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "A regular language L is accepted by a non-deterministic finite automaton (NFA) with n states. Which of the following statement(s) is/are FALSE?",
                options: [
                    "L may have an accepting NFA with < n states.",
                    "L may have an accepting DFA with < n states.",
                    "There exists a DFA with ≤ 2ⁿ states that accepts L.",
                    "Every DFA that accepts L has > 2ⁿ states."
                ],
                correctAnswer: [3]
            },
            {
                id: 29,
                section: "Technical",
                marks: 1,
                type: "NAT",
                question: "Suppose in a multiprogramming environment, a C program with scanf and printf in a for loop (20 iterations) is executed. The number of times the process will enter the ready queue during its lifetime (not counting the initial entry) is _______.",
                correctAnswer: 41,
                tolerance: 0
            },
            {
                id: 30,
                section: "Technical",
                marks: 1,
                type: "NAT",
                question: "Let S be the set of all ternary strings defined over the alphabet {a,b,c}. Consider all strings in S that contain at least one occurrence of two consecutive symbols (aa, bb or cc). The number of such strings of length 5 is _______.",
                correctAnswer: 195,
                tolerance: 0
            },
            {
                id: 31,
                section: "Technical",
                marks: 1,
                type: "NAT",
                question: "Consider the function f(x) = {ax+b for x<1, x³+x²+1 for x≥1}. If the function is differentiable everywhere, the value of b must be _______.",
                correctAnswer: 1.0,
                tolerance: 0.1
            },
            {
                id: 32,
                section: "Technical",
                marks: 1,
                type: "NAT",
                question: "A box contains 5 coins: 4 regular coins and 1 fake coin. When a regular coin is tossed, P(head)=0.5 and for a fake coin, P(head)=1. You pick a coin at random and toss it twice, and get two heads. The probability that the coin you have chosen is the fake coin is _______.",
                correctAnswer: 0.80,
                tolerance: 0.01
            },
            {
                id: 33,
                section: "Technical",
                marks: 1,
                type: "NAT",
                question: "The pseudocode of a bubble sort function is given. Let A[0,...,29] be an array storing 30 distinct integers in descending order. The number of swap operations that will be performed is __________.",
                correctAnswer: 435,
                tolerance: 0
            },
            {
                id: 34,
                section: "Technical",
                marks: 1,
                type: "NAT",
                question: "Given C program with pointer operations: int *z; int a=20, b=25; z=&a; foo(z,b); printf('%d',a);. The output is __________.",
                correctAnswer: 25,
                tolerance: 0
            },
            {
                id: 35,
                section: "Technical",
                marks: 1,
                type: "NAT",
                question: "The height of any rooted tree is defined as the maximum number of edges in the path from the root node to any leaf node. Suppose a Min-Heap T stores 32 keys. The height of T is _____________.",
                correctAnswer: 4,
                tolerance: 0
            },
            // Technical Q36-Q65 (2 marks each)
            {
                id: 36,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "Consider a memory system with 1M bytes of main memory and 16K bytes of cache memory. The processor generates 20-bit memory address, and cache block size is 16 bytes. If the cache uses direct mapping, how many bits will be required to store all the tag values?",
                options: [
                    "6 × 2¹⁰",
                    "8 × 2¹⁰",
                    "2¹²",
                    "2¹⁴"
                ],
                correctAnswer: 0
            },
            {
                id: 37,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "A processor has 64 general-purpose registers and 50 distinct instruction types. An instruction is encoded in 32-bits. What is the maximum number of bits that can be used to store the immediate operand for the instruction: ADD R1, #25?",
                options: [
                    "16",
                    "20",
                    "22",
                    "24"
                ],
                correctAnswer: 2
            },
            {
                id: 38,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "A computer has two processors M₁ and M₂. Four processes P₁,P₂,P₃,P₄ with CPU bursts of 20, 16, 25, and 10 milliseconds arrive at the same time. M₁ uses priority P₁>P₃>P₂>P₄, M₂ uses priority P₂>P₃>P₄>P₁. What will be the average waiting time in milliseconds?",
                options: [
                    "9.00",
                    "8.75",
                    "6.50",
                    "7.50"
                ],
                correctAnswer: 2
            },
            {
                id: 39,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "Consider two relations: teams(tid,tname) and players(pid,pname,tid). Which tuple relational calculus query returns the name of players who play for team 'MI'?",
                options: [
                    "{p.pname | p ∈ players ∧ ∃t (t ∈ teams ∧ p.tid = t.tid ∧ t.tname = 'MI')}",
                    "{p.pname | p ∈ teams ∧ ∃t (t ∈ players ∧ p.tid = t.tid ∧ t.tname = 'MI')}",
                    "{p.pname | p ∈ players ∧ ∃t (t ∈ teams ∧ t.tname = 'MI')}",
                    "{p.pname | p ∈ teams ∧ ∃t (t ∈ players ∧ t.tname = 'MI')}"
                ],
                correctAnswer: 0
            },
            {
                id: 40,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "A packet with destination IP address 145.36.109.70 arrives at a router. Which interface will the packet be forwarded to? (145.36.0.0/16→E1, 145.36.128.0/17→E2, 145.36.64.0/18→E3, 145.36.255.0/24→E4, Default→E5)",
                options: [
                    "E3",
                    "E1",
                    "E2",
                    "E5"
                ],
                correctAnswer: 0
            },
            {
                id: 41,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "Let A be a 2×2 matrix: A = [[1,1],[1,-1]]. What are the eigenvalues of the matrix A¹³?",
                options: [
                    "1, -1",
                    "2√2, -2√2",
                    "4√2, -4√2",
                    "64√2, -64√2"
                ],
                correctAnswer: 3
            },
            {
                id: 42,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "Consider the 4-variable Boolean function F(b₃,b₂,b₁,b₀) = Σ(0,2,4,8,10,11,12). Which ONE of the following is the CORRECT minimized Boolean expression?",
                options: [
                    "b̄₁b̄₀ + b̄₂b̄₀ + b₁b̄₂b₃",
                    "b̄₁b̄₀ + b̄₂b̄₀",
                    "b̄₂b̄₀ + b₁b₂b₃",
                    "b̄₀b̄₂ + b̄₃"
                ],
                correctAnswer: 0
            },
            {
                id: 43,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "Let G(V,E) be an undirected and unweighted graph with 100 vertices. Let d(u,v) denote the number of edges in a shortest path between u and v. The maximum value of d(u,v) is 30. Let T be any breadth-first-search tree of G. Which ONE is CORRECT?",
                options: [
                    "The height of T is exactly 15.",
                    "The height of T is exactly 30.",
                    "The height of T is at least 15.",
                    "The height of T is at least 30."
                ],
                correctAnswer: 2
            },
            {
                id: 44,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "Consider two languages over {a,b}: L₁ = {aᵐbᵝ | α ∈ {a,b}⁺ AND β ∈ {a,b}⁺}, L₂ = {aᵐbᵝ | α ∈ {a}⁺ AND β ∈ {a,b}⁺}. Which ONE is CORRECT?",
                options: [
                    "Both L₁ and L₂ are regular languages.",
                    "L₁ is a regular language but L₂ is not a regular language.",
                    "L₁ is not a regular language but L₂ is a regular language.",
                    "Neither L₁ nor L₂ is a regular language."
                ],
                correctAnswer: 1
            },
            {
                id: 45,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "Consider two languages over {a,b,c}: L₁ = {aᵐbᵐcᵐ⁺ⁿ | m,n ≥ 1}, L₂ = {aᵐbⁿcᵐ⁺ⁿ | m,n ≥ 1}. Which ONE is CORRECT?",
                options: [
                    "Both L₁ and L₂ are context-free languages.",
                    "L₁ is a context-free language but L₂ is not a context-free language.",
                    "L₁ is not a context-free language but L₂ is a context-free language.",
                    "Neither L₁ nor L₂ are context-free languages."
                ],
                correctAnswer: 2
            },
            {
                id: 46,
                section: "Technical",
                marks: 2,
                type: "MSQ",
                question: "Which of the following statement(s) is/are TRUE while computing First and Follow during top down parsing?",
                options: [
                    "For a production A → ε, ε will be added to First(A).",
                    "If there is any input right end marker, it will be added to First(S), where S is the start symbol.",
                    "For a production A → ε, ε will be added to Follow(A).",
                    "If there is any input right end marker, it will be added to Follow(S), where S is the start symbol."
                ],
                correctAnswer: [0, 3]
            },
            {
                id: 47,
                section: "Technical",
                marks: 2,
                type: "MSQ",
                question: "Consider a relational schema team(name,city,owner), with functional dependencies {name → city, name → owner}. The relation is decomposed into t1(name,city) and t2(name,owner). Which statement(s) is/are TRUE?",
                options: [
                    "The relation team is NOT in BCNF.",
                    "The relations t1 and t2 are in BCNF.",
                    "The decomposition constitutes a lossless join.",
                    "The relation team is NOT in 3NF."
                ],
                correctAnswer: [0, 1, 2]
            },
            {
                id: 48,
                section: "Technical",
                marks: 2,
                type: "MSQ",
                question: "Which of the following predicate logic formulae/formula is/are CORRECT representation(s) of 'Everyone has exactly one mother'? (mother(y,x): y is the mother of x, noteq(x,y): x and y are not equal)",
                options: [
                    "∀x∃y∃z(mother(y,x) ∧ ¬mother(z,x))",
                    "∀x∃y[mother(y,x) ∧ ∀z(noteq(z,y) → ¬mother(z,x))]",
                    "∀x∀y[mother(y,x) → ∃z(mother(z,x) ∧ ¬noteq(z,y))]",
                    "∀x∃y[mother(y,x) ∧ ¬∃z(noteq(z,y) ∧ mother(z,x))]"
                ],
                correctAnswer: [1, 3]
            },
            {
                id: 49,
                section: "Technical",
                marks: 2,
                type: "MSQ",
                question: "A = {0,1,2,3,...} is the set of non-negative integers. Let F be the set of functions from A to itself. For any two functions, (f₁⊙f₂)(n) = f₁(n) + f₂(n). Which of the following is/are CORRECT about (F,⊙)?",
                options: [
                    "(F,⊙) is an Abelian group.",
                    "(F,⊙) is an Abelian monoid.",
                    "(F,⊙) is a non-Abelian group.",
                    "(F,⊙) is a non-Abelian monoid."
                ],
                correctAnswer: [1]
            },
            {
                id: 50,
                section: "Technical",
                marks: 2,
                type: "MSQ",
                question: "Consider a DFA defined over Σ = {a,b}. Identify which language(s) is/are accepted by the given DFA.",
                options: [
                    "The set of all strings containing an even number of b's.",
                    "The set of all strings containing the pattern bab.",
                    "The set of all strings ending with the pattern bab.",
                    "The set of all strings not containing the pattern aba."
                ],
                correctAnswer: [1, 2]
            },
            {
                id: 51,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "A disk of size 512M bytes is divided into blocks of 64K bytes. A file is stored using linked allocation where each data block reserves 4 bytes for pointer. A file of 1M bytes needs to be stored. The amount of space in bytes that will be wasted due to internal fragmentation is ______.",
                correctAnswer: 64,
                tolerance: 0
            },
            {
                id: 52,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Refer to the given 3-address code sequence with goto statements. The number of basic blocks is ________.",
                correctAnswer: 4,
                tolerance: 0
            },
            {
                id: 53,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "A computer has a memory hierarchy with L1 cache (hit rate=95%, access time=10ns), L2 cache (hit rate=85%, access time including L1 miss penalty=20ns), and Main Memory (access time including L1 and L2 cache miss penalty=200ns). The average memory access time in nanoseconds is ________.",
                correctAnswer: 11.50,
                tolerance: 0.01
            },
            {
                id: 54,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "In optimal page replacement with modification (predicts only up to next 4 page references), a process accesses pages: 1,3,2,4,2,3,1,2,4,3,1,4. With three initially empty memory frames, the number of page faults is ________.",
                correctAnswer: 6,
                tolerance: 0
            },
            {
                id: 55,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Consider database tables: player(pid,pname,age), coach(cid,cname), team(tid,tname,city,cid), members(pid,tid). Given SQL query returns MIN(P.age) for players whose coach is 'Mark'. The value returned is ______.",
                correctAnswer: 30,
                tolerance: 0
            },
            {
                id: 56,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "A 5-bit message is transmitted through a noisy channel. The probability that a bit gets flipped is 0.01. Flipping of each bit is independent. The probability that the message is delivered error-free is ______.",
                correctAnswer: 0.951,
                tolerance: 0.001
            },
            {
                id: 57,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "A message of 15000 bytes is transmitted using IPv4 via two routers: Router-1 (MTU=5000 bytes) and Router-2 (MTU=3000 bytes). The number of fragments delivered to the destination is ________.",
                correctAnswer: 6,
                tolerance: 0
            },
            {
                id: 58,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Consider probability distribution P(x) = {Cx² for 1≤x≤4, 0 otherwise}. The probability that x lies between 2 and 3, P(2≤x≤3) is __________.",
                correctAnswer: 0.333,
                tolerance: 0.001
            },
            {
                id: 59,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Consider a finite state machine (FSM) with one input X and one output f, represented by the given state transition table. The minimum number of states required to realize this FSM is ________.",
                correctAnswer: 5,
                tolerance: 0
            },
            {
                id: 60,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Consider the sequential circuit designed using D-Flip-flops. The circuit is initialized with some value. The number of distinct states the circuit will go through before returning back to the initial state is _________.",
                correctAnswer: 16,
                tolerance: 0
            },
            {
                id: 61,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Given C program with recursive function foo() on array A[]={0,1,2,2,2,0,0,1,1}. The value printed is _______.",
                correctAnswer: 5,
                tolerance: 0
            },
            {
                id: 62,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Given C program with linked list operations. L1 has 9 nodes: 1→7→12→3→9→5→11→15→8. L2 has 7 nodes: 1→11→6→9→15→12→4. After execution, the number of nodes in L1 is ________.",
                correctAnswer: 4,
                tolerance: 0
            },
            {
                id: 63,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Consider C program with function gate(14362). The value printed is _______.",
                correctAnswer: 432,
                tolerance: 0
            },
            {
                id: 64,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Given graph with edges: A-B(7), A-D(6), B-C(x), D-C(3), D-B(1), C-D(8). The maximum value of x such that edge B-C is included in every minimum spanning tree is _________.",
                correctAnswer: 7,
                tolerance: 0
            },
            {
                id: 65,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "In double hashing scheme, h₁(k)=k mod 11 and h₂(k)=1+(k mod 7). Hash table size is 11. Keys inserted: 63,50,25,79,67,24. The slot at which key 24 gets stored is ___________.",
                correctAnswer: 4,
                tolerance: 0
            }
        ];

        // App State
        let currentQuestion = 0;
        let userAnswers = {};
        let markedQuestions = new Set();
        let visitedQuestions = new Set();
        let startTime = null;
        let timerInterval = null;
        let examStarted = false;
        let examSubmitted = false;

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            // Show instructions initially
        });

        function startExam() {
            examStarted = true;
            document.getElementById('instructions').style.display = 'none';
            document.getElementById('examContent').style.display = 'block';
            
            startTime = new Date();
            startTimer();
            loadQuestions();
            generateQuestionPalette();
            showQuestion(0);
            updateStats();
        }

        function startTimer() {
            let duration = 180 * 60; // 3 hours in seconds
            
            timerInterval = setInterval(() => {
                if (examSubmitted) {
                    clearInterval(timerInterval);
                    return;
                }

                duration--;
                
                let hours = Math.floor(duration / 3600);
                let minutes = Math.floor((duration % 3600) / 60);
                let seconds = duration % 60;
                
                document.getElementById('timeDisplay').textContent = 
                    `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
                
                if (duration <= 0) {
                    clearInterval(timerInterval);
                    submitExam();
                }
            }, 1000);
        }

        function loadQuestions() {
            const container = document.getElementById('questionsContainer');
            container.innerHTML = '';
            
            questionData.forEach((q, index) => {
                const questionCard = createQuestionCard(q, index);
                container.appendChild(questionCard);
            });
        }

        function createQuestionCard(question, index) {
            const card = document.createElement('div');
            card.className = 'question-card';
            card.id = `question-${index}`;
            
            let optionsHTML = '';
            if (question.type === 'MCQ' || question.type === 'MSQ') {
                optionsHTML = question.options.map((option, optIndex) => `
                    <div class="option" onclick="selectOption(${index}, ${optIndex}, '${question.type}')">
                        <div class="option-radio"></div>
                        <div class="option-text"><strong>(${String.fromCharCode(65 + optIndex)})</strong> ${option}</div>
                    </div>
                `).join('');
            } else if (question.type === 'NAT') {
                optionsHTML = `
                    <input type="number" 
                           step="any" 
                           class="numerical-input" 
                           id="nat-input-${index}"
                           placeholder="Enter your answer (numerical value)"
                           onchange="saveNumericalAnswer(${index})">
                `;
            }
            
            card.innerHTML = `
                <div class="question-header">
                    <span class="question-number">Question ${question.id}</span>
                    <span class="marks-badge">${question.marks} ${question.marks === 1 ? 'Mark' : 'Marks'}</span>
                </div>
                <div class="question-text">
                    <strong>${question.section === 'GA' ? 'General Aptitude' : 'Technical Section'}</strong><br>
                    ${question.question}
                </div>
                <div class="options">
                    ${optionsHTML}
                </div>
            `;
            
            return card;
        }

        function generateQuestionPalette() {
            const palette = document.getElementById('questionPalette');
            palette.innerHTML = '';
            
            questionData.forEach((q, index) => {
                const btn = document.createElement('button');
                btn.className = 'palette-btn';
                btn.textContent = q.id;
                btn.onclick = () => showQuestion(index);
                palette.appendChild(btn);
            });
        }

        function showQuestion(index) {
            // Hide all questions
            document.querySelectorAll('.question-card').forEach(card => {
                card.classList.remove('active');
            });
            
            // Show current question
            const questionCard = document.getElementById(`question-${index}`);
            if (questionCard) {
                questionCard.classList.add('active');
                currentQuestion = index;
                visitedQuestions.add(index);
                updateQuestionPalette();
                updateStats();
                
                // Scroll to top
                questionCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
                
                // Restore answer if exists
                if (userAnswers[index] !== undefined) {
                    const question = questionData[index];
                    if (question.type === 'NAT') {
                        document.getElementById(`nat-input-${index}`).value = userAnswers[index];
                    } else {
                        restoreOptionSelection(index);
                    }
                }
            }
        }

        function restoreOptionSelection(questionIndex) {
            const question = questionData[questionIndex];
            const card = document.getElementById(`question-${questionIndex}`);
            const options = card.querySelectorAll('.option');
            
            options.forEach((option, optIndex) => {
                option.classList.remove('selected');
            });
            
            if (Array.isArray(userAnswers[questionIndex])) {
                // MSQ
                userAnswers[questionIndex].forEach(selectedIndex => {
                    if (options[selectedIndex]) {
                        options[selectedIndex].classList.add('selected');
                    }
                });
            } else if (userAnswers[questionIndex] !== undefined) {
                // MCQ
                if (options[userAnswers[questionIndex]]) {
                    options[userAnswers[questionIndex]].classList.add('selected');
                }
            }
        }

        function selectOption(questionIndex, optionIndex, type) {
            const card = document.getElementById(`question-${questionIndex}`);
            const options = card.querySelectorAll('.option');
            
            if (type === 'MCQ') {
                // Single selection
                options.forEach(opt => opt.classList.remove('selected'));
                options[optionIndex].classList.add('selected');
                userAnswers[questionIndex] = optionIndex;
            } else if (type === 'MSQ') {
                // Multiple selection
                if (!userAnswers[questionIndex]) {
                    userAnswers[questionIndex] = [];
                }
                
                if (options[optionIndex].classList.contains('selected')) {
                    options[optionIndex].classList.remove('selected');
                    userAnswers[questionIndex] = userAnswers[questionIndex].filter(i => i !== optionIndex);
                    if (userAnswers[questionIndex].length === 0) {
                        delete userAnswers[questionIndex];
                    }
                } else {
                    options[optionIndex].classList.add('selected');
                    if (!userAnswers[questionIndex].includes(optionIndex)) {
                        userAnswers[questionIndex].push(optionIndex);
                    }
                }
            }
            
            updateQuestionPalette();
            updateStats();
        }

        function saveNumericalAnswer(questionIndex) {
            const input = document.getElementById(`nat-input-${questionIndex}`);
            const value = input.value.trim();
            
            if (value !== '') {
                userAnswers[questionIndex] = parseFloat(value);
            } else {
                delete userAnswers[questionIndex];
            }
            
            updateQuestionPalette();
            updateStats();
        }

        function updateQuestionPalette() {
            const palette = document.querySelectorAll('.palette-btn');
            
            palette.forEach((btn, index) => {
                btn.classList.remove('answered', 'marked', 'current');
                
                if (index === currentQuestion) {
                    btn.classList.add('current');
                } else if (userAnswers[index] !== undefined) {
                    btn.classList.add('answered');
                } else if (markedQuestions.has(index)) {
                    btn.classList.add('marked');
                }
            });
        }

        function updateStats() {
            const answered = Object.keys(userAnswers).length;
            const marked = markedQuestions.size;
            const visited = visitedQuestions.size;
            const notVisited = questionData.length - visited;
            
            document.getElementById('answeredCount').textContent = answered;
            document.getElementById('markedCount').textContent = marked;
            document.getElementById('visitedCount').textContent = visited;
            document.getElementById('notVisitedCount').textContent = notVisited;
            
            const progress = (answered / questionData.length) * 100;
            document.getElementById('progressBar').style.width = progress + '%';
            document.getElementById('progressText').textContent = `${answered} of ${questionData.length} answered`;
        }

        function nextQuestion() {
            if (currentQuestion < questionData.length - 1) {
                showQuestion(currentQuestion + 1);
            }
        }

        function previousQuestion() {
            if (currentQuestion > 0) {
                showQuestion(currentQuestion - 1);
            }
        }

        function markForReview() {
            if (markedQuestions.has(currentQuestion)) {
                markedQuestions.delete(currentQuestion);
            } else {
                markedQuestions.add(currentQuestion);
            }
            updateQuestionPalette();
            updateStats();
        }

        function clearResponse() {
            const question = questionData[currentQuestion];
            
            if (question.type === 'NAT') {
                document.getElementById(`nat-input-${currentQuestion}`).value = '';
            } else {
                const card = document.getElementById(`question-${currentQuestion}`);
                const options = card.querySelectorAll('.option');
                options.forEach(opt => opt.classList.remove('selected'));
            }
            
            delete userAnswers[currentQuestion];
            updateQuestionPalette();
            updateStats();
        }

        function filterQuestions(filter) {
            // Update active tab
            document.querySelectorAll('.nav-tab').forEach(tab => {
                tab.classList.remove('active');
            });
            event.target.classList.add('active');
            
            // Filter logic (for now just showing all)
            // You can implement specific filtering based on the filter parameter
        }

        function submitExam() {
            if (!examSubmitted) {
                const confirmSubmit = confirm('Are you sure you want to submit the exam? You cannot change your answers after submission.');
                if (!confirmSubmit) return;
            }
            
            examSubmitted = true;
            clearInterval(timerInterval);
            
            calculateResults();
        }

        function calculateResults() {
            let totalScore = 0;
            let correctAnswers = 0;
            let wrongAnswers = 0;
            let unanswered = 0;
            let sectionWise = {
                GA: { score: 0, total: 15, correct: 0, wrong: 0 },
                Technical: { score: 0, total: 85, correct: 0, wrong: 0 }
            };
            
            questionData.forEach((question, index) => {
                const userAnswer = userAnswers[index];
                let isCorrect = false;
                
                if (userAnswer === undefined) {
                    unanswered++;
                    return;
                }
                
                if (question.type === 'MCQ') {
                    isCorrect = userAnswer === question.correctAnswer;
                } else if (question.type === 'MSQ') {
                    if (Array.isArray(userAnswer) && Array.isArray(question.correctAnswer)) {
                        isCorrect = userAnswer.length === question.correctAnswer.length &&
                                   userAnswer.every(val => question.correctAnswer.includes(val));
                    }
                } else if (question.type === 'NAT') {
                    const tolerance = question.tolerance || 0;
                    isCorrect = Math.abs(userAnswer - question.correctAnswer) <= tolerance;
                }
                
                if (isCorrect) {
                    totalScore += question.marks;
                    correctAnswers++;
                    sectionWise[question.section].score += question.marks;
                    sectionWise[question.section].correct++;
                } else {
                    wrongAnswers++;
                    sectionWise[question.section].wrong++;
                    // Negative marking for MCQ only
                    if (question.type === 'MCQ') {
                        const penalty = question.marks === 1 ? 1/3 : 2/3;
                        totalScore -= penalty;
                        sectionWise[question.section].score -= penalty;
                    }
                }
            });
            
            // Show results
            showResults(totalScore, correctAnswers, wrongAnswers, unanswered, sectionWise);
        }

        function showResults(score, correct, wrong, unanswered, sectionWise) {
            document.getElementById('finalScore').textContent = Math.max(0, score.toFixed(2));
            
            const detailsHTML = `
                <div class="result-item">
                    <span>Correct Answers</span>
                    <strong style="color: var(--success)">${correct}</strong>
                </div>
                <div class="result-item">
                    <span>Wrong Answers</span>
                    <strong style="color: var(--danger)">${wrong}</strong>
                </div>
                <div class="result-item">
                    <span>Unanswered</span>
                    <strong style="color: var(--gray)">${unanswered}</strong>
                </div>
                <div class="result-item">
                    <span>Attempted</span>
                    <strong>${correct + wrong}</strong>
                </div>
                <div class="result-item">
                    <span>General Aptitude Score</span>
                    <strong style="color: var(--primary)">${sectionWise.GA.score.toFixed(2)} / ${sectionWise.GA.total}</strong>
                </div>
                <div class="result-item">
                    <span>Technical Score</span>
                    <strong style="color: var(--primary)">${sectionWise.Technical.score.toFixed(2)} / ${sectionWise.Technical.total}</strong>
                </div>
                <div class="result-item">
                    <span>Accuracy</span>
                    <strong>${((correct / (correct + wrong)) * 100 || 0).toFixed(1)}%</strong>
                </div>
            `;
            
            document.getElementById('resultsDetails').innerHTML = detailsHTML;
            
            // Create chart
            createPerformanceChart(correct, wrong, unanswered);
            
            document.getElementById('resultsModal').classList.add('active');
        }

        function createPerformanceChart(correct, wrong, unanswered) {
            const ctx = document.getElementById('performanceChart').getContext('2d');
            
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Correct', 'Wrong', 'Unanswered'],
                    datasets: [{
                        data: [correct, wrong, unanswered],
                        backgroundColor: [
                            'rgba(16, 185, 129, 0.8)',
                            'rgba(239, 68, 68, 0.8)',
                            'rgba(100, 116, 139, 0.8)'
                        ],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom',
                        },
                        title: {
                            display: true,
                            text: 'Performance Analysis'
                        }
                    }
                }
            });
        }

        function reviewAnswers() {
            document.getElementById('resultsModal').classList.remove('active');
            showQuestion(0);
            
            // Show correct/wrong indicators
            questionData.forEach((question, index) => {
                const card = document.getElementById(`question-${index}`);
                const options = card.querySelectorAll('.option');
                const userAnswer = userAnswers[index];
                
                if (question.type === 'MCQ') {
                    options.forEach((option, optIndex) => {
                        if (optIndex === question.correctAnswer) {
                            option.classList.add('correct');
                        }
                        if (optIndex === userAnswer && userAnswer !== question.correctAnswer) {
                            option.classList.add('wrong');
                        }
                    });
                }
            });
        }

        function closeResults() {
            document.getElementById('resultsModal').classList.remove('active');
        }
    </script>
</body>
</html>