<?php
/* === PERSISTENT SESSION PROTECTION === */

// Start session with 1 year lifetime
if (session_status() === PHP_SESSION_NONE) {
    ini_set("session.gc_maxlifetime", 31536000); // 1 year
    session_set_cookie_params(31536000);
    session_start();
}

// Check if user has premium access
if (!isset($_SESSION["premium_access"]) || $_SESSION["premium_access"] !== true) {
    header("Location: ../../index.php");
    exit;
}

// Validate code has not expired
if (isset($_SESSION["code_expiry"])) {
    $expiry = strtotime($_SESSION["code_expiry"]);
    $today = strtotime(date("Y-m-d"));
    
    if ($today > $expiry) {
        session_destroy();
        header("Location: ../../index.php?error=expired");
        exit;
    }
}

/* === END PERSISTENT SESSION PROTECTION === */
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GATE CS 2024 - IISc Bengaluru | Online Examination</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --secondary: #ec4899;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #3b82f6;
            --dark: #1e293b;
            --light: #f8fafc;
            --gray: #64748b;
            --border: #e2e8f0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: var(--dark);
            line-height: 1.6;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Instructions Screen */
        .instructions-screen {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.2);
            animation: slideIn 0.6s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .instructions-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .instructions-header h1 {
            font-size: 32px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }

        .instructions-header p {
            color: var(--gray);
            font-size: 16px;
        }

        .exam-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }

        .info-card {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.1), rgba(236, 72, 153, 0.1));
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            border-left: 4px solid var(--primary);
        }

        .info-card h3 {
            color: var(--primary);
            font-size: 28px;
            margin-bottom: 5px;
        }

        .info-card p {
            color: var(--gray);
            font-size: 14px;
        }

        .instructions-content {
            margin: 30px 0;
        }

        .instructions-content h2 {
            color: var(--primary);
            margin: 20px 0 15px 0;
            font-size: 22px;
        }

        .instructions-content ul {
            list-style-position: inside;
            color: var(--dark);
        }

        .instructions-content li {
            margin: 10px 0;
            padding-left: 10px;
        }

        .start-btn {
            display: block;
            width: 100%;
            max-width: 400px;
            margin: 30px auto;
            padding: 18px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 8px 20px rgba(99, 102, 241, 0.3);
        }

        .start-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 30px rgba(99, 102, 241, 0.4);
        }

        /* Exam Screen */
        .exam-screen {
            display: none;
        }

        .exam-header {
            background: white;
            padding: 15px 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .exam-title h2 {
            font-size: 24px;
            color: var(--primary);
        }

        .exam-title p {
            color: var(--gray);
            font-size: 14px;
        }

        .timer {
            background: linear-gradient(135deg, var(--danger), #dc2626);
            color: white;
            padding: 12px 24px;
            border-radius: 10px;
            font-size: 20px;
            font-weight: bold;
            box-shadow: 0 5px 15px rgba(239, 68, 68, 0.3);
        }

        .exam-content {
            display: grid;
            grid-template-columns: 1fr 350px;
            gap: 20px;
        }

        .question-panel {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            min-height: 600px;
        }

        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--border);
        }

        .question-number {
            font-size: 18px;
            font-weight: 600;
            color: var(--primary);
        }

        .question-marks {
            background: linear-gradient(135deg, var(--success), #059669);
            color: white;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
        }

        .question-text {
            font-size: 16px;
            line-height: 1.8;
            margin-bottom: 25px;
            color: var(--dark);
        }

        .options {
            margin: 20px 0;
        }

        .option {
            background: var(--light);
            padding: 15px;
            margin: 12px 0;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
            border: 2px solid transparent;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .option:hover {
            background: rgba(99, 102, 241, 0.1);
            border-color: var(--primary);
        }

        .option input[type="radio"],
        .option input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        .option.selected {
            background: rgba(99, 102, 241, 0.15);
            border-color: var(--primary);
        }

        .numerical-input {
            width: 100%;
            padding: 15px;
            font-size: 16px;
            border: 2px solid var(--border);
            border-radius: 10px;
            margin: 15px 0;
        }

        .numerical-input:focus {
            outline: none;
            border-color: var(--primary);
        }

        .question-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
        }

        .btn-secondary {
            background: var(--light);
            color: var(--dark);
            border: 2px solid var(--border);
        }

        .btn-warning {
            background: linear-gradient(135deg, var(--warning), #d97706);
            color: white;
        }

        .btn-danger {
            background: linear-gradient(135deg, var(--danger), #dc2626);
            color: white;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        /* Sidebar */
        .sidebar {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            max-height: 85vh;
            overflow-y: auto;
        }

        .sidebar h3 {
            font-size: 18px;
            color: var(--primary);
            margin-bottom: 15px;
        }

        .navigation-tabs {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 20px;
        }

        .nav-tab {
            padding: 8px 12px;
            background: var(--light);
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 12px;
            transition: all 0.3s;
        }

        .nav-tab.active {
            background: var(--primary);
            color: white;
        }

        .question-palette {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 8px;
        }

        .palette-btn {
            padding: 10px;
            border: 2px solid var(--border);
            background: white;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }

        .palette-btn:hover {
            transform: scale(1.05);
        }

        .palette-btn.current {
            background: var(--info);
            color: white;
            border-color: var(--info);
        }

        .palette-btn.answered {
            background: var(--success);
            color: white;
            border-color: var(--success);
        }

        .palette-btn.marked {
            background: var(--warning);
            color: white;
            border-color: var(--warning);
        }

        .progress-section {
            margin: 20px 0;
            padding: 15px;
            background: var(--light);
            border-radius: 10px;
        }

        .progress-bar {
            height: 8px;
            background: var(--border);
            border-radius: 10px;
            overflow: hidden;
            margin: 10px 0;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            transition: width 0.3s;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-top: 15px;
        }

        .stat-item {
            text-align: center;
            padding: 10px;
            background: white;
            border-radius: 8px;
            border-left: 3px solid var(--primary);
        }

        .stat-value {
            font-size: 20px;
            font-weight: bold;
            color: var(--primary);
        }

        .stat-label {
            font-size: 12px;
            color: var(--gray);
        }

        /* Results Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: 20px;
            padding: 40px;
            max-width: 800px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalSlide 0.3s ease;
        }

        @keyframes modalSlide {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .results-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .results-header h2 {
            font-size: 32px;
            color: var(--primary);
            margin-bottom: 10px;
        }

        .score-circle {
            width: 200px;
            height: 200px;
            margin: 30px auto;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 15px 40px rgba(99, 102, 241, 0.3);
        }

        .score-inner {
            width: 180px;
            height: 180px;
            background: white;
            border-radius: 50%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .score-value {
            font-size: 48px;
            font-weight: bold;
            color: var(--primary);
        }

        .score-label {
            font-size: 14px;
            color: var(--gray);
        }

        .results-details {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin: 30px 0;
        }

        .result-card {
            padding: 20px;
            background: var(--light);
            border-radius: 12px;
            text-align: center;
        }

        .result-card h4 {
            color: var(--gray);
            font-size: 14px;
            margin-bottom: 8px;
        }

        .result-card p {
            font-size: 24px;
            font-weight: bold;
            color: var(--primary);
        }

        .chart-container {
            margin: 30px 0;
            height: 300px;
        }

        /* Responsive */
        @media (max-width: 968px) {
            .exam-content {
                grid-template-columns: 1fr;
            }

            .sidebar {
                order: -1;
                max-height: none;
            }

            .question-palette {
                grid-template-columns: repeat(10, 1fr);
            }
        }

        @media (max-width: 640px) {
            .exam-header {
                flex-direction: column;
                text-align: center;
            }

            .question-palette {
                grid-template-columns: repeat(5, 1fr);
            }

            .results-details {
                grid-template-columns: 1fr;
            }
        }

        .hidden {
            display: none;
        }

        /* Review Mode */
        .review-indicator {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 10px;
        }

        .review-indicator.correct {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }

        .review-indicator.wrong {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Instructions Screen -->
        <div class="instructions-screen" id="instructionsScreen">
            <div class="instructions-header">
                <h1>🎓 GATE CS 2024</h1>
                <p>Computer Science and Information Technology Set 1 (CS1)</p>
                <p>Organizing Institute: IISc Bengaluru</p>
            </div>

            <div class="exam-info">
                <div class="info-card">
                    <h3>65</h3>
                    <p>Total Questions</p>
                </div>
                <div class="info-card">
                    <h3>100</h3>
                    <p>Total Marks</p>
                </div>
                <div class="info-card">
                    <h3>180</h3>
                    <p>Minutes</p>
                </div>
                <div class="info-card">
                    <h3>3</h3>
                    <p>Hours Duration</p>
                </div>
            </div>

            <div class="instructions-content">
                <h2>📋 General Instructions</h2>
                <ul>
                    <li>The examination consists of 65 questions carrying 100 marks.</li>
                    <li>The duration of the examination is 3 hours (180 minutes).</li>
                    <li>Questions Q.1 to Q.10 (General Aptitude) carry a total of 15 marks.</li>
                    <li>Questions Q.11 to Q.65 (Technical Section) carry a total of 85 marks.</li>
                </ul>

                <h2>📊 Question Types</h2>
                <ul>
                    <li><strong>MCQ (Multiple Choice Questions):</strong> Single correct answer from 4 options.</li>
                    <li><strong>MSQ (Multiple Select Questions):</strong> One or more correct answers.</li>
                    <li><strong>NAT (Numerical Answer Type):</strong> Answer is a number that needs to be entered.</li>
                </ul>

                <h2>🎯 Marking Scheme</h2>
                <ul>
                    <li>Questions Q.1 to Q.5 carry <strong>1 mark</strong> each.</li>
                    <li>Questions Q.6 to Q.10 carry <strong>2 marks</strong> each.</li>
                    <li>Questions Q.11 to Q.35 carry <strong>1 mark</strong> each.</li>
                    <li>Questions Q.36 to Q.65 carry <strong>2 marks</strong> each.</li>
                </ul>

                <h2>⚠️ Negative Marking</h2>
                <ul>
                    <li>For 1-mark MCQ: <strong>1/3 mark</strong> deducted for wrong answer.</li>
                    <li>For 2-mark MCQ: <strong>2/3 mark</strong> deducted for wrong answer.</li>
                    <li>No negative marking for MSQ and NAT questions.</li>
                </ul>

                <h2>🖥️ Navigation Instructions</h2>
                <ul>
                    <li>Use <strong>Previous</strong> and <strong>Next</strong> buttons to navigate between questions.</li>
                    <li>Click on question numbers in the palette to jump directly to any question.</li>
                    <li>Use <strong>Mark for Review</strong> to flag questions you want to revisit.</li>
                    <li>Click <strong>Clear Response</strong> to remove your answer for current question.</li>
                    <li>The timer will count down automatically and exam will auto-submit when time is up.</li>
                </ul>

                <h2>✅ Question Status Legend</h2>
                <ul>
                    <li><strong style="color: #3b82f6;">Blue:</strong> Current question</li>
                    <li><strong style="color: #10b981;">Green:</strong> Answered</li>
                    <li><strong style="color: #f59e0b;">Orange:</strong> Marked for review</li>
                    <li><strong style="color: #64748b;">Gray:</strong> Not visited</li>
                </ul>
            </div>

            <button class="start-btn" onclick="startExam()">🚀 Start Examination</button>

            <div style="text-align: center; margin-top: 30px; color: #64748b; font-size: 14px;">
                <p>© 2025 GATEX - Product of Tech Eagles under Mahakumbrix Innovation</p>
                <p>Powered By Rocket Examica | All Rights Reserved</p>
            </div>
        </div>

        <!-- Exam Screen -->
        <div class="exam-screen" id="examScreen">
            <!-- Header -->
            <div class="exam-header">
                <div class="exam-title">
                    <h2>GATE CS 2024</h2>
                    <p>IISc Bengaluru</p>
                </div>
                <div class="timer" id="timer">03:00:00</div>
            </div>

            <!-- Main Content -->
            <div class="exam-content">
                <!-- Question Panel -->
                <div class="question-panel">
                    <div class="question-header">
                        <span class="question-number" id="questionNumber">Question 1 of 65</span>
                        <span class="question-marks" id="questionMarks">1 Mark</span>
                    </div>

                    <div class="question-text" id="questionText"></div>

                    <div id="optionsContainer"></div>

                    <div class="question-actions">
                        <button class="btn btn-warning" onclick="markForReview()">🏴 Mark for Review</button>
                        <button class="btn btn-secondary" onclick="clearResponse()">🗑️ Clear Response</button>
                        <button class="btn btn-secondary" onclick="previousQuestion()">← Previous</button>
                        <button class="btn btn-primary" onclick="nextQuestion()">Next →</button>
                        <button class="btn btn-danger" onclick="confirmSubmit()">📝 Submit Exam</button>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="sidebar">
                    <h3>Question Palette</h3>
                    
                    <div class="navigation-tabs">
                        <button class="nav-tab active" onclick="filterQuestions('all')">All</button>
                        <button class="nav-tab" onclick="filterQuestions('ga')">GA</button>
                        <button class="nav-tab" onclick="filterQuestions('technical')">Technical</button>
                        <button class="nav-tab" onclick="filterQuestions('answered')">Answered</button>
                        <button class="nav-tab" onclick="filterQuestions('unanswered')">Unanswered</button>
                        <button class="nav-tab" onclick="filterQuestions('marked')">Marked</button>
                    </div>

                    <div class="progress-section">
                        <div class="progress-bar">
                            <div class="progress-fill" id="progressBar"></div>
                        </div>
                        <div class="stats">
                            <div class="stat-item">
                                <div class="stat-value" id="answeredCount">0</div>
                                <div class="stat-label">Answered</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value" id="markedCount">0</div>
                                <div class="stat-label">Marked</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value" id="visitedCount">0</div>
                                <div class="stat-label">Visited</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value" id="notVisitedCount">65</div>
                                <div class="stat-label">Not Visited</div>
                            </div>
                        </div>
                    </div>

                    <div class="question-palette" id="questionPalette"></div>
                </div>
            </div>
        </div>

        <!-- Results Modal -->
        <div class="modal" id="resultsModal">
            <div class="modal-content">
                <div class="results-header">
                    <h2>🎉 Exam Completed!</h2>
                    <p>Here's your performance summary</p>
                </div>

                <div class="score-circle">
                    <div class="score-inner">
                        <div class="score-value" id="finalScore">0</div>
                        <div class="score-label">out of 100</div>
                    </div>
                </div>

                <div class="results-details">
                    <div class="result-card">
                        <h4>Correct Answers</h4>
                        <p id="correctCount">0</p>
                    </div>
                    <div class="result-card">
                        <h4>Wrong Answers</h4>
                        <p id="wrongCount">0</p>
                    </div>
                    <div class="result-card">
                        <h4>Unanswered</h4>
                        <p id="unansweredCount">0</p>
                    </div>
                    <div class="result-card">
                        <h4>Accuracy</h4>
                        <p id="accuracy">0%</p>
                    </div>
                    <div class="result-card">
                        <h4>General Aptitude</h4>
                        <p id="gaScore">0/15</p>
                    </div>
                    <div class="result-card">
                        <h4>Technical Section</h4>
                        <p id="technicalScore">0/85</p>
                    </div>
                </div>

                <div class="chart-container">
                    <canvas id="resultsChart"></canvas>
                </div>

                <div style="text-align: center; margin-top: 20px;">
                    <button class="btn btn-primary" onclick="reviewAnswers()">📊 Review Answers</button>
                    <button class="btn btn-secondary" onclick="location.reload()">🔄 Restart Exam</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Question Data - GATE CS 2024
        const questionData = [
            // Q1-Q5: GA (1 mark each)
            {
                id: 1,
                section: "GA",
                marks: 1,
                type: "MCQ",
                question: "If '→' denotes increasing order of intensity, then the meaning of the words [dry → arid → parched] is analogous to [diet → fast → ________]. Which one of the given options is appropriate to fill the blank?",
                options: ["starve", "reject", "feast", "deny"],
                correctAnswer: "A"
            },
            {
                id: 2,
                section: "GA",
                marks: 1,
                type: "MCQ",
                question: "If two distinct non-zero real variables x and y are such that (x + y) is proportional to (x − y) then the value of x/y",
                options: ["depends on xy", "depends only on x and not on y", "depends only on y and not on x", "is a constant"],
                correctAnswer: "D"
            },
            {
                id: 3,
                section: "GA",
                marks: 1,
                type: "MCQ",
                question: "Consider the following sample of numbers: 9, 18, 11, 14, 15, 17, 10, 69, 11, 13. The median of the sample is",
                options: ["13.5", "14", "11", "18.7"],
                correctAnswer: "B"
            },
            {
                id: 4,
                section: "GA",
                marks: 1,
                type: "MCQ",
                question: "The number of coins of ₹1, ₹5, and ₹10 denominations that a person has are in the ratio 5:3:13. Of the total amount, the percentage of money in ₹5 coins is",
                options: ["21%", "14 2/7%", "10%", "30%"],
                correctAnswer: "B"
            },
            {
                id: 5,
                section: "GA",
                marks: 1,
                type: "MCQ",
                question: "For positive non-zero real variables p and q, if log(p² + q²) = log p + log q + 2 log 3, then the value of (p⁴ + q⁴)/(p²q²) is",
                options: ["79", "81", "9", "83"],
                correctAnswer: "B"
            },
            // Q6-Q10: GA (2 marks each)
            {
                id: 6,
                section: "GA",
                marks: 2,
                type: "MCQ",
                question: "In the given text, the blanks are numbered (i)−(iv). Select the best match for all the blanks. Steve was advised to keep his head (i) before heading (ii) to bat; for, while he had a head (iii) batting, he could only do so with a cool head (iv) his shoulders.",
                options: [
                    "(i) down (ii) down (iii) on (iv) for",
                    "(i) on (ii) down (iii) for (iv) on",
                    "(i) down (ii) out (iii) for (iv) on",
                    "(i) on (ii) out (iii) on (iv) for"
                ],
                correctAnswer: "C"
            },
            {
                id: 7,
                section: "GA",
                marks: 2,
                type: "MCQ",
                question: "A rectangular paper sheet of dimensions 54 cm × 4 cm is taken. The two longer edges of the sheet are joined together to create a cylindrical tube. A cube whose surface area is equal to the area of the sheet is also taken. Then, the ratio of the volume of the cylindrical tube to the volume of the cube is",
                options: ["1/π", "2/π", "3/π", "4/π"],
                correctAnswer: "C"
            },
            {
                id: 8,
                section: "GA",
                marks: 2,
                type: "MCQ",
                question: "The pie chart presents the percentage contribution of different macronutrients to a typical 2,000 kcal diet. The typical energy density (kcal/g) is: Carbohydrates=4, Proteins=4, Unsaturated fat=9, Saturated fat=9, Trans fat=9. Total fat (all three types), in grams, this person consumes is",
                options: ["44.4", "77.8", "100", "3,600"],
                correctAnswer: "C"
            },
            {
                id: 9,
                section: "GA",
                marks: 2,
                type: "MCQ",
                question: "A rectangular paper of 20 cm × 8 cm is folded 3 times. Each fold is made along the line of symmetry, which is perpendicular to its long edge. The perimeter of the final folded sheet (in cm) is",
                options: ["18", "24", "20", "21"],
                correctAnswer: "A"
            },
            {
                id: 10,
                section: "GA",
                marks: 2,
                type: "MCQ",
                question: "The least number of squares to be added in the figure to make AB a line of symmetry is",
                options: ["6", "4", "5", "7"],
                correctAnswer: "B"
            },
            // Q11-Q35: Technical (1 mark each)
            {
                id: 11,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Let f: ℝ → ℝ be a function such that f(x) = max{x, x³}, x ∈ ℝ, where ℝ is the set of all real numbers. The set of all points where f(x) is NOT differentiable is",
                options: ["{−1, 1, 2}", "{−2, −1, 1}", "{0, 1}", "{−1, 0, 1}"],
                correctAnswer: "D"
            },
            {
                id: 12,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "The product of all eigenvalues of the matrix [[1, 2, 3], [4, 5, 6], [7, 8, 9]] is",
                options: ["−1", "0", "1", "2"],
                correctAnswer: "B"
            },
            {
                id: 13,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Consider a system that uses 5 bits for representing signed integers in 2's complement format. In this system, two integers A and B are represented as A=01010 and B=11010. Which one of the following operations will result in either an arithmetic overflow or an arithmetic underflow?",
                options: ["A + B", "A − B", "B − A", "2 ∗ B"],
                correctAnswer: "C"
            },
            {
                id: 14,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Consider a permutation sampled uniformly at random from the set of all permutations of {1, 2, 3, ⋯, n} for some n ≥ 4. Let X be the event that 1 occurs before 2 in the permutation, and Y the event that 3 occurs before 4. Which one of the following statements is TRUE?",
                options: [
                    "The events X and Y are mutually exclusive",
                    "The events X and Y are independent",
                    "Either event X or Y must occur",
                    "Event X is more likely than event Y"
                ],
                correctAnswer: "B"
            },
            {
                id: 15,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Which one of the following statements is FALSE?",
                options: [
                    "In the cycle stealing mode of DMA, one word of data is transferred between an I/O device and main memory in a stolen cycle",
                    "For bulk data transfer, the burst mode of DMA has a higher throughput than the cycle stealing mode",
                    "Programmed I/O mechanism has a better CPU utilization than the interrupt driven I/O mechanism",
                    "The CPU can start executing an interrupt service routine faster with vectored interrupts than with non-vectored interrupts"
                ],
                correctAnswer: "C"
            },
            {
                id: 16,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "A user starts browsing a webpage. The browser opens a single TCP connection. The webpage consists of a top-level index page with multiple embedded image objects. Which one of the following is the CORRECT chronological order of packets: (i) HTTP GET for index, (ii) DNS request, (iii) HTTP GET for image, (iv) TCP SYN?",
                options: ["(iv), (ii), (iii), (i)", "(ii), (iv), (iii), (i)", "(ii), (iv), (i), (iii)", "(iv), (ii), (i), (iii)"],
                correctAnswer: "C"
            },
            {
                id: 17,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Given an integer array of size N, we want to check if the array is sorted. An algorithm makes a single pass comparing each element only with its adjacent elements. The worst-case time complexity is",
                options: ["both O(N) and Ω(N)", "O(N) but not Ω(N)", "Ω(N) but not O(N)", "neither O(N) nor Ω(N)"],
                correctAnswer: "A"
            },
            {
                id: 18,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Consider the C program: int main(){ int a = 6; int b = 0; while(a < 10) { a = a / 12 + 1; a += b;} printf(\"%d\", a); return 0;} Which statement is CORRECT?",
                options: ["The program prints 9 as output", "The program prints 10 as output", "The program gets stuck in an infinite loop", "The program prints 6 as output"],
                correctAnswer: "C"
            },
            {
                id: 19,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Consider the C program with recursive function fX() that reads characters and prints them. Input is 1234 followed by newline. Which statement is CORRECT?",
                options: ["The program will not terminate", "The program will terminate with no output", "The program will terminate with 4321 as output", "The program will terminate with 1234 as output"],
                correctAnswer: "C"
            },
            {
                id: 20,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "Let S be: \"Instructors teach courses. Students register for courses. Courses are allocated classrooms. Instructors guide students.\" Which ER diagram CORRECTLY represents S?",
                options: ["(i)", "(ii)", "(iii)", "(iv)"],
                correctAnswer: "C"
            },
            {
                id: 21,
                section: "Technical",
                marks: 1,
                type: "MCQ",
                question: "In a B+ tree, the requirement of at least half-full (50%) node occupancy is relaxed for which case?",
                options: ["Only the root node", "All leaf nodes", "All internal nodes", "Only the leftmost leaf node"],
                correctAnswer: "A"
            },
            {
                id: 22,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "Which of the following statements about a relation R in first normal form (1NF) is/are TRUE?",
                options: [
                    "R can have a multi-attribute key",
                    "R cannot have a foreign key",
                    "R cannot have a composite attribute",
                    "R cannot have more than one candidate key"
                ],
                correctAnswer: ["A", "C"]
            },
            {
                id: 23,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "Let L₁, L₂ be two regular languages and L₃ a language which is not regular. Which of the following is/are always TRUE?",
                options: [
                    "L₁ = L₂ if and only if L₁ ∩ L₂̅ = ∅",
                    "L₁ ∪ L₃ is not regular",
                    "L₃̅ is not regular",
                    "L₁̅ ∪ L₂̅ is regular"
                ],
                correctAnswer: ["A", "D"]
            },
            {
                id: 24,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "Which of the following statements about threads is/are TRUE?",
                options: [
                    "Threads can only be implemented in kernel space",
                    "Each thread has its own file descriptor table for open files",
                    "All the threads belonging to a process share a common stack",
                    "Threads belonging to a process are by default not protected from each other"
                ],
                correctAnswer: ["D"]
            },
            {
                id: 25,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "Which of the following process state transitions is/are NOT possible?",
                options: ["Running to Ready", "Waiting to Running", "Ready to Waiting", "Running to Terminated"],
                correctAnswer: ["B", "C"]
            },
            {
                id: 26,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "Which of the following is/are Bottom-Up Parser(s)?",
                options: ["Shift-reduce Parser", "Predictive Parser", "LL(1) Parser", "LR Parser"],
                correctAnswer: ["A", "D"]
            },
            {
                id: 27,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "Let A and B be two events with P(A) = 0.3, P(B) = 0.5, and P(A ∩ B) = 0.1. Which of the following is/are TRUE?",
                options: [
                    "The two events A and B are independent",
                    "P(A ∪ B) = 0.7",
                    "P(A ∩ Bᶜ) = 0.2, where Bᶜ is the complement of B",
                    "P(Aᶜ ∩ Bᶜ) = 0.4, where Aᶜ and Bᶜ are the complements of A and B"
                ],
                correctAnswer: ["B", "C"]
            },
            {
                id: 28,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "Consider the circuit X → AND gate with NOT gate on one input. Which of the following is/are CORRECT?",
                options: [
                    "With no propagation delays, the output Y is always logic Zero",
                    "With no propagation delays, the output Y is always logic One",
                    "With propagation delays, Y can have transient logic One after X transitions 0→1",
                    "With propagation delays, Y can have transient logic Zero after X transitions 1→0"
                ],
                correctAnswer: ["A", "C"]
            },
            {
                id: 29,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "TCP client P establishes connection to server Q. Let Nₚ be sequence number in SYN from P to Q. Let Nᵩ be acknowledgement in SYN ACK from Q to P. Which is/are CORRECT?",
                options: [
                    "The sequence number Nₚ is chosen randomly by P",
                    "The sequence number Nₚ is always 0 for a new connection",
                    "The acknowledgement number Nᵩ is equal to Nₚ",
                    "The acknowledgement number Nᵩ is equal to Nₚ + 1"
                ],
                correctAnswer: ["A", "D"]
            },
            {
                id: 30,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "Consider a 5-stage pipelined processor (IF, ID, EX, MEM, WB). Which statements about forwarding is/are CORRECT?",
                options: [
                    "Forwarding means result from source stage of earlier instruction is passed to destination stage of later instruction",
                    "Data from output of MEM can be passed to input of EX of next instruction",
                    "Forwarding cannot prevent all pipeline stalls",
                    "Forwarding does not require any extra hardware"
                ],
                correctAnswer: ["A", "B", "C"]
            },
            {
                id: 31,
                section: "Technical",
                marks: 1,
                type: "MSQ",
                question: "Which fields is/are modified in IP header of packet going out of NAT device from internal to external network?",
                options: ["Source IP", "Destination IP", "Header Checksum", "Total Length"],
                correctAnswer: ["A", "C"]
            },
            {
                id: 32,
                section: "Technical",
                marks: 1,
                type: "NAT",
                question: "Let A and B be non-empty finite sets such that there exist one-to-one and onto functions (i) from A to B and (ii) from A × A to A ∪ B. The number of possible values of |A| is",
                correctAnswer: 1,
                tolerance: 0
            },
            {
                id: 33,
                section: "Technical",
                marks: 1,
                type: "NAT",
                question: "Consider operator precedence: + (Highest, Left), − (High, Right), ∗ (Medium, Right), / (Low, Right). The value of expression 3 + 1 + 5 ∗ 2 / 7 + 2 − 4 − 7 − 6 / 2 is",
                correctAnswer: 1,
                tolerance: 0
            },
            {
                id: 34,
                section: "Technical",
                marks: 1,
                type: "NAT",
                question: "The number of spanning trees in a complete graph of 4 vertices labelled A, B, C, and D is",
                correctAnswer: 16,
                tolerance: 0
            },
            {
                id: 35,
                section: "Technical",
                marks: 1,
                type: "NAT",
                question: "Consider relations R(A,B) and S(A,C). R has tuples (10,20), (20,30), (30,40), (30,50), (50,95). S has tuples (10,90), (30,45), (40,80). The total number of tuples from σ_{B<C}(R ⋈_{R.A=S.A} S) is",
                correctAnswer: 3,
                tolerance: 0
            },
            // Q36-Q65: Technical (2 marks each)
            {
                id: 36,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "A file of size 10⁶ bytes is split into 10³ byte chunks and sent over P—Q—R. Both links have bandwidth 10⁶ bits/sec. P starts transmitting at t = 0. Time at which R receives all chunks (rounded to 3 decimals) is",
                options: ["8.000", "8.008", "15.992", "16.000"],
                correctAnswer: "D"
            },
            {
                id: 37,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "Consider the syntax-directed definition computing S.val for input \"MMLK\". Which value is CORRECT?",
                options: ["45", "50", "55", "65"],
                correctAnswer: "B"
            },
            {
                id: 38,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "Consider grammar G with incomplete productions. FIRST(S) = {c, d, f}, FIRST(T) = {a, b, ε}, FIRST(R) = {c, ε}. Which option CORRECTLY fills incomplete productions?",
                options: [
                    "(1) S → Rf (2) T → ε (3) R → cTR",
                    "(1) S → fR (2) T → ε (3) R → cTR",
                    "(1) S → fR (2) T → cT (3) R → cR",
                    "(1) S → Rf (2) T → cT (3) R → cR"
                ],
                correctAnswer: "B"
            },
            {
                id: 39,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "Consider pseudo-code with basic blocks. Which option CORRECTLY specifies number of basic blocks and instructions in largest block?",
                options: ["6 and 6", "6 and 7", "7 and 7", "7 and 6"],
                correctAnswer: "A"
            },
            {
                id: 40,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "Two threads T1 and T2 update shared variables a and b (initially a = b = 1). T1: a=a+1; b=b+1; T2: b=2*b; a=2*a; Which option lists all possible (a,b) combinations?",
                options: [
                    "(a = 4, b = 4); (a = 3, b = 3); (a = 4, b = 3)",
                    "(a = 3, b = 4); (a = 4, b = 3); (a = 3, b = 3)",
                    "(a = 4, b = 4); (a = 4, b = 3); (a = 3, b = 4)",
                    "(a = 2, b = 2); (a = 2, b = 3); (a = 3, b = 4)"
                ],
                correctAnswer: "C"
            },
            {
                id: 41,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "Array [82, 101, 90, 11, 111, 75, 33, 131, 44, 93] is heapified. First three elements are",
                options: ["82, 90, 101", "82, 11, 93", "131, 11, 93", "131, 111, 90"],
                correctAnswer: "D"
            },
            {
                id: 42,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "Consider recurrence T(n) = √nT(√n) + n for n ≥ 1, T(1) = 1. Which is CORRECT?",
                options: ["T(n) = Θ(n log log n)", "T(n) = Θ(n log n)", "T(n) = Θ(n² log n)", "T(n) = Θ(n² log log n)"],
                correctAnswer: "B"
            },
            {
                id: 43,
                section: "Technical",
                marks: 2,
                type: "MCQ",
                question: "Binary min-heap contains 105 distinct elements. Let k be index of maximum element. Number of possible values of k is",
                options: ["53", "52", "27", "1"],
                correctAnswer: "A"
            },
            {
                id: 44,
                section: "Technical",
                marks: 2,
                type: "MSQ",
                question: "Symbol → indicates functional dependency. Which of the following is/are TRUE?",
                options: [
                    "(X,Y) → (Z,W) implies X → (Z,W)",
                    "(X,Y) → (Z,W) implies (X,Y) → Z",
                    "((X,Y) → Z and W → Y) implies (X,W) → Z",
                    "(X → Y and Y → Z) implies X → Z"
                ],
                correctAnswer: ["B", "C", "D"]
            },
            {
                id: 45,
                section: "Technical",
                marks: 2,
                type: "MSQ",
                question: "Let G be directed graph and T a DFS spanning tree rooted at v. T is also BFS tree rooted at v. Which is/are TRUE for every such G and T?",
                options: [
                    "There are no back-edges in G with respect to T",
                    "There are no cross-edges in G with respect to T",
                    "There are no forward-edges in G with respect to T",
                    "The only edges in G are edges in T"
                ],
                correctAnswer: ["A", "B", "C"]
            },
            {
                id: 46,
                section: "Technical",
                marks: 2,
                type: "MSQ",
                question: "Schedule S: r₁(z); w₁(z); r₂(x); r₃(y); w₃(y); r₂(y); r₂(y); w₂(x); w₂(y); Which schedules are conflict equivalent to S?",
                options: ["T₁T₂T₃", "T₁T₃T₂", "T₃T₂T₁", "T₃T₁T₂"],
                correctAnswer: ["A", "B"]
            },
            {
                id: 47,
                section: "Technical",
                marks: 2,
                type: "MSQ",
                question: "Boolean expression F(X,Y,Z) = Σ(3,5,6,7). Which is/are CORRECT?",
                options: [
                    "F(X,Y,Z) = Π(0,1,2,4)",
                    "F(X,Y,Z) = XY + YZ + XZ",
                    "F(X,Y,Z) is independent of input Y",
                    "F(X,Y,Z) is independent of input X"
                ],
                correctAnswer: ["A", "B"]
            },
            {
                id: 48,
                section: "Technical",
                marks: 2,
                type: "MSQ",
                question: "C function: int f(int x, int y) { for (int i=0; i<y; i++) { x=x+x+y; } return x; } Which is/are TRUE?",
                options: [
                    "If x=20, y=10, return value > 2²⁰",
                    "If x=20, y=20, return value > 2²⁰",
                    "If x=20, y=10, return value < 2¹⁰",
                    "If x=10, y=20, return value > 2²⁰"
                ],
                correctAnswer: ["A", "D"]
            },
            {
                id: 49,
                section: "Technical",
                marks: 2,
                type: "MSQ",
                question: "Let A be n × m matrix where m > n. For system Ax = 0, which is/are TRUE?",
                options: [
                    "There exist at least m − n linearly independent solutions",
                    "There exist m − n linearly independent vectors such that every solution is their linear combination",
                    "There exists non-zero solution with at least m − n variables = 0",
                    "There exists solution with at least n variables non-zero"
                ],
                correctAnswer: ["A", "B", "C"]
            },
            {
                id: 50,
                section: "Technical",
                marks: 2,
                type: "MSQ",
                question: "5-state DFA M accepts language L(M) ⊂ (0 + 1)*. Which statements is/are FALSE?",
                options: [
                    "States 2 and 4 are distinguishable in M",
                    "States 3 and 4 are distinguishable in M",
                    "States 2 and 5 are distinguishable in M",
                    "Any string w with n₀(w) = n₁(w) is in L(M)"
                ],
                correctAnswer: ["B", "C"]
            },
            {
                id: 51,
                section: "Technical",
                marks: 2,
                type: "MSQ",
                question: "Graph G has n vertices and chromatic number k. Which is/are always TRUE?",
                options: [
                    "G contains a complete subgraph with k vertices",
                    "G contains an independent set of size at least n/k",
                    "G contains at least k(k − 1)/2 edges",
                    "G contains a vertex of degree at least k"
                ],
                correctAnswer: ["B"]
            },
            {
                id: 52,
                section: "Technical",
                marks: 2,
                type: "MSQ",
                question: "Operators a ◊ b = a + 2b, a□b = ab. Which is/are TRUE?",
                options: [
                    "Operator ◊ obeys the associative law",
                    "Operator □ obeys the associative law",
                    "Operator ◊ over □ obeys the distributive law",
                    "Operator □ over ◊ obeys the distributive law"
                ],
                correctAnswer: ["B", "D"]
            },
            {
                id: 53,
                section: "Technical",
                marks: 2,
                type: "MSQ",
                question: "Set-associative cache architectures: WBC (write back) and WTC (write through), both use LRU. Which is/are TRUE?",
                options: [
                    "Read miss in WBC never evicts a dirty block",
                    "Read miss in WTC never triggers write back to main memory",
                    "Write hit in WBC can modify dirty bit of cache block",
                    "Write miss in WTC always writes victim block to main memory before loading"
                ],
                correctAnswer: ["B", "C"]
            },
            {
                id: 54,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "512 GB hard disk with 32 storage surfaces, 4096 sectors per track, each sector holds 1024 bytes. Number of cylinders is",
                correctAnswer: 4194304,
                tolerance: 0
            },
            {
                id: 55,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Baseline execution time is 100 ns on 2 GHz single core. 90% code can be parallelized. Overhead for additional core is 10 ns. Number of cores that minimize execution time is",
                correctAnswer: 3,
                tolerance: 0
            },
            {
                id: 56,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Program has 25% load/store instructions. Ideal CPI = 2. Instruction cache miss rate = 2%, data cache miss rate = 8%, miss penalty = 100 cycles. Speedup with perfect cache (rounded to 2 decimals) is",
                correctAnswer: 2.17,
                tolerance: 0.01
            },
            {
                id: 57,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Code: int x = 3; while(x > 0) { fork(); printf(\"hello\"); wait(NULL); x--; }. Total number of times printf executes is",
                correctAnswer: 14,
                tolerance: 0
            },
            {
                id: 58,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Forwarding table has prefixes with next hops R1-R4. Router forwards 20 packets each to hosts 10.1.1.16, 10.1.1.72, 10.1.1.132, 10.1.1.191, 10.1.1.205. Number forwarded via R2 is",
                correctAnswer: 40,
                tolerance: 0
            },
            {
                id: 59,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "CFG G in Chomsky Normal Form with 10 variables. String w = a³⁰b³⁰c³⁰ is derivable from S. Number of steps in derivation S →* w is",
                correctAnswer: 179,
                tolerance: 0
            },
            {
                id: 60,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "DFS forest of undirected graph G with 100 vertices has 40 edges. Number of connected components is",
                correctAnswer: 60,
                tolerance: 0
            },
            {
                id: 61,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Regular expressions: r = 0* + 1*, s = 01* + 10*. Total strings of length ≤ 5 that are neither in r nor in s is",
                correctAnswer: 6,
                tolerance: 0
            },
            {
                id: 62,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Memory management with page size 2 KB. Pages 0,1,2,3 stored in frames 1,3,2,0. Physical address corresponding to virtual address 2500 is",
                correctAnswer: 4596,
                tolerance: 0
            },
            {
                id: 63,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Bag has 10 red and 15 blue balls. Two balls drawn without replacement. Given first ball is red, probability both are red (rounded to 3 decimals) is",
                correctAnswer: 0.375,
                tolerance: 0.001
            },
            {
                id: 64,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "Digital logic circuit with three 2-to-1 multiplexers. For inputs X1=1, X2=1, X3=0, X4=0, number of (A,B,C) combinations giving Y=1 is",
                correctAnswer: 4,
                tolerance: 0
            },
            {
                id: 65,
                section: "Technical",
                marks: 2,
                type: "NAT",
                question: "IP datagram of 1420 bytes (20 byte header) over two links. First link MTU=542 bytes, second link MTU=360 bytes. Number of fragments delivered at receiver is",
                correctAnswer: 5,
                tolerance: 0
            }
        ];

        // State Management
        let currentQuestion = 0;
        let userAnswers = {};
        let markedQuestions = new Set();
        let visitedQuestions = new Set();
        let examStarted = false;
        let examSubmitted = false;
        let startTime;
        let timerInterval;

        // Start Exam
        function startExam() {
            document.getElementById('instructionsScreen').style.display = 'none';
            document.getElementById('examScreen').style.display = 'block';
            examStarted = true;
            startTime = new Date();
            startTimer();
            initializeQuestionPalette();
            showQuestion(0);
        }

        // Timer
        function startTimer() {
            let timeLeft = 180 * 60; // 3 hours in seconds

            timerInterval = setInterval(() => {
                timeLeft--;

                const hours = Math.floor(timeLeft / 3600);
                const minutes = Math.floor((timeLeft % 3600) / 60);
                const seconds = timeLeft % 60;

                document.getElementById('timer').textContent = 
                    `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

                if (timeLeft <= 0) {
                    clearInterval(timerInterval);
                    submitExam();
                }
            }, 1000);
        }

        // Initialize Question Palette
        function initializeQuestionPalette() {
            const palette = document.getElementById('questionPalette');
            palette.innerHTML = '';

            for (let i = 0; i < questionData.length; i++) {
                const btn = document.createElement('button');
                btn.className = 'palette-btn';
                btn.textContent = i + 1;
                btn.onclick = () => showQuestion(i);
                palette.appendChild(btn);
            }
        }

        // Show Question
        function showQuestion(index) {
            currentQuestion = index;
            visitedQuestions.add(index);

            const question = questionData[index];
            
            document.getElementById('questionNumber').textContent = `Question ${index + 1} of 65`;
            document.getElementById('questionMarks').textContent = `${question.marks} Mark${question.marks > 1 ? 's' : ''}`;
            document.getElementById('questionText').textContent = question.question;

            const optionsContainer = document.getElementById('optionsContainer');
            optionsContainer.innerHTML = '';

            if (question.type === 'MCQ') {
                optionsContainer.innerHTML = `<div class="options" id="options"></div>`;
                const optionsDiv = document.getElementById('options');
                
                question.options.forEach((option, i) => {
                    const optionLetter = String.fromCharCode(65 + i);
                    const isSelected = userAnswers[index] === optionLetter;
                    
                    const optionDiv = document.createElement('div');
                    optionDiv.className = `option ${isSelected ? 'selected' : ''}`;
                    optionDiv.onclick = () => selectOption(index, optionLetter);
                    
                    optionDiv.innerHTML = `
                        <input type="radio" name="answer" value="${optionLetter}" ${isSelected ? 'checked' : ''}>
                        <label>(${optionLetter}) ${option}</label>
                    `;
                    
                    optionsDiv.appendChild(optionDiv);
                });
            } else if (question.type === 'MSQ') {
                optionsContainer.innerHTML = `<div class="options" id="options"></div>`;
                const optionsDiv = document.getElementById('options');
                
                question.options.forEach((option, i) => {
                    const optionLetter = String.fromCharCode(65 + i);
                    const answers = userAnswers[index] || [];
                    const isSelected = answers.includes(optionLetter);
                    
                    const optionDiv = document.createElement('div');
                    optionDiv.className = `option ${isSelected ? 'selected' : ''}`;
                    optionDiv.onclick = () => selectMultipleOption(index, optionLetter);
                    
                    optionDiv.innerHTML = `
                        <input type="checkbox" value="${optionLetter}" ${isSelected ? 'checked' : ''}>
                        <label>(${optionLetter}) ${option}</label>
                    `;
                    
                    optionsDiv.appendChild(optionDiv);
                });
            } else if (question.type === 'NAT') {
                const currentAnswer = userAnswers[index] || '';
                optionsContainer.innerHTML = `
                    <label style="font-weight: 600; display: block; margin-bottom: 10px;">Enter your numerical answer:</label>
                    <input type="number" step="any" class="numerical-input" id="numericalAnswer" 
                           placeholder="Enter numerical answer" value="${currentAnswer}"
                           onchange="saveNumericalAnswer(${index})">
                `;
            }

            updateQuestionPalette();
            updateStats();
        }

        // Select Option (MCQ)
        function selectOption(index, option) {
            userAnswers[index] = option;
            showQuestion(index);
        }

        // Select Multiple Options (MSQ)
        function selectMultipleOption(index, option) {
            if (!userAnswers[index]) {
                userAnswers[index] = [];
            }
            
            const answers = userAnswers[index];
            const idx = answers.indexOf(option);
            
            if (idx > -1) {
                answers.splice(idx, 1);
            } else {
                answers.push(option);
            }
            
            if (answers.length === 0) {
                delete userAnswers[index];
            }
            
            showQuestion(index);
        }

        // Save Numerical Answer
        function saveNumericalAnswer(index) {
            const value = document.getElementById('numericalAnswer').value;
            if (value) {
                userAnswers[index] = parseFloat(value);
            } else {
                delete userAnswers[index];
            }
            updateQuestionPalette();
            updateStats();
        }

        // Navigation
        function previousQuestion() {
            if (currentQuestion > 0) {
                showQuestion(currentQuestion - 1);
            }
        }

        function nextQuestion() {
            if (currentQuestion < questionData.length - 1) {
                showQuestion(currentQuestion + 1);
            }
        }

        function markForReview() {
            if (markedQuestions.has(currentQuestion)) {
                markedQuestions.delete(currentQuestion);
            } else {
                markedQuestions.add(currentQuestion);
            }
            updateQuestionPalette();
            updateStats();
        }

        function clearResponse() {
            delete userAnswers[currentQuestion];
            showQuestion(currentQuestion);
        }

        // Update Question Palette
        function updateQuestionPalette() {
            const buttons = document.querySelectorAll('.palette-btn');
            
            buttons.forEach((btn, index) => {
                btn.className = 'palette-btn';
                
                if (index === currentQuestion) {
                    btn.classList.add('current');
                } else if (userAnswers.hasOwnProperty(index)) {
                    btn.classList.add('answered');
                } else if (markedQuestions.has(index)) {
                    btn.classList.add('marked');
                }
            });
        }

        // Update Statistics
        function updateStats() {
            const answered = Object.keys(userAnswers).length;
            const marked = markedQuestions.size;
            const visited = visitedQuestions.size;
            const notVisited = questionData.length - visited;

            document.getElementById('answeredCount').textContent = answered;
            document.getElementById('markedCount').textContent = marked;
            document.getElementById('visitedCount').textContent = visited;
            document.getElementById('notVisitedCount').textContent = notVisited;

            const progress = (answered / questionData.length) * 100;
            document.getElementById('progressBar').style.width = progress + '%';
        }

        // Filter Questions
        function filterQuestions(filter) {
            const tabs = document.querySelectorAll('.nav-tab');
            tabs.forEach(tab => tab.classList.remove('active'));
            event.target.classList.add('active');

            const buttons = document.querySelectorAll('.palette-btn');
            
            buttons.forEach((btn, index) => {
                const question = questionData[index];
                let show = false;

                switch(filter) {
                    case 'all':
                        show = true;
                        break;
                    case 'ga':
                        show = question.section === 'GA';
                        break;
                    case 'technical':
                        show = question.section === 'Technical';
                        break;
                    case 'answered':
                        show = userAnswers.hasOwnProperty(index);
                        break;
                    case 'unanswered':
                        show = !userAnswers.hasOwnProperty(index);
                        break;
                    case 'marked':
                        show = markedQuestions.has(index);
                        break;
                }

                btn.style.display = show ? 'block' : 'none';
            });
        }

        // Submit Exam
        function confirmSubmit() {
            const answered = Object.keys(userAnswers).length;
            const unanswered = questionData.length - answered;
            
            if (confirm(`You have answered ${answered} questions and ${unanswered} questions are unanswered. Do you want to submit the exam?`)) {
                submitExam();
            }
        }

        function submitExam() {
            examSubmitted = true;
            clearInterval(timerInterval);
            calculateResults();
        }

        // Calculate Results
        function calculateResults() {
            let totalScore = 0;
            let correctCount = 0;
            let wrongCount = 0;
            let gaScore = 0;
            let technicalScore = 0;

            questionData.forEach((question, index) => {
                const userAnswer = userAnswers[index];
                
                if (userAnswer !== undefined) {
                    let isCorrect = false;

                    if (question.type === 'MCQ') {
                        isCorrect = userAnswer === question.correctAnswer;
                    } else if (question.type === 'MSQ') {
                        const correctAnswers = question.correctAnswer.sort();
                        const userAnswersSorted = (userAnswer || []).sort();
                        isCorrect = JSON.stringify(correctAnswers) === JSON.stringify(userAnswersSorted);
                    } else if (question.type === 'NAT') {
                        const diff = Math.abs(userAnswer - question.correctAnswer);
                        isCorrect = diff <= (question.tolerance || 0);
                    }

                    if (isCorrect) {
                        correctCount++;
                        totalScore += question.marks;
                        
                        if (question.section === 'GA') {
                            gaScore += question.marks;
                        } else {
                            technicalScore += question.marks;
                        }
                    } else {
                        wrongCount++;
                        
                        // Negative marking only for MCQ
                        if (question.type === 'MCQ') {
                            if (question.marks === 1) {
                                totalScore -= 1/3;
                            } else if (question.marks === 2) {
                                totalScore -= 2/3;
                            }
                        }
                    }
                }
            });

            const unansweredCount = questionData.length - Object.keys(userAnswers).length;
            const attempted = correctCount + wrongCount;
            const accuracy = attempted > 0 ? ((correctCount / attempted) * 100).toFixed(2) : 0;

            // Display Results
            document.getElementById('finalScore').textContent = totalScore.toFixed(2);
            document.getElementById('correctCount').textContent = correctCount;
            document.getElementById('wrongCount').textContent = wrongCount;
            document.getElementById('unansweredCount').textContent = unansweredCount;
            document.getElementById('accuracy').textContent = accuracy + '%';
            document.getElementById('gaScore').textContent = gaScore.toFixed(2) + '/15';
            document.getElementById('technicalScore').textContent = technicalScore.toFixed(2) + '/85';

            // Show Results Modal
            document.getElementById('resultsModal').classList.add('active');

            // Create Chart
            createResultsChart(correctCount, wrongCount, unansweredCount);
        }

        // Create Results Chart
        function createResultsChart(correct, wrong, unanswered) {
            const ctx = document.getElementById('resultsChart').getContext('2d');
            
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Correct', 'Wrong', 'Unanswered'],
                    datasets: [{
                        data: [correct, wrong, unanswered],
                        backgroundColor: ['#10b981', '#ef4444', '#6b7280'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }

        // Review Answers
        function reviewAnswers() {
            document.getElementById('resultsModal').classList.remove('active');
            showQuestion(0);
        }
    </script>
</body>
</html>