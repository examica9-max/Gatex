<?php
/* === PERSISTENT SESSION PROTECTION === */

// Start session with 1 year lifetime
if (session_status() === PHP_SESSION_NONE) {
    ini_set("session.gc_maxlifetime", 31536000); // 1 year
    session_set_cookie_params(31536000);
    session_start();
}

// Check if user has premium access
if (!isset($_SESSION["premium_access"]) || $_SESSION["premium_access"] !== true) {
    header("Location: ../../index.php");
    exit;
}

// Validate code has not expired
if (isset($_SESSION["code_expiry"])) {
    $expiry = strtotime($_SESSION["code_expiry"]);
    $today = strtotime(date("Y-m-d"));
    
    if ($today > $expiry) {
        session_destroy();
        header("Location: ../../index.php?error=expired");
        exit;
    }
}

/* === END PERSISTENT SESSION PROTECTION === */
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎓 GATE CS 2023 - IIT Kanpur</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .instructions-screen {
            max-width: 900px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            animation: fadeIn 0.5s ease-in;
        }

        .exam-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .exam-header h1 {
            font-size: 2.5em;
            background: linear-gradient(135deg, #6366f1, #ec4899);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }

        .exam-header h2 {
            font-size: 1.5em;
            color: #555;
            font-weight: 500;
        }

        .exam-header p {
            color: #777;
            margin-top: 5px;
        }

        .info-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }

        .info-card {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            color: white;
            box-shadow: 0 5px 15px rgba(99, 102, 241, 0.3);
        }

        .info-card h3 {
            font-size: 2em;
            margin-bottom: 5px;
        }

        .info-card p {
            font-size: 0.9em;
            opacity: 0.9;
        }

        .instructions-content {
            background: #f8f9fa;
            padding: 25px;
            border-radius: 15px;
            margin: 20px 0;
        }

        .instructions-content h3 {
            color: #6366f1;
            margin-bottom: 15px;
            font-size: 1.3em;
        }

        .instructions-content ul {
            list-style: none;
            padding: 0;
        }

        .instructions-content li {
            padding: 10px 0;
            padding-left: 25px;
            position: relative;
            color: #444;
            line-height: 1.6;
        }

        .instructions-content li:before {
            content: "✓";
            position: absolute;
            left: 0;
            color: #10b981;
            font-weight: bold;
        }

        .legend {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .legend-color {
            width: 30px;
            height: 30px;
            border-radius: 8px;
            border: 2px solid #ddd;
        }

        .start-btn {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            border: none;
            padding: 15px 50px;
            font-size: 1.2em;
            border-radius: 50px;
            cursor: pointer;
            display: block;
            margin: 30px auto;
            box-shadow: 0 5px 15px rgba(16, 185, 129, 0.4);
            transition: transform 0.3s ease;
        }

        .start-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(16, 185, 129, 0.5);
        }

        .exam-screen {
            display: none;
            max-width: 1400px;
            margin: 0 auto;
        }

        .exam-nav {
            background: white;
            padding: 15px 30px;
            border-radius: 15px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            flex-wrap: wrap;
            gap: 15px;
        }

        .exam-title {
            font-size: 1.5em;
            color: #6366f1;
            font-weight: 600;
        }

        .timer {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
            padding: 10px 25px;
            border-radius: 50px;
            font-size: 1.3em;
            font-weight: bold;
            box-shadow: 0 5px 15px rgba(239, 68, 68, 0.3);
        }

        .exam-content {
            display: grid;
            grid-template-columns: 1fr 400px;
            gap: 20px;
        }

        .question-panel {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            min-height: 500px;
        }

        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e5e7eb;
            flex-wrap: wrap;
            gap: 10px;
        }

        .question-number {
            font-size: 1.3em;
            color: #6366f1;
            font-weight: 600;
        }

        .marks-badge {
            background: linear-gradient(135deg, #ec4899, #d946ef);
            color: white;
            padding: 8px 20px;
            border-radius: 50px;
            font-weight: 600;
        }

        .question-text {
            font-size: 1.1em;
            color: #333;
            line-height: 1.8;
            margin: 25px 0;
            white-space: pre-wrap;
        }

        .options {
            margin: 25px 0;
        }

        .option {
            background: #f8f9fa;
            padding: 15px 20px;
            margin: 12px 0;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 2px solid transparent;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .option:hover {
            background: #e5e7eb;
            border-color: #6366f1;
        }

        .option input[type="radio"],
        .option input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        .option.selected {
            background: #dbeafe;
            border-color: #6366f1;
        }

        .option label {
            cursor: pointer;
            flex: 1;
            font-size: 1.05em;
        }

        input[type="number"] {
            width: 100%;
            padding: 15px;
            font-size: 1.1em;
            border: 2px solid #ddd;
            border-radius: 10px;
            margin: 20px 0;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            font-size: 1em;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
        }

        .btn-mark {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: white;
        }

        .btn-clear {
            background: #e5e7eb;
            color: #333;
        }

        .btn-prev {
            background: linear-gradient(135deg, #6366f1, #4f46e5);
            color: white;
        }

        .btn-next {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            margin-left: auto;
        }

        .btn-submit {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .sidebar {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            max-height: calc(100vh - 120px);
            overflow-y: auto;
        }

        .nav-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .nav-tab {
            flex: 1;
            min-width: 80px;
            padding: 10px 15px;
            background: #f8f9fa;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            font-size: 0.9em;
        }

        .nav-tab.active {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: white;
        }

        .progress-stats {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .stat-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            color: #555;
        }

        .stat-value {
            font-weight: 600;
            color: #6366f1;
        }

        .question-palette {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 10px;
        }

        .palette-btn {
            aspect-ratio: 1;
            border: 2px solid #ddd;
            background: white;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            font-size: 0.95em;
        }

        .palette-btn:hover {
            transform: scale(1.05);
        }

        .palette-btn.current {
            background: #6366f1;
            color: white;
            border-color: #6366f1;
        }

        .palette-btn.answered {
            background: #10b981;
            color: white;
            border-color: #10b981;
        }

        .palette-btn.marked {
            background: #f59e0b;
            color: white;
            border-color: #f59e0b;
        }

        .palette-btn.visited {
            background: #f8f9fa;
            border-color: #cbd5e1;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            animation: fadeIn 0.3s ease;
        }

        .modal-content {
            position: relative;
            max-width: 1000px;
            margin: 50px auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalSlide 0.5s ease;
        }

        .score-circle {
            width: 200px;
            height: 200px;
            margin: 0 auto 30px;
            border-radius: 50%;
            background: linear-gradient(135deg, #6366f1, #ec4899);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: white;
            box-shadow: 0 10px 30px rgba(99, 102, 241, 0.4);
        }

        .score-circle h2 {
            font-size: 3em;
            margin-bottom: 5px;
        }

        .score-circle p {
            font-size: 1.2em;
            opacity: 0.9;
        }

        .result-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }

        .result-card {
            background: linear-gradient(135deg, #f8f9fa, #e5e7eb);
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            border-left: 4px solid #6366f1;
        }

        .result-card.correct {
            border-left-color: #10b981;
        }

        .result-card.wrong {
            border-left-color: #ef4444;
        }

        .result-card.unanswered {
            border-left-color: #9ca3af;
        }

        .result-card.accuracy {
            border-left-color: #3b82f6;
        }

        .result-card.ga-score {
            border-left-color: #8b5cf6;
        }

        .result-card.tech-score {
            border-left-color: #ec4899;
        }

        .result-card h3 {
            font-size: 2.5em;
            margin-bottom: 5px;
            color: #333;
        }

        .result-card p {
            color: #666;
            font-size: 0.95em;
        }

        .chart-container {
            margin: 30px 0;
            max-width: 400px;
            margin-left: auto;
            margin-right: auto;
        }

        .chart-title {
            text-align: center;
            font-size: 1.5em;
            color: #333;
            margin-bottom: 20px;
            font-weight: 600;
        }

        .modal-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 30px;
            flex-wrap: wrap;
        }

        .btn-review {
            background: linear-gradient(135deg, #8b5cf6, #7c3aed);
            color: white;
            padding: 15px 40px;
            border: none;
            border-radius: 50px;
            font-size: 1.1em;
            cursor: pointer;
            font-weight: 600;
        }

        .btn-restart {
            background: white;
            color: #6366f1;
            padding: 15px 40px;
            border: 2px solid #6366f1;
            border-radius: 50px;
            font-size: 1.1em;
            cursor: pointer;
            font-weight: 600;
        }

        .review-screen {
            display: none;
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
        }

        .review-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .review-header h2 {
            font-size: 2em;
            color: #6366f1;
            margin-bottom: 20px;
        }

        .back-btn {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            font-size: 1em;
            font-weight: 600;
        }

        .review-question {
            background: #f8f9fa;
            padding: 25px;
            margin: 20px 0;
            border-radius: 15px;
            border-left: 4px solid #6366f1;
        }

        .review-question.correct {
            border-left-color: #10b981;
        }

        .review-question.wrong {
            border-left-color: #ef4444;
        }

        .review-question.unanswered {
            border-left-color: #9ca3af;
        }

        .review-q-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            flex-wrap: wrap;
            gap: 10px;
        }

        .review-q-number {
            font-weight: 600;
            color: #333;
            font-size: 1.1em;
        }

        .status-badge {
            padding: 6px 15px;
            border-radius: 50px;
            font-size: 0.9em;
            font-weight: 600;
        }

        .status-badge.correct {
            background: #d1fae5;
            color: #065f46;
        }

        .status-badge.wrong {
            background: #fee2e2;
            color: #991b1b;
        }

        .status-badge.unanswered {
            background: #e5e7eb;
            color: #374151;
        }

        .review-option {
            padding: 12px 15px;
            margin: 10px 0;
            border-radius: 8px;
            background: white;
        }

        .review-option.user-answer {
            background: #dbeafe;
            border: 2px solid #3b82f6;
        }

        .review-option.user-answer.correct {
            background: #d1fae5;
            border-color: #10b981;
        }

        .review-option.user-answer.wrong {
            background: #fee2e2;
            border-color: #ef4444;
        }

        .review-option.correct-answer {
            background: #d1fae5;
            border: 2px solid #10b981;
        }

        .footer {
            text-align: center;
            margin-top: 40px;
            padding: 20px;
            color: white;
            font-size: 0.9em;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes modalSlide {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @media (max-width: 968px) {
            .exam-content {
                grid-template-columns: 1fr;
            }

            .sidebar {
                max-height: none;
            }

            .question-palette {
                grid-template-columns: repeat(5, 1fr);
            }
        }

        @media (max-width: 640px) {
            .info-cards {
                grid-template-columns: 1fr;
            }

            .result-cards {
                grid-template-columns: 1fr;
            }

            .exam-nav {
                flex-direction: column;
                gap: 15px;
            }

            .question-palette {
                grid-template-columns: repeat(5, 1fr);
            }

            .instructions-screen {
                padding: 20px;
            }

            .modal-content {
                padding: 20px;
                margin: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="instructions-screen" id="instructionsScreen">
        <div class="exam-header">
            <h1>🎓 GATE CS 2023</h1>
            <h2>Computer Science and Information Technology</h2>
            <p>Organizing Institute: IIT Kanpur</p>
        </div>

        <div class="info-cards">
            <div class="info-card">
                <h3>65</h3>
                <p>Questions</p>
            </div>
            <div class="info-card">
                <h3>100</h3>
                <p>Marks</p>
            </div>
            <div class="info-card">
                <h3>180</h3>
                <p>Minutes</p>
            </div>
            <div class="info-card">
                <h3>3</h3>
                <p>Hours</p>
            </div>
        </div>

        <div class="instructions-content">
            <h3>Examination Instructions</h3>
            <ul>
                <li>This examination contains 65 questions divided into General Aptitude (10 questions) and Technical (55 questions)</li>
                <li>Q1-Q5: General Aptitude (1 mark each)</li>
                <li>Q6-Q10: General Aptitude (2 marks each)</li>
                <li>Q11-Q35: Technical (1 mark each)</li>
                <li>Q36-Q65: Technical (2 marks each)</li>
                <li>MCQ (Multiple Choice): Single answer, negative marking applies (1/3 for 1-mark, 2/3 for 2-mark)</li>
                <li>MSQ (Multiple Select): Multiple answers, NO negative marking</li>
                <li>NAT (Numerical Answer Type): Number input, NO negative marking</li>
                <li>You can navigate between questions using Previous/Next buttons or question palette</li>
                <li>Mark questions for review and clear responses as needed</li>
                <li>Timer will show remaining time - exam auto-submits at 00:00:00</li>
            </ul>
        </div>

        <div class="instructions-content">
            <h3>Question Status Legend</h3>
            <div class="legend">
                <div class="legend-item">
                    <div class="legend-color" style="background: #6366f1;"></div>
                    <span>Current Question</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #10b981;"></div>
                    <span>Answered</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #f59e0b;"></div>
                    <span>Marked for Review</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: white;"></div>
                    <span>Not Visited</span>
                </div>
            </div>
        </div>

        <button class="start-btn" onclick="startExam()">Start Examination</button>

        <div class="footer">
            © 2025 GATEX - Product of Tech Eagles under Mahakumbrix Innovation | Powered By Rocket Examica
        </div>
    </div>

    <div class="exam-screen" id="examScreen">
        <div class="exam-nav">
            <div class="exam-title">GATE CS 2023 - IIT Kanpur</div>
            <div class="timer" id="timer">03:00:00</div>
        </div>

        <div class="exam-content">
            <div class="question-panel">
                <div class="question-header">
                    <div class="question-number" id="questionNumber">Question 1</div>
                    <div class="marks-badge" id="marksBadge">1 Mark</div>
                </div>

                <div class="question-text" id="questionText"></div>

                <div class="options" id="optionsContainer"></div>

                <div class="action-buttons">
                    <button class="btn btn-mark" onclick="markForReview()">Mark for Review</button>
                    <button class="btn btn-clear" onclick="clearResponse()">Clear Response</button>
                    <button class="btn btn-prev" onclick="previousQuestion()">Previous</button>
                    <button class="btn btn-next" onclick="nextQuestion()">Next</button>
                    <button class="btn btn-submit" onclick="submitExam()">Submit Exam</button>
                </div>
            </div>

            <div class="sidebar">
                <div class="nav-tabs">
                    <button class="nav-tab active" onclick="filterQuestions('all')">All</button>
                    <button class="nav-tab" onclick="filterQuestions('GA')">GA</button>
                    <button class="nav-tab" onclick="filterQuestions('Technical')">Technical</button>
                    <button class="nav-tab" onclick="filterQuestions('answered')">Answered</button>
                    <button class="nav-tab" onclick="filterQuestions('unanswered')">Unanswered</button>
                    <button class="nav-tab" onclick="filterQuestions('marked')">Marked</button>
                </div>

                <div class="progress-stats" id="progressStats">
                    <div class="stat-row">
                        <span>Answered:</span>
                        <span class="stat-value" id="answeredCount">0</span>
                    </div>
                    <div class="stat-row">
                        <span>Marked:</span>
                        <span class="stat-value" id="markedCount">0</span>
                    </div>
                    <div class="stat-row">
                        <span>Visited:</span>
                        <span class="stat-value" id="visitedCount">1</span>
                    </div>
                    <div class="stat-row">
                        <span>Not Visited:</span>
                        <span class="stat-value" id="notVisitedCount">64</span>
                    </div>
                </div>

                <div class="question-palette" id="questionPalette"></div>
            </div>
        </div>
    </div>

    <div class="modal" id="resultsModal">
        <div class="modal-content">
            <div class="score-circle">
                <h2 id="totalScore">0</h2>
                <p>out of 100</p>
            </div>

            <div class="result-cards">
                <div class="result-card correct">
                    <h3 id="correctCount">0</h3>
                    <p>✓ Correct Answers</p>
                    <p id="correctMarks" style="font-weight: 600; color: #10b981;">+0 marks</p>
                </div>
                <div class="result-card wrong">
                    <h3 id="wrongCount">0</h3>
                    <p>✗ Wrong Answers</p>
                    <p id="wrongMarks" style="font-weight: 600; color: #ef4444;">-0 marks</p>
                </div>
                <div class="result-card unanswered">
                    <h3 id="unansweredCount">0</h3>
                    <p>○ Unanswered</p>
                </div>
                <div class="result-card accuracy">
                    <h3 id="accuracyPercent">0%</h3>
                    <p>📊 Accuracy</p>
                </div>
                <div class="result-card ga-score">
                    <h3 id="gaScore">0</h3>
                    <p>📚 GA Score (out of 15)</p>
                </div>
                <div class="result-card tech-score">
                    <h3 id="techScore">0</h3>
                    <p>💻 Technical Score (out of 85)</p>
                </div>
            </div>

            <div class="chart-container">
                <div class="chart-title">Performance Breakdown</div>
                <canvas id="performanceChart"></canvas>
            </div>

            <div class="modal-buttons">
                <button class="btn-review" onclick="showReview()">Review Answers</button>
                <button class="btn-restart" onclick="restartExam()">Restart Exam</button>
            </div>
        </div>
    </div>

    <div class="review-screen" id="reviewScreen">
        <div class="review-header">
            <h2>Answer Review - GATE CS 2023</h2>
            <button class="back-btn" onclick="backToResults()">Back to Results</button>
        </div>
        <div id="reviewContent"></div>
    </div>

    <script>
const questions = [
  {id:1,section:"GA",marks:1,type:"MCQ",question:"We reached the station late, and _______ missed the train.",options:["near","nearly","utterly","mostly"],correctAnswer:"B"},
  {id:2,section:"GA",marks:1,type:"MCQ",question:"Kind : _______ : : Often : Frequently\n(By word meaning)",options:["Mean","Type","Cruel","Kindly"],correctAnswer:"C"},
  {id:3,section:"GA",marks:1,type:"MCQ",question:"A series of natural numbers F₁, F₂, F₃, F₄, F₅, F₆, F₇, ... obeys Fₙ₊₁ = Fₙ + Fₙ₋₁ for all integers n ≥ 2.\n\nIf F₆ = 37, and F₇ = 60, then what is F₁?",options:["4","5","8","9"],correctAnswer:"B"},
  {id:4,section:"GA",marks:1,type:"MCQ",question:"A survey for a certain year found that 90% of pregnant women received medical care at least once before giving birth. Of these women, 60% received medical care from doctors, while 40% received medical care from other healthcare providers.\n\nGiven this information, which one of the following statements can be inferred with certainty?",options:["More than half of the pregnant women received medical care at least once from a doctor.","Less than half of the pregnant women received medical care at least once from a doctor.","More than half of the pregnant women received medical care at most once from a doctor.","Less than half of the pregnant women received medical care at most once from a doctor."],correctAnswer:"A"},
  {id:5,section:"GA",marks:1,type:"MCQ",question:"Looking at the surface of a smooth 3-dimensional object from the outside, which one of the following options is TRUE?",options:["The surface of the object must be concave everywhere.","The surface of the object must be convex everywhere.","The surface of the object may be concave in some places and convex in other places.","The object can have edges, but no corners."],correctAnswer:"C"},
  {id:6,section:"GA",marks:2,type:"MCQ",question:"The country of Zombieland is in distress since more than 75% of its working population is suffering from serious health issues. Studies conducted by competent health experts concluded that a complete lack of physical exercise among its working population was one of the leading causes of their health issues. As one of the measures to address the problem, the Government of Zombieland has decided to provide monetary incentives to those who ride bicycles to work.\n\nBased only on the information provided above, which one of the following statements can be logically inferred with certainty?",options:["All the working population of Zombieland will henceforth ride bicycles to work.","Riding bicycles will ensure that all of the working population of Zombieland is free of health issues.","The health experts suggested to the Government of Zombieland to declare riding bicycles as mandatory.","The Government of Zombieland believes that riding bicycles is a form of physical exercise."],correctAnswer:"D"},
  {id:7,section:"GA",marks:2,type:"MCQ",question:"Consider two functions of time (t),\n\nf(t) = 0.01 t²\ng(t) = 4 t\n\nwhere 0 < t < ∞.\n\nNow consider the following two statements:\n(i) For some t > 0, g(t) > f(t).\n(ii) There exists a T, such that f(t) > g(t) for all t > T.\n\nWhich one of the following options is TRUE?",options:["only (i) is correct","only (ii) is correct","both (i) and (ii) are correct","neither (i) nor (ii) is correct"],correctAnswer:"C"},
  {id:8,section:"GA",marks:2,type:"MCQ",question:"Which one of the following sentence sequences creates a coherent narrative?\n\n(i) Once on the terrace, on her way to her small room in the corner, she notices the man right away.\n(ii) She begins to pant by the time she has climbed all the stairs.\n(iii) Mina has bought vegetables and rice at the market, so her bags are heavy.\n(iv) He was leaning against the parapet, watching the traffic below.",options:["(i), (ii), (iv), (iii)","(ii), (iii), (i), (iv)","(iv), (ii), (i), (iii)","(iii), (ii), (i), (iv)"],correctAnswer:"D"},
  {id:9,section:"GA",marks:2,type:"MCQ",question:"f(x) and g(y) are functions of x and y, respectively, and f(x) = g(y) for all real values of x and y. Which one of the following options is necessarily TRUE for all x and y?",options:["f(x) = 0 and g(y) = 0","f(x) = g(y) = constant","f(x) ≠ constant and g(y) ≠ constant","f(x) + g(y) = f(x) - g(y)"],correctAnswer:"B"},
  {id:10,section:"GA",marks:2,type:"MCQ",question:"A 2D figure P is transformed via Operation 1 to Q, then via Operation 2 to R.\n\nWhich operation sequence correctly describes P → Q → R?",options:["Operation 1: A clockwise rotation by 90° about an axis perpendicular to the plane of the figure\nOperation 2: A reflection along a horizontal line","Operation 1: A counter clockwise rotation by 90° about an axis perpendicular to the plane of the figure\nOperation 2: A reflection along a horizontal line","Operation 1: A clockwise rotation by 90° about an axis perpendicular to the plane of the figure\nOperation 2: A reflection along a vertical line","Operation 1: A counter clockwise rotation by 180° about an axis perpendicular to the plane of the figure\nOperation 2: A reflection along a vertical line"],correctAnswer:"B"},
  {id:11,section:"Technical",marks:1,type:"MCQ",question:"Consider the following statements regarding the front-end and back-end of a compiler.\n\nS1: The front-end includes phases that are independent of the target hardware.\nS2: The back-end includes phases that are specific to the target hardware.\nS3: The back-end includes phases that are specific to the programming language used in the source code.\n\nIdentify the CORRECT option.",options:["Only S1 is TRUE.","Only S1 and S2 are TRUE.","S1, S2, and S3 are all TRUE.","Only S1 and S3 are TRUE."],correctAnswer:"B"},
  {id:12,section:"Technical",marks:1,type:"MCQ",question:"Which one of the following sequences when stored in an array at locations A[1], ..., A[10] forms a max-heap?",options:["23, 17, 10, 6, 13, 14, 1, 5, 7, 12","23, 17, 14, 7, 13, 10, 1, 5, 6, 12","23, 17, 14, 6, 13, 10, 1, 5, 7, 15","23, 14, 17, 1, 10, 13, 16, 12, 7, 5"],correctAnswer:"B"},
  {id:13,section:"Technical",marks:1,type:"MCQ",question:"Let SLLdel be a function that deletes a node in a singly-linked list given a pointer to the node and a pointer to the head of the list. Similarly, let DLLdel be another function that deletes a node in a doubly-linked list given a pointer to the node and a pointer to the head of the list.\n\nLet n denote the number of nodes in each of the linked lists. Which one of the following choices is TRUE about the worst-case time complexity of SLLdel and DLLdel?",options:["SLLdel is O(1) and DLLdel is O(n)","Both SLLdel and DLLdel are O(log(n))","Both SLLdel and DLLdel are O(1)","SLLdel is O(n) and DLLdel is O(1)"],correctAnswer:"D"},
  {id:14,section:"Technical",marks:1,type:"MCQ",question:"Consider a Deterministic Finite-state Automaton (DFA) A that runs on alphabet {0, 1}. The DFA has states {s, p, q, r}, with s being the start state and p being the only final state.\n\nWhich one of the following regular expressions correctly describes the language accepted by A?",options:["1(0*11)*","0(0 + 1)*","1(0 + 11)*","1(110*)*"],correctAnswer:"A"},
  {id:15,section:"Technical",marks:1,type:"MCQ",question:"The Lucas sequence Lₙ is defined by the recurrence relation:\n\nLₙ = Lₙ₋₁ + Lₙ₋₂, for n ≥ 3,\n\nwith L₁ = 1 and L₂ = 3.\n\nWhich one of the options given is TRUE?",options:["Lₙ = ((1 + √5)/2)ⁿ + ((1 - √5)/2)ⁿ","Lₙ = ((1 + √5)/2)ⁿ - ((1 - √5)/3)ⁿ","Lₙ = ((1 + √5)/2)ⁿ + ((1 - √5)/3)ⁿ","Lₙ = ((1 + √5)/2)ⁿ - ((1 - √5)/2)ⁿ"],correctAnswer:"A"},
  {id:16,section:"Technical",marks:1,type:"MCQ",question:"Which one of the options given below refers to the degree (or arity) of a relation in relational database systems?",options:["Number of attributes of its relation schema.","Number of tuples stored in the relation.","Number of entries in the relation.","Number of distinct domains of its relation schema."],correctAnswer:"A"},
  {id:17,section:"Technical",marks:1,type:"MCQ",question:"Suppose two hosts are connected by a point-to-point link and they are configured to use Stop-and-Wait protocol for reliable data transfer. Identify in which one of the following scenarios, the utilization of the link is the lowest.",options:["Longer link length and lower transmission rate","Longer link length and higher transmission rate","Shorter link length and lower transmission rate","Shorter link length and higher transmission rate"],correctAnswer:"B"},
  {id:18,section:"Technical",marks:1,type:"MCQ",question:"Let A and B be two 4x4 matrices such that A is skew-symmetric (A^T = -A) and B is symmetric (B^T = B).\n\nLet det(A) and det(B) denote the determinants of the matrices A and B, respectively.\n\nWhich one of the options given below is TRUE?",options:["det(A) = det(B)","det(B) = -det(A)","det(A) = 0","det(AB) = det(A) + det(B)"],correctAnswer:"C"},
  {id:19,section:"Technical",marks:1,type:"MCQ",question:"Consider the following definition of a lexical token id for an identifier in a programming language, using extended regular expressions:\n\nletter → [A-Za-z]\ndigit → [0-9]\nid → letter (letter | digit)*\n\nWhich one of the following represents a correct NFA with ε-transitions that accepts valid identifiers?",options:["NFA starting with letter, looping on letter|digit","NFA with ε transitions allowing empty strings","NFA starting with digit transitions","NFA with only letter loops"],correctAnswer:"A"},
  {id:20,section:"Technical",marks:1,type:"MCQ",question:"An algorithm has to store several keys generated by an adversary in a hash table. The adversary is malicious who tries to maximize the number of collisions. Let k be the number of keys, m be the number of slots in the hash table, and k > m.\n\nWhich one of the following is the best hashing strategy to counteract the adversary?",options:["Division method, i.e., use the hash function h(k) = k mod m.","Multiplication method, i.e., use the hash function h(k) = ⌊m(kA - ⌊kA⌋)⌋, where A is a carefully chosen constant.","Universal hashing method.","If k is a prime number, use Division method. Otherwise, use Multiplication method."],correctAnswer:"C"},
  {id:21,section:"Technical",marks:1,type:"MCQ",question:"The output of a 2-input multiplexer is connected back to one of its inputs.\n\nThis circuit is functionally equivalent to:",options:["D Flip-flop","D Latch","Half-adder","Demultiplexer"],correctAnswer:"B"},
  {id:22,section:"Technical",marks:1,type:"MSQ",question:"Which one or more of the following need to be saved on a context switch from one thread (T1) of a process to another thread (T2) of the same process?",options:["Page table base register","Stack pointer","Program counter","General purpose registers"],correctAnswer:["B","C","D"]},
  {id:23,section:"Technical",marks:1,type:"MSQ",question:"Which one or more of the following options guarantee that a computer system will transition from user mode to kernel mode?",options:["Function Call","malloc Call","Page Fault","System Call"],correctAnswer:["C","D"]},
  {id:24,section:"Technical",marks:1,type:"MSQ",question:"Which of the following statements is/are CORRECT?",options:["The intersection of two regular languages is regular.","The intersection of two context-free languages is context-free.","The intersection of two recursive languages is recursive.","The intersection of two recursively enumerable languages is recursively enumerable."],correctAnswer:["A","C","D"]},
  {id:25,section:"Technical",marks:1,type:"MSQ",question:"Which of the following statements is/are INCORRECT about the OSPF (Open Shortest Path First) routing protocol?",options:["OSPF implements Bellman-Ford algorithm to find shortest paths.","OSPF uses Dijkstra's shortest path algorithm to implement least-cost path routing.","OSPF is used as an inter-domain routing protocol.","OSPF implements hierarchical routing."],correctAnswer:["A","C"]},
  {id:26,section:"Technical",marks:1,type:"MSQ",question:"Geetha has a conjecture about integers, which is of the form\n\n∀x (P(x) ⟹ ∃yQ(x, y))\n\nWhich of the following would imply Geetha's conjecture?",options:["∃x (P(x) ∧ ∀yQ(x, y))","∀x∀yQ(x, y)","∃y∀x (P(x) ⟹ Q(x, y))","∃x (P(x) ∧ ∃yQ(x, y))"],correctAnswer:["B","C"]},
  {id:27,section:"Technical",marks:1,type:"MSQ",question:"Which one or more of the following CPU scheduling algorithms can potentially cause starvation?",options:["First-in First-Out","Round Robin","Priority Scheduling","Shortest Job First"],correctAnswer:["C","D"]},
  {id:28,section:"Technical",marks:1,type:"MSQ",question:"Let f(x) = x³ + 15x² - 33x - 36 be a real-valued function.\n\nWhich of the following statements is/are TRUE?",options:["f(x) does not have a local maximum.","f(x) has a local maximum.","f(x) does not have a local minimum.","f(x) has a local minimum."],correctAnswer:["B","D"]},
  {id:29,section:"Technical",marks:1,type:"MSQ",question:"Let f and g be functions of natural numbers given by f(n) = n and g(n) = n². Which of the following statements is/are TRUE?",options:["f ∈ O(g)","f ∈ Ω(g)","f ∈ o(g)","f ∈ Θ(g)"],correctAnswer:["A","C"]},
  {id:30,section:"Technical",marks:1,type:"NAT",question:"Let A be the adjacency matrix of a graph with vertices {1, 2, 3, 4, 5}.\n\nLet λ₁, λ₂, λ₃, λ₄, and λ₅ be the five eigenvalues of A.\n\nThe value of λ₁ + λ₂ + λ₃ + λ₄ + λ₅ = ",correctAnswer:0,tolerance:0},
  {id:31,section:"Technical",marks:1,type:"NAT",question:"The value of the definite integral\n\n∫₋₃³ ∫₋₂² ∫₋₁¹ (4x²y - z³) dz dy dx\n\nis _____ (Rounded off to the nearest integer)",correctAnswer:0,tolerance:1},
  {id:32,section:"Technical",marks:1,type:"NAT",question:"A particular number is written as 132 in radix-4 representation. The same number in radix-5 representation is _____.",correctAnswer:110,tolerance:0},
  {id:33,section:"Technical",marks:1,type:"NAT",question:"Consider a 3-stage pipelined processor having a delay of 10 ns, 20 ns, and 14 ns, for the first, second, and the third stages, respectively. Assume no other delay and no pipeline hazards. One instruction is fetched every cycle.\n\nThe total execution time for executing 100 instructions is _____ ns.",correctAnswer:2080,tolerance:0},
  {id:34,section:"Technical",marks:1,type:"NAT",question:"A keyboard connected to a computer is used at a rate of 1 keystroke per second. The system polls the keyboard every 10 ms and consumes 100 μs for each poll. If a key has been pressed, the system consumes an additional 200 μs to process the keystroke. Let T₁ be the fraction of a second spent in polling and processing.\n\nIn an alternative implementation using interrupts, it takes 1 ms total for servicing an interrupt and processing a keystroke. Let T₂ be the fraction of a second spent in servicing the interrupt and processing.\n\nThe ratio T₁/T₂ is _____ (Rounded off to one decimal place)",correctAnswer:10.3,tolerance:0.2},
  {id:35,section:"Technical",marks:1,type:"NAT",question:"The integer value printed by the following ANSI-C program is _____.\n\n#include<stdio.h>\n\nint funcp(){\n    static int x = 1;\n    x++;\n    return x;\n}\n\nint main(){\n    int x,y;\n    x = funcp();\n    y = funcp()+x;\n    printf(\"%d\\n\", (x+y));\n    return 0;\n}",correctAnswer:7,tolerance:0},
  {id:36,section:"Technical",marks:2,type:"MCQ",question:"Consider the following program:\n\nint main() {\n    f1();\n    f2(2);\n    f3();\n    return(0);\n}\nint f1() { return(1); }\nint f2(int X) {\n    f3();\n    if (X==1)\n        return f1();\n    else\n        return (X*f2(X-1));\n}\nint f3() { return(5); }\n\nWhich activation tree corresponds to the main function?",options:["main → f1, f2(2) → f3, f2(1) → f3, f1, f3","main → f1, f2, f3","main → f2 → f1 → f3","main → f1, f3, f2"],correctAnswer:"A"},
  {id:37,section:"Technical",marks:2,type:"MCQ",question:"Consider a control flow graph with basic blocks.\n\nWhich choice correctly lists the set of live variables at the exit point of each basic block?",options:["B1: {}, B2: {a}, B3: {a}, B4: {a}","B1: {i, j}, B2: {a}, B3: {a}, B4: {i}","B1: {a, i, j}, B2: {a, i, j}, B3: {a, i}, B4: {a}","B1: {a, i, j}, B2: {a, j}, B3: {a, j}, B4: {a, i, j}"],correctAnswer:"A"},
  {id:38,section:"Technical",marks:2,type:"MCQ",question:"Consider the two functions incr and decr:\n\nincr(){\n    wait(s);\n    X = X+1;\n    signal(s);\n}\ndecr(){\n    wait(s);\n    X = X-1;\n    signal(s);\n}\n\nThere are 5 threads invoking incr once, and 3 threads invoking decr once, on the same shared variable X. Initial value of X is 10.\n\nI-1: s is a binary semaphore initialized to 1.\nI-2: s is a counting semaphore initialized to 2.\n\nWhat are the minimum possible values of V1, V2?",options:["15, 7","7, 7","12, 7","12, 8"],correctAnswer:"C"},
  {id:39,section:"Technical",marks:2,type:"MCQ",question:"Consider the context-free grammar G:\n\nS → aSb | X\nX → aX | Xb | a | b\n\nWhich statement is CORRECT?",options:["The language generated by G is (a + b)*","The language generated by G is a*(a + b)b*","The language generated by G is a*b*(a + b)","The language generated by G is not a regular language"],correctAnswer:"B"},
  {id:40,section:"Technical",marks:2,type:"MCQ",question:"Consider a pushdown automaton (PDA) P that runs on input alphabet {a, b}, has stack alphabet {⊥, A}, and has three states {s, p, q}, with s being the start state.\n\nWhich option correctly describes the language accepted by P?",options:["{aᵐbⁿ | 1 ≤ m and n < m}","{aᵐbⁿ | 0 ≤ n ≤ m}","{aᵐbⁿ | 0 ≤ m and 0 ≤ n}","{aᵐ | 0 ≤ m} ∪ {bⁿ | 0 ≤ n}"],correctAnswer:"B"},
  {id:41,section:"Technical",marks:2,type:"MCQ",question:"Consider C-code and its assembly code with unknown operands U1–U4.\n\nWhich is a CORRECT replacement for (U1, U2, U3, U4)?",options:["(8, 4, 1, L02)","(3, 4, 4, L01)","(8, 1, 1, L02)","(3, 1, 1, L01)"],correctAnswer:"B"},
  {id:42,section:"Technical",marks:2,type:"MCQ",question:"A 4 KB byte-addressable memory uses four 1 KB memory blocks. Two input address lines (IA4 and IA3) are connected to chip select (CS) ports through a decoder.\n\nWhat are the starting addresses (Addr=0) of each block (X1, X2, X3, X4) in decimal?",options:["(0, 1, 2, 3)","(0, 1024, 2048, 3072)","(0, 8, 16, 24)","(0, 0, 0, 0)"],correctAnswer:"B"},
  {id:43,section:"Technical",marks:2,type:"MCQ",question:"Consider a sequential digital circuit with T flip-flops and D flip-flops. At the beginning, Q1, Q2 and Q3 have values 0, 1 and 1, respectively.\n\nWhich value of (Q1, Q2, Q3) can NEVER be obtained?",options:["(0, 0, 1)","(1, 0, 0)","(1, 0, 1)","(1, 1, 1)"],correctAnswer:"C"},
  {id:44,section:"Technical",marks:2,type:"MCQ",question:"A Boolean circuit uses two 4-input multiplexers (M1, M2) and one 2-input multiplexer (M3) with inputs X0–X7.\n\nWhich set of values (X0, X1, X2, X3, X4, X5, X6, X7) realizes A̅ + A̅.C + A.B̅.C?",options:["(1, 1, 0, 0, 1, 1, 1, 0)","(1, 1, 0, 0, 1, 1, 0, 1)","(1, 1, 0, 1, 1, 1, 0, 0)","(0, 0, 1, 1, 0, 1, 1, 1)"],correctAnswer:"A"},
  {id:45,section:"Technical",marks:2,type:"MCQ",question:"Consider IEEE-754 single precision floating point numbers P=0xC1800000 and Q=0x3F5C2EF4.\n\nWhich corresponds to P × Q in IEEE-754 single precision format?",options:["0x404C2EF4","0x405C2EF4","0xC15C2EF4","0xC14C2EF4"],correctAnswer:"D"},
  {id:46,section:"Technical",marks:2,type:"MCQ",question:"Let A be a priority queue using a max-heap. Extract-Max(A) extracts and deletes the maximum element. Insert(A,key) inserts a new element.\n\nWhen A contains n elements, what is TRUE about worst-case running time?",options:["Both Extract-Max(A) and Insert(A,key) run in O(1).","Both Extract-Max(A) and Insert(A,key) run in O(log(n)).","Extract-Max(A) runs in O(1) whereas Insert(A,key) runs in O(n).","Extract-Max(A) runs in O(1) whereas Insert(A,key) runs in O(log(n))."],correctAnswer:"B"},
  {id:47,section:"Technical",marks:2,type:"MCQ",question:"Consider a C function foo called on a binary tree with root node containing value 10.\n\nWhen foo is called with a pointer to the root node, what will it print?",options:["3 8 5 13 11 10","3 5 8 10 11 13","3 8 16 13 24 50","3 16 8 50 24 13"],correctAnswer:"C"},
  {id:48,section:"Technical",marks:2,type:"MCQ",question:"Let U = {1, 2, ..., n}, where n > 1000. Let k < n. Let A, B be subsets of U with |A| = |B| = k and A ∩ B = ∅.\n\nA permutation separates A from B if all members of A appear before all members of B, or vice versa.\n\nHow many permutations of U separate A from B?",options:["n!","C(n, 2k)(n - 2k)!","C(n, 2k)(n - 2k)!(k!)²","2·C(n, 2k)(n - 2k)!(k!)²"],correctAnswer:"D"},
  {id:49,section:"Technical",marks:2,type:"MSQ",question:"Let f : A → B be an onto function. Define equivalence relation ~ on A as:\na₁ ~ a₂ if f(a₁) = f(a₂)\n\nLet E = {[x] : x ∈ A} be the set of all equivalence classes. Define F : E → B as F([x]) = f(x).\n\nWhich statements is/are TRUE?",options:["F is NOT well-defined.","F is an onto function.","F is a one-to-one function.","F is a bijective function."],correctAnswer:["B","C","D"]},
  {id:50,section:"Technical",marks:2,type:"MSQ",question:"Design a reliable byte-stream transport protocol myTCP over a 100 Mbps network with RTT of 150 ms and maximum segment lifetime of 2 minutes.\n\nWhich is/are valid lengths of the Sequence Number field in myTCP header?",options:["30 bits","32 bits","34 bits","36 bits"],correctAnswer:["B","C","D"]},
  {id:51,section:"Technical",marks:2,type:"MSQ",question:"Let X be a set and 2^X denote the powerset. Define binary operation Δ on 2^X as:\nAΔB = (A - B) ∪ (B - A)\n\nLet H = (2^X, Δ). Which statements about H is/are correct?",options:["H is a group.","Every element in H has an inverse, but H is NOT a group.","For every A ∈ 2^X, the inverse of A is the complement of A.","For every A ∈ 2^X, the inverse of A is A."],correctAnswer:["A","D"]},
  {id:52,section:"Technical",marks:2,type:"MSQ",question:"You click on www.gate-2023.in URL. Browser cache is empty. IP address is not cached, so DNS lookup is triggered over 3-tier DNS hierarchy in iterative mode.\n\nWhich statements is/are CORRECT about minimum elapsed time?",options:["7 RTTs, in case of non-persistent HTTP with 5 parallel TCP connections.","5 RTTs, in case of persistent HTTP with pipelining.","9 RTTs, in case of non-persistent HTTP with 5 parallel TCP connections.","6 RTTs, in case of persistent HTTP with pipelining."],correctAnswer:["A","B"]},
  {id:53,section:"Technical",marks:2,type:"MSQ",question:"Consider a random experiment where two fair coins are tossed. Let A = HEAD on both throws, B = HEAD on first throw, C = HEAD on second throw.\n\nWhich statement(s) is/are TRUE?",options:["A and B are independent.","A and C are independent.","B and C are independent.","Prob(B|C) = Prob(B)"],correctAnswer:["C","D"]},
  {id:54,section:"Technical",marks:2,type:"MSQ",question:"Consider Function_1 and Function_2 in pseudocode. Let f₁(n) and f₂(n) denote the number of times 'x = x + 1' is executed.\n\nWhich statement(s) is/are TRUE?",options:["f₁(n) ∈ Θ(f₂(n))","f₁(n) ∈ o(f₂(n))","f₁(n) ∈ ω(f₂(n))","f₁(n) ∈ O(n)"],correctAnswer:["B","D"]},
  {id:55,section:"Technical",marks:2,type:"MSQ",question:"Let G be a simple, finite, undirected graph with vertices {v₁, ..., vₙ}. Let Δ(G) denote maximum degree. Color vertices using a greedy strategy.\n\nWhich statement(s) is/are TRUE?",options:["This procedure results in a proper vertex coloring of G.","The number of colors used is at most Δ(G) + 1.","The number of colors used is at most Δ(G).","The number of colors used is equal to the chromatic number of G."],correctAnswer:["A","B"]},
  {id:56,section:"Technical",marks:2,type:"NAT",question:"Let U = {1, 2, 3}. Let 2^U denote the powerset of U. Consider an undirected graph G whose vertex set is 2^U. For any A, B ∈ 2^U, (A, B) is an edge if (i) A ≠ B, and (ii) either A ⊆ B or B ⊆ A.\n\nIf ∅ denotes the empty set, the cardinality of B(∅) is _____.",correctAnswer:6,tolerance:0},
  {id:57,section:"Technical",marks:2,type:"NAT",question:"Consider a 2D array D in C stored in row-major order:\n\nint D[128][128];\n\nDemand paging is used; each physical page frame holds 512 elements. LRU page-replacement policy is used. 30 physical page frames are allocated to a process executing:\n\nfor (int i = 0; i < 128; i++)\n    for (int j = 0; j < 128; j++)\n        D[j][i] *= 10;\n\nThe number of page faults generated is _____.",correctAnswer:512,tolerance:0},
  {id:58,section:"Technical",marks:2,type:"NAT",question:"Consider a computer system with 57-bit virtual addressing using multi-level tree-structured page tables with L levels. Page size is 4 KB and a page table entry occupies 8 bytes.\n\nThe value of L is _____.",correctAnswer:4,tolerance:0},
  {id:59,section:"Technical",marks:2,type:"NAT",question:"Consider sequence a: a₀ = 1, a₁ = 5, a₂ = 7, a₃ = 8, a₄ = 9, a₅ = 2. Operations performed on stack S and queue Q (both initially empty):\n\nI: push a₀ to a₅ into S\nII: enqueue a₀ to a₅ into Q\nIII: pop from S\nIV: dequeue from Q\nV: pop from S\nVI: dequeue from Q\nVII: dequeue from Q and push into S\nVIII: Repeat VII three times\nIX: pop from S\nX: pop from S\n\nThe top element of S after these operations is _____.",correctAnswer:7,tolerance:0},
  {id:60,section:"Technical",marks:2,type:"NAT",question:"Consider syntax directed translation with given grammar and semantic rules. The value computed for input string 10#011 is _____ (Rounded off to three decimal places)",correctAnswer:2.375,tolerance:0.001},
  {id:61,section:"Technical",marks:2,type:"NAT",question:"Consider a table named Student in a relational database with rollNum as primary key.\n\nThe SQL query below is executed:\n\nSELECT *\nFROM Student\nWHERE gender = 'F' AND marks > 65;\n\nThe number of rows returned is _____.",correctAnswer:2,tolerance:0},
  {id:62,section:"Technical",marks:2,type:"NAT",question:"Consider a database of fixed-length records stored as an ordered file. 25,000 records, each 100 bytes, primary key occupies 15 bytes.\n\nBlock size is 1024 bytes, pointer to block occupies 5 bytes. Binary search on index file is used.\n\nGiven a key, number of block accesses required to identify the block in worst case is _____.",correctAnswer:10,tolerance:0},
  {id:63,section:"Technical",marks:2,type:"NAT",question:"Consider the language L over alphabet {0, 1}:\n\nL = {w ∈ {0, 1}* | w does not contain three or more consecutive 1's}.\n\nThe minimum number of states in a DFA for L is _____.",correctAnswer:4,tolerance:0},
  {id:64,section:"Technical",marks:2,type:"NAT",question:"An 8-way set associative cache of size 64 KB is used in a system with 32-bit address. Address is sub-divided into TAG, INDEX, and BLOCK OFFSET.\n\nThe number of bits in the TAG is _____.",correctAnswer:21,tolerance:0},
  {id:65,section:"Technical",marks:2,type:"NAT",question:"The forwarding table of a router:\n\nSubnet Number | Subnet Mask | Interface ID\n200.150.0.0 | 255.255.0.0 | 1\n200.150.64.0 | 255.255.224.0 | 2\n200.150.68.0 | 255.255.255.0 | 3\n200.150.68.64 | 255.255.255.224 | 4\nDefault | | 0\n\nA packet addressed to 200.150.68.118 will be forwarded to interface _____.",correctAnswer:3,tolerance:0}
];

let currentQuestion = 0;
let userAnswers = {};
let markedQuestions = new Set();
let visitedQuestions = new Set([0]);
let timeRemaining = 180 * 60;
let timerInterval;
let currentFilter = 'all';

function startExam() {
    document.getElementById('instructionsScreen').style.display = 'none';
    document.getElementById('examScreen').style.display = 'block';
    initializeExam();
    startTimer();
}

function initializeExam() {
    createQuestionPalette();
    loadQuestion(0);
    updateStats();
}

function createQuestionPalette() {
    const palette = document.getElementById('questionPalette');
    palette.innerHTML = '';
    questions.forEach((q, index) => {
        const btn = document.createElement('button');
        btn.className = 'palette-btn';
        btn.textContent = index + 1;
        btn.onclick = () => loadQuestion(index);
        palette.appendChild(btn);
    });
}

function loadQuestion(index) {
    currentQuestion = index;
    visitedQuestions.add(index);
    const question = questions[index];
    document.getElementById('questionNumber').textContent = `Question ${index + 1}`;
    document.getElementById('marksBadge').textContent = `${question.marks} Mark${question.marks > 1 ? 's' : ''}`;
    document.getElementById('questionText').textContent = question.question;
    const optionsContainer = document.getElementById('optionsContainer');
    optionsContainer.innerHTML = '';
    if (question.type === 'MCQ') {
        question.options.forEach((option, i) => {
            const optionDiv = document.createElement('div');
            optionDiv.className = 'option';
            if (userAnswers[index] === String.fromCharCode(65 + i)) {
                optionDiv.classList.add('selected');
            }
            const radio = document.createElement('input');
            radio.type = 'radio';
            radio.name = 'option';
            radio.value = String.fromCharCode(65 + i);
            radio.checked = userAnswers[index] === String.fromCharCode(65 + i);
            radio.onchange = () => {
                userAnswers[index] = radio.value;
                updateStats();
                document.querySelectorAll('.option').forEach(opt => opt.classList.remove('selected'));
                optionDiv.classList.add('selected');
            };
            const label = document.createElement('label');
            label.textContent = `(${String.fromCharCode(65 + i)}) ${option}`;
            optionDiv.appendChild(radio);
            optionDiv.appendChild(label);
            optionsContainer.appendChild(optionDiv);
        });
    } else if (question.type === 'MSQ') {
        question.options.forEach((option, i) => {
            const optionDiv = document.createElement('div');
            optionDiv.className = 'option';
            const letter = String.fromCharCode(65 + i);
            if (userAnswers[index] && userAnswers[index].includes(letter)) {
                optionDiv.classList.add('selected');
            }
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.value = letter;
            checkbox.checked = userAnswers[index] && userAnswers[index].includes(letter);
            checkbox.onchange = () => {
                if (!userAnswers[index]) userAnswers[index] = [];
                if (checkbox.checked) {
                    if (!userAnswers[index].includes(letter)) {
                        userAnswers[index].push(letter);
                    }
                    optionDiv.classList.add('selected');
                } else {
                    userAnswers[index] = userAnswers[index].filter(a => a !== letter);
                    optionDiv.classList.remove('selected');
                }
                if (userAnswers[index].length === 0) {
                    delete userAnswers[index];
                }
                updateStats();
            };
            const label = document.createElement('label');
            label.textContent = `(${letter}) ${option}`;
            optionDiv.appendChild(checkbox);
            optionDiv.appendChild(label);
            optionsContainer.appendChild(optionDiv);
        });
    } else if (question.type === 'NAT') {
        const input = document.createElement('input');
        input.type = 'number';
        input.step = 'any';
        input.placeholder = 'Enter your numerical answer';
        input.value = userAnswers[index] || '';
        input.oninput = () => {
            if (input.value.trim() !== '') {
                userAnswers[index] = parseFloat(input.value);
            } else {
                delete userAnswers[index];
            }
            updateStats();
        };
        optionsContainer.appendChild(input);
    }
    updatePalette();
}

function updatePalette() {
    const buttons = document.querySelectorAll('.palette-btn');
    buttons.forEach((btn, index) => {
        btn.className = 'palette-btn';
        if (index === currentQuestion) {
            btn.classList.add('current');
        } else if (userAnswers.hasOwnProperty(index)) {
            btn.classList.add('answered');
        } else if (markedQuestions.has(index)) {
            btn.classList.add('marked');
        } else if (visitedQuestions.has(index)) {
            btn.classList.add('visited');
        }
        if (currentFilter !== 'all') {
            const question = questions[index];
            if (currentFilter === 'GA' && question.section !== 'GA') {
                btn.style.display = 'none';
            } else if (currentFilter === 'Technical' && question.section !== 'Technical') {
                btn.style.display = 'none';
            } else if (currentFilter === 'answered' && !userAnswers.hasOwnProperty(index)) {
                btn.style.display = 'none';
            } else if (currentFilter === 'unanswered' && userAnswers.hasOwnProperty(index)) {
                btn.style.display = 'none';
            } else if (currentFilter === 'marked' && !markedQuestions.has(index)) {
                btn.style.display = 'none';
            } else {
                btn.style.display = '';
            }
        } else {
            btn.style.display = '';
        }
    });
}

function updateStats() {
    const answered = Object.keys(userAnswers).length;
    const marked = markedQuestions.size;
    const visited = visitedQuestions.size;
    const notVisited = questions.length - visited;
    document.getElementById('answeredCount').textContent = answered;
    document.getElementById('markedCount').textContent = marked;
    document.getElementById('visitedCount').textContent = visited;
    document.getElementById('notVisitedCount').textContent = notVisited;
}

function filterQuestions(filter) {
    currentFilter = filter;
    document.querySelectorAll('.nav-tab').forEach(tab => tab.classList.remove('active'));
    event.target.classList.add('active');
    updatePalette();
}

function markForReview() {
    if (markedQuestions.has(currentQuestion)) {
        markedQuestions.delete(currentQuestion);
    } else {
        markedQuestions.add(currentQuestion);
    }
    updateStats();
    updatePalette();
}

function clearResponse() {
    delete userAnswers[currentQuestion];
    loadQuestion(currentQuestion);
    updateStats();
}

function previousQuestion() {
    if (currentQuestion > 0) {
        loadQuestion(currentQuestion - 1);
    }
}

function nextQuestion() {
    if (currentQuestion < questions.length - 1) {
        loadQuestion(currentQuestion + 1);
    }
}

function startTimer() {
    timerInterval = setInterval(() => {
        timeRemaining--;
        const hours = Math.floor(timeRemaining / 3600);
        const minutes = Math.floor((timeRemaining % 3600) / 60);
        const seconds = timeRemaining % 60;
        document.getElementById('timer').textContent = 
            `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        if (timeRemaining <= 0) {
            clearInterval(timerInterval);
            submitExam();
        }
    }, 1000);
}

function submitExam() {
    if (!confirm('Are you sure you want to submit the exam?')) {
        return;
    }
    clearInterval(timerInterval);
    calculateResults();
}

function calculateResults() {
    let totalScore = 0;
    let correctCount = 0;
    let wrongCount = 0;
    let unansweredCount = 0;
    let correctMarks = 0;
    let wrongMarks = 0;
    let gaScore = 0;
    let techScore = 0;
    questions.forEach((q, index) => {
        const userAnswer = userAnswers[index];
        if (!userAnswer) {
            unansweredCount++;
            return;
        }
        let isCorrect = false;
        if (q.type === 'MCQ') {
            isCorrect = userAnswer === q.correctAnswer;
        } else if (q.type === 'MSQ') {
            const correctSet = new Set(q.correctAnswer);
            const userSet = new Set(Array.isArray(userAnswer) ? userAnswer : [userAnswer]);
            isCorrect = correctSet.size === userSet.size && 
                       [...correctSet].every(a => userSet.has(a));
        } else if (q.type === 'NAT') {
            const diff = Math.abs(userAnswer - q.correctAnswer);
            isCorrect = diff <= q.tolerance;
        }
        if (isCorrect) {
            correctCount++;
            totalScore += q.marks;
            correctMarks += q.marks;
            if (q.section === 'GA') {
                gaScore += q.marks;
            } else {
                techScore += q.marks;
            }
        } else {
            wrongCount++;
            if (q.type === 'MCQ') {
                const penalty = q.marks === 1 ? 1/3 : 2/3;
                totalScore -= penalty;
                wrongMarks += penalty;
            }
        }
    });
    totalScore = Math.max(0, totalScore);
    const accuracy = correctCount > 0 ? ((correctCount / (correctCount + wrongCount)) * 100).toFixed(2) : 0;
    document.getElementById('totalScore').textContent = totalScore.toFixed(2);
    document.getElementById('correctCount').textContent = correctCount;
    document.getElementById('correctMarks').textContent = `+${correctMarks} marks`;
    document.getElementById('wrongCount').textContent = wrongCount;
    document.getElementById('wrongMarks').textContent = `-${wrongMarks.toFixed(2)} marks`;
    document.getElementById('unansweredCount').textContent = unansweredCount;
    document.getElementById('accuracyPercent').textContent = accuracy + '%';
    document.getElementById('gaScore').textContent = gaScore.toFixed(2);
    document.getElementById('techScore').textContent = techScore.toFixed(2);
    createChart(correctCount, wrongCount, unansweredCount);
    document.getElementById('examScreen').style.display = 'none';
    document.getElementById('resultsModal').style.display = 'block';
}

function createChart(correct, wrong, unanswered) {
    const ctx = document.getElementById('performanceChart').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Correct', 'Wrong', 'Unanswered'],
            datasets: [{
                data: [correct, wrong, unanswered],
                backgroundColor: ['#10b981', '#ef4444', '#9ca3af'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        font: {
                            size: 14
                        }
                    }
                }
            }
        }
    });
}

function showReview() {
    document.getElementById('resultsModal').style.display = 'none';
    document.getElementById('reviewScreen').style.display = 'block';
    generateReview();
}

function generateReview() {
    const reviewContent = document.getElementById('reviewContent');
    reviewContent.innerHTML = '';
    questions.forEach((q, index) => {
        const reviewDiv = document.createElement('div');
        reviewDiv.className = 'review-question';
        const userAnswer = userAnswers[index];
        let isCorrect = false;
        let status = 'unanswered';
        if (userAnswer) {
            if (q.type === 'MCQ') {
                isCorrect = userAnswer === q.correctAnswer;
            } else if (q.type === 'MSQ') {
                const correctSet = new Set(q.correctAnswer);
                const userSet = new Set(Array.isArray(userAnswer) ? userAnswer : [userAnswer]);
                isCorrect = correctSet.size === userSet.size && 
                           [...correctSet].every(a => userSet.has(a));
            } else if (q.type === 'NAT') {
                const diff = Math.abs(userAnswer - q.correctAnswer);
                isCorrect = diff <= q.tolerance;
            }
            status = isCorrect ? 'correct' : 'wrong';
        }
        reviewDiv.classList.add(status);
        let html = `
            <div class="review-q-header">
                <div class="review-q-number">Question ${index + 1} (${q.section} - ${q.marks} Mark${q.marks > 1 ? 's' : ''} - ${q.type})</div>
                <span class="status-badge ${status}">${status.toUpperCase()}</span>
            </div>
            <div style="margin: 15px 0; font-size: 1.05em; line-height: 1.6; white-space: pre-wrap;">${q.question}</div>
        `;
        if (q.type === 'MCQ' || q.type === 'MSQ') {
            html += '<div style="margin: 15px 0;">';
            q.options.forEach((option, i) => {
                const letter = String.fromCharCode(65 + i);
                let optionClass = 'review-option';
                if (q.type === 'MCQ') {
                    if (userAnswer === letter) {
                        optionClass += ' user-answer';
                        if (isCorrect) {
                            optionClass += ' correct';
                        } else {
                            optionClass += ' wrong';
                        }
                    }
                    if (q.correctAnswer === letter && userAnswer !== letter) {
                        optionClass += ' correct-answer';
                    }
                } else if (q.type === 'MSQ') {
                    const userAnswerArray = Array.isArray(userAnswer) ? userAnswer : [];
                    if (userAnswerArray.includes(letter)) {
                        optionClass += ' user-answer';
                        if (q.correctAnswer.includes(letter)) {
                            optionClass += ' correct';
                        } else {
                            optionClass += ' wrong';
                        }
                    }
                    if (q.correctAnswer.includes(letter) && !userAnswerArray.includes(letter)) {
                        optionClass += ' correct-answer';
                    }
                }
                html += `<div class="${optionClass}">(${letter}) ${option}</div>`;
            });
            html += '</div>';
            if (q.type === 'MCQ') {
                html += `<div style="margin-top: 15px; padding: 12px; background: #f0fdf4; border-radius: 8px; border-left: 3px solid #10b981;">
                    <strong>Correct Answer:</strong> ${q.correctAnswer}
                </div>`;
            } else if (q.type === 'MSQ') {
                html += `<div style="margin-top: 15px; padding: 12px; background: #f0fdf4; border-radius: 8px; border-left: 3px solid #10b981;">
                    <strong>Correct Answers:</strong> ${q.correctAnswer.join(', ')}
                </div>`;
            }
            if (userAnswer) {
                if (q.type === 'MCQ') {
                    html += `<div style="margin-top: 10px; padding: 12px; background: ${isCorrect ? '#f0fdf4' : '#fef2f2'}; border-radius: 8px; border-left: 3px solid ${isCorrect ? '#10b981' : '#ef4444'};">
                        <strong>Your Answer:</strong> ${userAnswer}
                    </div>`;
                } else if (q.type === 'MSQ') {
                    html += `<div style="margin-top: 10px; padding: 12px; background: ${isCorrect ? '#f0fdf4' : '#fef2f2'}; border-radius: 8px; border-left: 3px solid ${isCorrect ? '#10b981' : '#ef4444'};">
                        <strong>Your Answers:</strong> ${Array.isArray(userAnswer) ? userAnswer.join(', ') : userAnswer}
                    </div>`;
                }
            } else {
                html += `<div style="margin-top: 10px; padding: 12px; background: #f9fafb; border-radius: 8px; border-left: 3px solid #9ca3af;">
                    <strong>Your Answer:</strong> Not Answered
                </div>`;
            }
        } else if (q.type === 'NAT') {
            html += `<div style="margin-top: 15px; padding: 12px; background: #f0fdf4; border-radius: 8px; border-left: 3px solid #10b981;">
                <strong>Correct Answer:</strong> ${q.correctAnswer}${q.tolerance > 0 ? ` (±${q.tolerance} tolerance)` : ''}
            </div>`;
            if (userAnswer !== undefined) {
                html += `<div style="margin-top: 10px; padding: 12px; background: ${isCorrect ? '#f0fdf4' : '#fef2f2'}; border-radius: 8px; border-left: 3px solid ${isCorrect ? '#10b981' : '#ef4444'};">
                    <strong>Your Answer:</strong> ${userAnswer}
                </div>`;
            } else {
                html += `<div style="margin-top: 10px; padding: 12px; background: #f9fafb; border-radius: 8px; border-left: 3px solid #9ca3af;">
                    <strong>Your Answer:</strong> Not Answered
                </div>`;
            }
        }
        reviewDiv.innerHTML = html;
        reviewContent.appendChild(reviewDiv);
    });
}

function backToResults() {
    document.getElementById('reviewScreen').style.display = 'none';
    document.getElementById('resultsModal').style.display = 'block';
}

function restartExam() {
    if (!confirm('Are you sure you want to restart the exam? All your progress will be lost.')) {
        return;
    }
    currentQuestion = 0;
    userAnswers = {};
    markedQuestions = new Set();
    visitedQuestions = new Set([0]);
    timeRemaining = 180 * 60;
    currentFilter = 'all';
    document.getElementById('resultsModal').style.display = 'none';
    document.getElementById('reviewScreen').style.display = 'none';
    document.getElementById('examScreen').style.display = 'none';
    document.getElementById('instructionsScreen').style.display = 'block';
}
    </script>
</body>
</html>
