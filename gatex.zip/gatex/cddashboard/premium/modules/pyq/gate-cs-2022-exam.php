<?php
/* === PERSISTENT SESSION PROTECTION === */

// Start session with 1 year lifetime
if (session_status() === PHP_SESSION_NONE) {
    ini_set("session.gc_maxlifetime", 31536000); // 1 year
    session_set_cookie_params(31536000);
    session_start();
}

// Check if user has premium access
if (!isset($_SESSION["premium_access"]) || $_SESSION["premium_access"] !== true) {
    header("Location: ../../index.php");
    exit;
}

// Validate code has not expired
if (isset($_SESSION["code_expiry"])) {
    $expiry = strtotime($_SESSION["code_expiry"]);
    $today = strtotime(date("Y-m-d"));
    
    if ($today > $expiry) {
        session_destroy();
        header("Location: ../../index.php?error=expired");
        exit;
    }
}

/* === END PERSISTENT SESSION PROTECTION === */
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎓 GATE CS 2022 - IIT Kharagpur</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .instructions-screen {
            max-width: 900px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            animation: fadeIn 0.5s ease-in;
        }

        .exam-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .exam-header h1 {
            font-size: 2.5em;
            background: linear-gradient(135deg, #6366f1, #ec4899);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }

        .exam-header h2 {
            font-size: 1.5em;
            color: #555;
            font-weight: 500;
        }

        .exam-header p {
            color: #777;
            margin-top: 5px;
        }

        .info-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }

        .info-card {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            color: white;
            box-shadow: 0 5px 15px rgba(99, 102, 241, 0.3);
        }

        .info-card h3 {
            font-size: 2em;
            margin-bottom: 5px;
        }

        .info-card p {
            font-size: 0.9em;
            opacity: 0.9;
        }

        .instructions-content {
            background: #f8f9fa;
            padding: 25px;
            border-radius: 15px;
            margin: 20px 0;
        }

        .instructions-content h3 {
            color: #6366f1;
            margin-bottom: 15px;
            font-size: 1.3em;
        }

        .instructions-content ul {
            list-style: none;
            padding: 0;
        }

        .instructions-content li {
            padding: 10px 0;
            padding-left: 25px;
            position: relative;
            color: #444;
            line-height: 1.6;
        }

        .instructions-content li:before {
            content: "✓";
            position: absolute;
            left: 0;
            color: #10b981;
            font-weight: bold;
        }

        .legend {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .legend-color {
            width: 30px;
            height: 30px;
            border-radius: 8px;
            border: 2px solid #ddd;
        }

        .start-btn {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            border: none;
            padding: 15px 50px;
            font-size: 1.2em;
            border-radius: 50px;
            cursor: pointer;
            display: block;
            margin: 30px auto;
            box-shadow: 0 5px 15px rgba(16, 185, 129, 0.4);
            transition: transform 0.3s ease;
        }

        .start-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(16, 185, 129, 0.5);
        }

        .exam-screen {
            display: none;
            max-width: 1400px;
            margin: 0 auto;
        }

        .exam-nav {
            background: white;
            padding: 15px 30px;
            border-radius: 15px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            flex-wrap: wrap;
            gap: 15px;
        }

        .exam-title {
            font-size: 1.5em;
            color: #6366f1;
            font-weight: 600;
        }

        .timer {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
            padding: 10px 25px;
            border-radius: 50px;
            font-size: 1.3em;
            font-weight: bold;
            box-shadow: 0 5px 15px rgba(239, 68, 68, 0.3);
        }

        .exam-content {
            display: grid;
            grid-template-columns: 1fr 400px;
            gap: 20px;
        }

        .question-panel {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            min-height: 500px;
        }

        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e5e7eb;
            flex-wrap: wrap;
            gap: 10px;
        }

        .question-number {
            font-size: 1.3em;
            color: #6366f1;
            font-weight: 600;
        }

        .marks-badge {
            background: linear-gradient(135deg, #ec4899, #d946ef);
            color: white;
            padding: 8px 20px;
            border-radius: 50px;
            font-weight: 600;
        }

        .question-text {
            font-size: 1.1em;
            color: #333;
            line-height: 1.8;
            margin: 25px 0;
            white-space: pre-wrap;
        }

        .options {
            margin: 25px 0;
        }

        .option {
            background: #f8f9fa;
            padding: 15px 20px;
            margin: 12px 0;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 2px solid transparent;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .option:hover {
            background: #e5e7eb;
            border-color: #6366f1;
        }

        .option input[type="radio"],
        .option input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        .option.selected {
            background: #dbeafe;
            border-color: #6366f1;
        }

        .option label {
            cursor: pointer;
            flex: 1;
            font-size: 1.05em;
        }

        input[type="number"] {
            width: 100%;
            padding: 15px;
            font-size: 1.1em;
            border: 2px solid #ddd;
            border-radius: 10px;
            margin: 20px 0;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            font-size: 1em;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
        }

        .btn-mark {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: white;
        }

        .btn-clear {
            background: #e5e7eb;
            color: #333;
        }

        .btn-prev {
            background: linear-gradient(135deg, #6366f1, #4f46e5);
            color: white;
        }

        .btn-next {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            margin-left: auto;
        }

        .btn-submit {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .sidebar {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            max-height: calc(100vh - 120px);
            overflow-y: auto;
        }

        .nav-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .nav-tab {
            flex: 1;
            min-width: 80px;
            padding: 10px 15px;
            background: #f8f9fa;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            font-size: 0.9em;
        }

        .nav-tab.active {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: white;
        }

        .progress-stats {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .stat-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            color: #555;
        }

        .stat-value {
            font-weight: 600;
            color: #6366f1;
        }

        .question-palette {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 10px;
        }

        .palette-btn {
            aspect-ratio: 1;
            border: 2px solid #ddd;
            background: white;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            font-size: 0.95em;
        }

        .palette-btn:hover {
            transform: scale(1.05);
        }

        .palette-btn.current {
            background: #6366f1;
            color: white;
            border-color: #6366f1;
        }

        .palette-btn.answered {
            background: #10b981;
            color: white;
            border-color: #10b981;
        }

        .palette-btn.marked {
            background: #f59e0b;
            color: white;
            border-color: #f59e0b;
        }

        .palette-btn.visited {
            background: #f8f9fa;
            border-color: #cbd5e1;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            animation: fadeIn 0.3s ease;
        }

        .modal-content {
            position: relative;
            max-width: 1000px;
            margin: 50px auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
            max-height: 90vh;
            overflow-y: auto;
            animation: modalSlide 0.5s ease;
        }

        .score-circle {
            width: 200px;
            height: 200px;
            margin: 0 auto 30px;
            border-radius: 50%;
            background: linear-gradient(135deg, #6366f1, #ec4899);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: white;
            box-shadow: 0 10px 30px rgba(99, 102, 241, 0.4);
        }

        .score-circle h2 {
            font-size: 3em;
            margin-bottom: 5px;
        }

        .score-circle p {
            font-size: 1.2em;
            opacity: 0.9;
        }

        .result-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }

        .result-card {
            background: linear-gradient(135deg, #f8f9fa, #e5e7eb);
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            border-left: 4px solid #6366f1;
        }

        .result-card.correct {
            border-left-color: #10b981;
        }

        .result-card.wrong {
            border-left-color: #ef4444;
        }

        .result-card.unanswered {
            border-left-color: #9ca3af;
        }

        .result-card.accuracy {
            border-left-color: #3b82f6;
        }

        .result-card.ga-score {
            border-left-color: #8b5cf6;
        }

        .result-card.tech-score {
            border-left-color: #ec4899;
        }

        .result-card h3 {
            font-size: 2.5em;
            margin-bottom: 5px;
            color: #333;
        }

        .result-card p {
            color: #666;
            font-size: 0.95em;
        }

        .chart-container {
            margin: 30px 0;
            max-width: 400px;
            margin-left: auto;
            margin-right: auto;
        }

        .chart-title {
            text-align: center;
            font-size: 1.5em;
            color: #333;
            margin-bottom: 20px;
            font-weight: 600;
        }

        .modal-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 30px;
            flex-wrap: wrap;
        }

        .btn-review {
            background: linear-gradient(135deg, #8b5cf6, #7c3aed);
            color: white;
            padding: 15px 40px;
            border: none;
            border-radius: 50px;
            font-size: 1.1em;
            cursor: pointer;
            font-weight: 600;
        }

        .btn-restart {
            background: white;
            color: #6366f1;
            padding: 15px 40px;
            border: 2px solid #6366f1;
            border-radius: 50px;
            font-size: 1.1em;
            cursor: pointer;
            font-weight: 600;
        }

        .review-screen {
            display: none;
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
        }

        .review-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .review-header h2 {
            font-size: 2em;
            color: #6366f1;
            margin-bottom: 20px;
        }

        .back-btn {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            font-size: 1em;
            font-weight: 600;
        }

        .review-question {
            background: #f8f9fa;
            padding: 25px;
            margin: 20px 0;
            border-radius: 15px;
            border-left: 4px solid #6366f1;
        }

        .review-question.correct {
            border-left-color: #10b981;
        }

        .review-question.wrong {
            border-left-color: #ef4444;
        }

        .review-question.unanswered {
            border-left-color: #9ca3af;
        }

        .review-q-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            flex-wrap: wrap;
            gap: 10px;
        }

        .review-q-number {
            font-weight: 600;
            color: #333;
            font-size: 1.1em;
        }

        .status-badge {
            padding: 6px 15px;
            border-radius: 50px;
            font-size: 0.9em;
            font-weight: 600;
        }

        .status-badge.correct {
            background: #d1fae5;
            color: #065f46;
        }

        .status-badge.wrong {
            background: #fee2e2;
            color: #991b1b;
        }

        .status-badge.unanswered {
            background: #e5e7eb;
            color: #374151;
        }

        .review-option {
            padding: 12px 15px;
            margin: 10px 0;
            border-radius: 8px;
            background: white;
        }

        .review-option.user-answer {
            background: #dbeafe;
            border: 2px solid #3b82f6;
        }

        .review-option.user-answer.correct {
            background: #d1fae5;
            border-color: #10b981;
        }

        .review-option.user-answer.wrong {
            background: #fee2e2;
            border-color: #ef4444;
        }

        .review-option.correct-answer {
            background: #d1fae5;
            border: 2px solid #10b981;
        }

        .footer {
            text-align: center;
            margin-top: 40px;
            padding: 20px;
            color: white;
            font-size: 0.9em;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes modalSlide {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @media (max-width: 968px) {
            .exam-content {
                grid-template-columns: 1fr;
            }

            .sidebar {
                max-height: none;
            }

            .question-palette {
                grid-template-columns: repeat(5, 1fr);
            }
        }

        @media (max-width: 640px) {
            .info-cards {
                grid-template-columns: 1fr;
            }

            .result-cards {
                grid-template-columns: 1fr;
            }

            .exam-nav {
                flex-direction: column;
                gap: 15px;
            }

            .question-palette {
                grid-template-columns: repeat(5, 1fr);
            }

            .instructions-screen {
                padding: 20px;
            }

            .modal-content {
                padding: 20px;
                margin: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="instructions-screen" id="instructionsScreen">
        <div class="exam-header">
            <h1>🎓 GATE CS 2022</h1>
            <h2>Computer Science and Information Technology</h2>
            <p>Organizing Institute: IIT Kharagpur</p>
        </div>

        <div class="info-cards">
            <div class="info-card">
                <h3>65</h3>
                <p>Questions</p>
            </div>
            <div class="info-card">
                <h3>100</h3>
                <p>Marks</p>
            </div>
            <div class="info-card">
                <h3>180</h3>
                <p>Minutes</p>
            </div>
            <div class="info-card">
                <h3>3</h3>
                <p>Hours</p>
            </div>
        </div>

        <div class="instructions-content">
            <h3>Examination Instructions</h3>
            <ul>
                <li>This examination contains 65 questions divided into General Aptitude (10 questions) and Technical (55 questions)</li>
                <li>Q1-Q5: General Aptitude (1 mark each)</li>
                <li>Q6-Q10: General Aptitude (2 marks each)</li>
                <li>Q11-Q22: Technical MCQ (1 mark each)</li>
                <li>Q23-Q27: Technical MSQ (1 mark each)</li>
                <li>Q28-Q35: Technical NAT (1 mark each)</li>
                <li>Q36-Q45: Technical MCQ (2 marks each)</li>
                <li>Q46-Q55: Technical MSQ (2 marks each)</li>
                <li>Q56-Q65: Technical NAT (2 marks each)</li>
                <li>MCQ (Multiple Choice): Single answer, negative marking (1/3 for 1-mark, 2/3 for 2-mark)</li>
                <li>MSQ (Multiple Select): Multiple answers, NO negative marking</li>
                <li>NAT (Numerical Answer Type): Number input, NO negative marking</li>
            </ul>
        </div>

        <div class="instructions-content">
            <h3>Question Status Legend</h3>
            <div class="legend">
                <div class="legend-item">
                    <div class="legend-color" style="background: #6366f1;"></div>
                    <span>Current Question</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #10b981;"></div>
                    <span>Answered</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #f59e0b;"></div>
                    <span>Marked for Review</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: white;"></div>
                    <span>Not Visited</span>
                </div>
            </div>
        </div>

        <button class="start-btn" onclick="startExam()">Start Examination</button>

        <div class="footer">
            © 2025 GATEX - Product of Tech Eagles under Mahakumbrix Innovation | Powered By Rocket Examica
        </div>
    </div>

    <div class="exam-screen" id="examScreen">
        <div class="exam-nav">
            <div class="exam-title">GATE CS 2022 - IIT Kharagpur</div>
            <div class="timer" id="timer">03:00:00</div>
        </div>

        <div class="exam-content">
            <div class="question-panel">
                <div class="question-header">
                    <div class="question-number" id="questionNumber">Question 1</div>
                    <div class="marks-badge" id="marksBadge">1 Mark</div>
                </div>

                <div class="question-text" id="questionText"></div>

                <div class="options" id="optionsContainer"></div>

                <div class="action-buttons">
                    <button class="btn btn-mark" onclick="markForReview()">Mark for Review</button>
                    <button class="btn btn-clear" onclick="clearResponse()">Clear Response</button>
                    <button class="btn btn-prev" onclick="previousQuestion()">Previous</button>
                    <button class="btn btn-next" onclick="nextQuestion()">Next</button>
                    <button class="btn btn-submit" onclick="submitExam()">Submit Exam</button>
                </div>
            </div>

            <div class="sidebar">
                <div class="nav-tabs">
                    <button class="nav-tab active" onclick="filterQuestions('all')">All</button>
                    <button class="nav-tab" onclick="filterQuestions('GA')">GA</button>
                    <button class="nav-tab" onclick="filterQuestions('CS')">CS</button>
                    <button class="nav-tab" onclick="filterQuestions('answered')">Answered</button>
                    <button class="nav-tab" onclick="filterQuestions('unanswered')">Unanswered</button>
                    <button class="nav-tab" onclick="filterQuestions('marked')">Marked</button>
                </div>

                <div class="progress-stats" id="progressStats">
                    <div class="stat-row">
                        <span>Answered:</span>
                        <span class="stat-value" id="answeredCount">0</span>
                    </div>
                    <div class="stat-row">
                        <span>Marked:</span>
                        <span class="stat-value" id="markedCount">0</span>
                    </div>
                    <div class="stat-row">
                        <span>Visited:</span>
                        <span class="stat-value" id="visitedCount">1</span>
                    </div>
                    <div class="stat-row">
                        <span>Not Visited:</span>
                        <span class="stat-value" id="notVisitedCount">64</span>
                    </div>
                </div>

                <div class="question-palette" id="questionPalette"></div>
            </div>
        </div>
    </div>

    <div class="modal" id="resultsModal">
        <div class="modal-content">
            <div class="score-circle">
                <h2 id="totalScore">0</h2>
                <p>out of 100</p>
            </div>

            <div class="result-cards">
                <div class="result-card correct">
                    <h3 id="correctCount">0</h3>
                    <p>✓ Correct Answers</p>
                    <p id="correctMarks" style="font-weight: 600; color: #10b981;">+0 marks</p>
                </div>
                <div class="result-card wrong">
                    <h3 id="wrongCount">0</h3>
                    <p>✗ Wrong Answers</p>
                    <p id="wrongMarks" style="font-weight: 600; color: #ef4444;">-0 marks</p>
                </div>
                <div class="result-card unanswered">
                    <h3 id="unansweredCount">0</h3>
                    <p>○ Unanswered</p>
                </div>
                <div class="result-card accuracy">
                    <h3 id="accuracyPercent">0%</h3>
                    <p>📊 Accuracy</p>
                </div>
                <div class="result-card ga-score">
                    <h3 id="gaScore">0</h3>
                    <p>📚 GA Score (out of 15)</p>
                </div>
                <div class="result-card tech-score">
                    <h3 id="techScore">0</h3>
                    <p>💻 CS Score (out of 85)</p>
                </div>
            </div>

            <div class="chart-container">
                <div class="chart-title">Performance Breakdown</div>
                <canvas id="performanceChart"></canvas>
            </div>

            <div class="modal-buttons">
                <button class="btn-review" onclick="showReview()">Review Answers</button>
                <button class="btn-restart" onclick="restartExam()">Restart Exam</button>
            </div>
        </div>
    </div>

    <div class="review-screen" id="reviewScreen">
        <div class="review-header">
            <h2>Answer Review - GATE CS 2022</h2>
            <button class="back-btn" onclick="backToResults()">Back to Results</button>
        </div>
        <div id="reviewContent"></div>
    </div>

    <script>
const questions = [
  {id:1,section:"GA",marks:1,type:"MCQ",question:"The _________ is too high for it to be considered _________.",options:["fair / fare","faer / fair","fare / fare","fare / fair"],correctAnswer:"D"},
  {id:2,section:"GA",marks:1,type:"MCQ",question:"A function y(x) is defined in the interval [0, 1] as:\n\ny(x) = 2 if 0 ≤ x < 1/3\ny(x) = 3 if 1/3 ≤ x < 3/4  \ny(x) = 1 if 3/4 ≤ x ≤ 1\n\nWhat is the area under the curve for the interval [0, 1]?",options:["5/6","6/5","13/6","6/13"],correctAnswer:"C"},
  {id:3,section:"GA",marks:1,type:"MCQ",question:"Let r be a root of the equation x² + 2x + 6 = 0.\n\nThen the value of the expression (r + 2)(r + 3)(r + 4)(r + 5) is:",options:["51","-51","126","-126"],correctAnswer:"D"},
  {id:4,section:"GA",marks:1,type:"MCQ",question:"Given below are four statements:\n\nStatement 1: All students are inquisitive.\nStatement 2: Some students are inquisitive.\nStatement 3: No student is inquisitive.\nStatement 4: Some students are not inquisitive.\n\nFrom the given four statements, find the two statements that CANNOT BE TRUE simultaneously, assuming that there is at least one student in the class.",options:["Statement 1 and Statement 3","Statement 1 and Statement 2","Statement 2 and Statement 4","Statement 3 and Statement 4"],correctAnswer:"A"},
  {id:5,section:"GA",marks:1,type:"MCQ",question:"A palindrome is a word that reads the same forwards and backwards. In a game of words, a player has two plates painted with letters.\n\nFrom the additional plates given in the options, which combination would allow the player to construct a five-letter palindrome using all five plates exactly once? The plates can be rotated in their plane.",options:["Option A","Option B","Option C","Option D"],correctAnswer:"B"},
  {id:6,section:"GA",marks:2,type:"MCQ",question:"Some people believe that \"what gets measured, improves\". Some others believe that \"what gets measured, gets gamed\". One possible reason for the difference in the beliefs is the work culture in organizations. In organizations with good work culture, metrics help improve outcomes. However, the same metrics are counterproductive in organizations with poor work culture.\n\nWhich one of the following is the CORRECT logical inference based on the information in the above passage?",options:["Metrics are useful in organizations with poor work culture","Metrics are useful in organizations with good work culture","Metrics are always counterproductive in organizations with good work culture","Metrics are never useful in organizations with good work culture"],correctAnswer:"B"},
  {id:7,section:"GA",marks:2,type:"MCQ",question:"In a recently conducted national entrance test, boys constituted 65% of those who appeared for the test. Girls constituted the remaining candidates and they accounted for 60% of the qualified candidates.\n\nWhich one of the following is the correct logical inference based on the information provided in the above passage?",options:["Equal number of boys and girls qualified","Equal number of boys and girls appeared for the test","The number of boys who appeared for the test is less than the number of girls who appeared","The number of boys who qualified the test is less than the number of girls who qualified"],correctAnswer:"D"},
  {id:8,section:"GA",marks:2,type:"MCQ",question:"A box contains five balls of same size and shape. Three of them are green coloured balls and two of them are orange coloured balls. Balls are drawn from the box one at a time. If a green ball is drawn, it is not replaced. If an orange ball is drawn, it is replaced with another orange ball.\n\nFirst ball is drawn. What is the probability of getting an orange ball in the next draw?",options:["1/2","8/25","19/50","23/50"],correctAnswer:"D"},
  {id:9,section:"GA",marks:2,type:"MCQ",question:"The corners and mid-points of the sides of a triangle are named using the distinct letters P, Q, R, S, T and U, but not necessarily in the same order. Consider the following statements:\n\n• The line joining P and R is parallel to the line joining Q and S.\n• P is placed on the side opposite to the corner T.\n• S and U cannot be placed on the same side.\n\nWhich one of the following statements is correct based on the above information?",options:["P cannot be placed at a corner","S cannot be placed at a corner","U cannot be placed at a mid-point","R cannot be placed at a corner"],correctAnswer:"B"},
  {id:10,section:"GA",marks:2,type:"MCQ",question:"A plot of land must be divided between four families. They want their individual plots to be similar in shape, not necessarily equal in area. The land has equally spaced poles. Two ropes, R1 and R2, are already present and cannot be moved.\n\nWhat is the least number of additional straight ropes needed to create the desired plots? A single rope can pass through three poles that are aligned in a straight line.",options:["2","4","5","3"],correctAnswer:"D"},
  {id:11,section:"CS",marks:1,type:"MCQ",question:"Which one of the following statements is TRUE for all positive functions f(n)?",options:["f(2^n) = Θ(f(n)²), when f(n) is a polynomial","f(2^n) = o(f(n)²)","f(2^n) = O(f(n)²), when f(n) is an exponential function","f(2^n) = Ω(f(n)²)"],correctAnswer:"A"},
  {id:12,section:"CS",marks:1,type:"MCQ",question:"Which one of the following regular expressions correctly represents the language of the finite automaton given below?",options:["ab*bab* + ba*aba*","(ab* + ab)(ba* + ba)*","(ab* + ba*)(a + b)*","(ba*ab* + b)(ab + ba)*"],correctAnswer:"D"},
  {id:13,section:"CS",marks:1,type:"MCQ",question:"Which one of the following statements is TRUE?",options:["The LALR(1) parser for a grammar G cannot have reduce-reduce conflict if the LR(1) parser for G does not have reduce-reduce conflict.","Symbol table is accessed only during the lexical analysis phase.","Data flow analysis is necessary for run-time memory management.","LR(1) parsing is sufficient for deterministic context-free languages."],correctAnswer:"D"},
  {id:14,section:"CS",marks:1,type:"MCQ",question:"In a relational data model, which one of the following statements is TRUE?",options:["A relation with only two attributes is always in BCNF.","If all attributes of a relation are prime attributes, then the relation is in BCNF.","Every relation has at least one non-prime attribute.","BCNF decompositions preserve functional dependencies."],correctAnswer:"A"},
  {id:15,section:"CS",marks:1,type:"MCQ",question:"Consider the problem of reversing a singly linked list. Which one of the following statements is TRUE about the time complexity of algorithms that solve the above problem in O(1) space?",options:["The best algorithm for the problem takes Θ(n) time in the worst case.","The best algorithm for the problem takes Θ(n log n) time in the worst case.","The best algorithm for the problem takes Θ(n²) time in the worst case.","It is not possible to reverse a singly linked list in O(1) space."],correctAnswer:"A"},
  {id:16,section:"CS",marks:1,type:"MCQ",question:"Suppose we are given n keys, m hash table slots, and two simple uniform hash functions h1 and h2. Further suppose our hashing scheme uses h1 for the odd keys and h2 for the even keys. What is the expected number of keys in a slot?",options:["m/n","n/m","2n/m","n/(2m)"],correctAnswer:"B"},
  {id:17,section:"CS",marks:1,type:"MCQ",question:"Which one of the following facilitates transfer of bulk data from hard disk to main memory with the highest throughput?",options:["DMA based I/O transfer","Interrupt driven I/O transfer","Polling based I/O transfer","Programmed I/O transfer"],correctAnswer:"A"},
  {id:18,section:"CS",marks:1,type:"MCQ",question:"Let R1 and R2 be two 4-bit registers that store numbers in 2's complement form. For the operation R1+R2, which one of the following values of R1 and R2 gives an arithmetic overflow?",options:["R1 = 1011 and R2 = 1110","R1 = 1100 and R2 = 1010","R1 = 0011 and R2 = 0100","R1 = 1001 and R2 = 1111"],correctAnswer:"B"},
  {id:19,section:"CS",marks:1,type:"MCQ",question:"Consider three threads T1, T2, and T3 executing on a single processor, synchronized using three binary semaphores S1, S2, and S3.\n\nT1: while(true) { wait(S3); print(\"C\"); signal(S2); }\nT2: while(true) { wait(S1); print(\"B\"); signal(S3); }\nT3: while(true) { wait(S2); print(\"A\"); signal(S1); }\n\nWhich initialization of the semaphores would print the sequence BCABCABCA...?",options:["S1 = 1; S2 = 1; S3 = 1","S1 = 1; S2 = 1; S3 = 0","S1 = 1; S2 = 0; S3 = 0","S1 = 0; S2 = 1; S3 = 1"],correctAnswer:"C"},
  {id:20,section:"CS",marks:1,type:"MCQ",question:"Consider the following two statements with respect to the matrices Am×n, Bn×m, Cn×n and Dn×n.\n\nStatement 1: tr(AB) = tr(BA)\nStatement 2: tr(CD) = tr(DC)\n\nwhere tr() represents the trace of a matrix. Which one of the following holds?",options:["Statement 1 is correct and Statement 2 is wrong.","Statement 1 is wrong and Statement 2 is correct.","Both Statement 1 and Statement 2 are correct.","Both Statement 1 and Statement 2 are wrong."],correctAnswer:"C"},
  {id:21,section:"CS",marks:1,type:"MCQ",question:"What is printed by the following ANSI C program?\n\n#include<stdio.h>\nint main(int argc, char *argv[]) {\n    int x = 1, z[2] = {10, 11};\n    int *p = NULL;\n    p = &x;\n    *p = 10;\n    p = &z[1];\n    *(&z[0] + 1) += 3;\n    printf(\"%d, %d, %d\\n\", x, z[0], z[1]);\n    return 0;\n}",options:["1, 10, 11","1, 10, 14","10, 14, 11","10, 10, 14"],correctAnswer:"D"},
  {id:22,section:"CS",marks:1,type:"MCQ",question:"Consider an enterprise network with two Ethernet segments, a web server and a firewall, connected via three routers.\n\nWhat is the number of subnets inside the enterprise network?",options:["3","12","6","8"],correctAnswer:"C"},
  {id:23,section:"CS",marks:1,type:"MSQ",question:"Which of the following statements is/are TRUE?",options:["Every subset of a recursively enumerable language is recursive.","If a language L and its complement L̄ are both recursively enumerable, then L must be recursive.","Complement of a context-free language must be recursive.","If L1 and L2 are regular, then L1 ∪ L2 must be deterministic context-free."],correctAnswer:["B","C","D"]},
  {id:24,section:"CS",marks:1,type:"MSQ",question:"Let WB and WT be two set associative cache organizations that use LRU algorithm for cache block replacement. WB is a write back cache and WT is a write through cache. Which of the following statements is/are FALSE?",options:["Each cache block in WB and WT has a dirty bit.","Every write hit in WB leads to a data transfer from cache to main memory.","Eviction of a block from WT will not lead to data transfer from cache to main memory.","A read miss in WB will never lead to eviction of a dirty block from WB."],correctAnswer:["A","B","D"]},
  {id:25,section:"CS",marks:1,type:"MSQ",question:"Consider the following three relations in a relational database:\nEmployee(eId, Name), Brand(bId, bName), Own(eId, bId)\n\nWhich of the following relational algebra expressions return the set of eIds who own all the brands?",options:["π_eId(Own) ÷ π_bId(Brand)","π_eId(Own) − π_eId((π_eId(Own) × π_bId(Brand)) − Own)","π_eId(Own) ÷ π_bId(Own)","(π_eId(Own) × π_bId(Brand)) ÷ π_bId(Brand)"],correctAnswer:["A","B"]},
  {id:26,section:"CS",marks:1,type:"MSQ",question:"Which of the following statements is/are TRUE with respect to deadlocks?",options:["Circular wait is a necessary condition for the formation of deadlock.","In a system where each resource has more than one instance, a cycle in its wait-for graph indicates the presence of a deadlock.","If the current allocation of resources to processes leads the system to unsafe state, then deadlock will necessarily occur.","In the resource-allocation graph of a system, if every edge is an assignment edge, then the system is not in deadlock state."],correctAnswer:["A","D"]},
  {id:27,section:"CS",marks:1,type:"MSQ",question:"Which of the following statements is/are TRUE for a group G?",options:["If for all x, y ∈ G, (xy)² = x²y², then G is commutative.","If for all x ∈ G, x² = 1, then G is commutative. Here, 1 is the identity element of G.","If the order of G is 2, then G is commutative.","If G is commutative, then a subgroup of G need not be commutative."],correctAnswer:["A","B","C"]},
  {id:28,section:"CS",marks:1,type:"NAT",question:"Suppose a binary search tree with 1000 distinct elements is also a complete binary tree. The tree is stored using the array representation of binary heap trees. Assuming that the array indices start with 0, the 3rd largest element of the tree is stored at index _____________.",correctAnswer:509,tolerance:0},
  {id:29,section:"CS",marks:1,type:"NAT",question:"Consider the augmented grammar with {+, *, (, ), id} as the set of terminals.\n\nS' → S\nS → S + R | R\nR → R * P | P\nP → (S) | id\n\nIf I0 is the set of two LR(0) items {[S' → •S], [S → •S + R]}, then goto(closure(I0), () contains exactly __________ items.",correctAnswer:5,tolerance:0},
  {id:30,section:"CS",marks:1,type:"NAT",question:"Consider a simple undirected graph of 10 vertices. If the graph is disconnected, then the maximum number of edges it can have is ____________.",correctAnswer:36,tolerance:0},
  {id:31,section:"CS",marks:1,type:"NAT",question:"Consider a relation R(A, B, C, D, E) with the following three functional dependencies:\n\nAB → C; BC → D; C → E;\n\nThe number of superkeys in the relation R is _____________.",correctAnswer:8,tolerance:0},
  {id:32,section:"CS",marks:1,type:"NAT",question:"The number of arrangements of six identical balls in three identical bins is______.",correctAnswer:7,tolerance:0},
  {id:33,section:"CS",marks:1,type:"NAT",question:"A cache memory that has a hit rate of 0.8 has an access latency 10 ns and miss penalty 100 ns. An optimization is done on the cache to reduce the miss rate. However, the optimization results in an increase of cache access latency to 15 ns, whereas the miss penalty is not affected. The minimum hit rate (rounded off to two decimal places) needed after the optimization such that it should not increase the average memory access time is _____________.",correctAnswer:0.85,tolerance:0.01},
  {id:34,section:"CS",marks:1,type:"NAT",question:"The value of the following limit is _____________.\n\nlim(x→0) (e^x - 1)/(2x)",correctAnswer:-0.5,tolerance:0.01},
  {id:35,section:"CS",marks:1,type:"NAT",question:"Consider the resolution of the domain name www.gate.org.in by a DNS resolver. Assume that no resource records are cached anywhere across the DNS servers and that iterative query mechanism is used in the resolution. The number of DNS query-response pairs involved in completely resolving the domain name is_____________.",correctAnswer:4,tolerance:0},
  {id:36,section:"CS",marks:2,type:"MCQ",question:"Which one of the following is the closed form for the generating function of the sequence {aₙ}ₙ≥₀ defined below?\n\naₙ = -1, if n is odd\naₙ = 1, otherwise",options:["(2 + x²)/(1 - x²)","(2(3 + x²))/(1 - x²)","(2 - x²)/(1 - x²)","x²/((1 - x)(1 + x²))"],correctAnswer:"A"},
  {id:37,section:"CS",marks:2,type:"MCQ",question:"Consider a simple undirected unweighted graph. If A is the adjacency matrix of the graph, then the number of 3-cycles in the graph is given by the trace of:",options:["A³","A³ divided by 2","A³ divided by 3","A³ divided by 6"],correctAnswer:"D"},
  {id:38,section:"CS",marks:2,type:"MCQ",question:"Which one of the following statements is FALSE?",options:["The TLB performs an associative search in parallel on all its valid entries using page number of incoming virtual address.","If the virtual address of a word given by CPU has a TLB hit, but the subsequent search for the word results in a cache miss, then the word will always be present in the main memory.","The memory access time using a given inverted page table is always same for all incoming virtual addresses.","In a system that uses hashed page tables, if two distinct virtual addresses V1 and V2 map to the same value while hashing, then the memory access time of these addresses will not be the same."],correctAnswer:"C"},
  {id:39,section:"CS",marks:2,type:"MCQ",question:"Let R(z)ᵢ and W(z)ᵢ denote read and write operations on a data element z by a transaction Tᵢ, respectively. Consider the schedule S:\n\nS: R₄(x) R₂(x) R₃(x) R₁(y) W₁(y) W₂(x) W₃(y) R₄(y)\n\nWhich one of the following serial schedules is conflict equivalent to S?",options:["T₁ → T₃ → T₄ → T₂","T₁ → T₄ → T₃ → T₂","T₄ → T₁ → T₃ → T₂","T₃ → T₁ → T₄ → T₂"],correctAnswer:"A"},
  {id:40,section:"CS",marks:2,type:"MCQ",question:"Consider a digital display system (DDS) with register X. A 16-bit code word loads a word in X from either S (a 1024-word memory segment) or R (a 32-word register file). Based on mode bit M, T selects an input word to load in X. P and Q interface with corresponding bits in the code word to choose the addressed word.\n\nWhich one represents the functionality of P, Q, and T?",options:["P is 10:1 multiplexer; Q is 5:1 multiplexer; T is 2:1 multiplexer","P is 10:2¹⁰ decoder; Q is 5:2⁵ decoder; T is 2:1 encoder","P is 10:2¹⁰ decoder; Q is 5:2⁵ decoder; T is 2:1 multiplexer","P is 1:10 de-multiplexer; Q is 1:5 de-multiplexer; T is 2:1 multiplexer"],correctAnswer:"C"},
  {id:41,section:"CS",marks:2,type:"MCQ",question:"Consider three floating point numbers A, B and C stored in registers as per IEEE-754 single precision floating point format:\n\nRA = 0xC1400000, RB = 0x42100000, RC = 0x41400000\n\nWhich one of the following is FALSE?",options:["A + C = 0","C = A + B","B = 3C","(B − C) = 0"],correctAnswer:"B"},
  {id:42,section:"CS",marks:2,type:"MCQ",question:"Consider four processes P, Q, R, and S scheduled on a CPU as per round robin algorithm with a time quantum of 4 units. The processes arrive in the order P, Q, R, S, all at time t = 0. There is exactly one context switch from S to Q, exactly one context switch from R to Q, and exactly two context switches from Q to R. There is no context switch from S to P.\n\nWhich one of the following is NOT possible as CPU burst time of these processes?",options:["P = 4, Q = 10, R = 6, S = 2","P = 2, Q = 9, R = 5, S = 1","P = 4, Q = 12, R = 5, S = 4","P = 3, Q = 7, R = 7, S = 3"],correctAnswer:"D"},
  {id:43,section:"CS",marks:2,type:"MCQ",question:"What is printed by the following ANSI C program?\n\n#include<stdio.h>\nint main(int argc, char *argv[]) {\n    int a[3][3][3] = {{1,2,3,4,5,6,7,8,9},\n                      {10,11,12,13,14,15,16,17,18},\n                      {19,20,21,22,23,24,25,26,27}};\n    int i = 0, j = 0, k = 0;\n    for(i = 0; i < 3; i++) {\n        for(k = 0; k < 3; k++)\n            printf(\"%d \", a[i][j][k]);\n        printf(\"\\n\");\n    }\n    return 0;\n}",options:["1 2 3\n10 11 12\n19 20 21","1 4 7\n10 13 16\n19 22 25","1 2 3\n4 5 6\n7 8 9","1 2 3\n13 14 15\n25 26 27"],correctAnswer:"A"},
  {id:44,section:"CS",marks:2,type:"MCQ",question:"What is printed by the following ANSI C program?\n\n#include<stdio.h>\nint main(int argc, char *argv[]) {\n    char a = 'P';\n    char b = 'x';\n    char c = (a & b) + '*';\n    char d = (a | b) - '-';\n    char e = (a ^ b) + '+';\n    printf(\"%c %c %c\\n\", c, d, e);\n    return 0;\n}\n\nASCII encoding: P=80, x=120, *=42, -=45, +=43",options:["z K S","122 75 83","* - +","P x +"],correctAnswer:"A"},
  {id:45,section:"CS",marks:2,type:"MCQ",question:"Consider solving the following system using LU decomposition:\n\nx1 + 2x2 + x3 = 4\nx1 + 3x2 + x3 = 7\nx1 + 2x2 + 5x3 = 7\n\nWhich one is the correct combination of values for L32, U33, and x1?",options:["L32 = 2, U33 = 1/2, x1 = 1","L32 = 2, U33 = 2, x1 = 1","L32 = 1/2, U33 = 2, x1 = 0","L32 = 1/2, U33 = 1/2, x1 = 0"],correctAnswer:"D"},
  {id:46,section:"CS",marks:2,type:"MSQ",question:"Which of the following is/are undecidable?",options:["Given two Turing machines M1 and M2, decide if L(M1) = L(M2).","Given a Turing machine M, decide if L(M) is regular.","Given a Turing machine M, decide if M accepts all strings.","Given a Turing machine M, decide if M takes more than 1073 steps on every string."],correctAnswer:["A","B","C"]},
  {id:47,section:"CS",marks:2,type:"MSQ",question:"Consider the following languages:\n\nL1 = {aⁿwaⁿ | w ∈ {a, b}*}\nL2 = {wxwᴿ | w, x ∈ {a, b}*, |w|, |x| > 0}\n\nWhich of the following is/are TRUE?",options:["L1 and L2 are regular.","L1 and L2 are context-free.","L1 is regular and L2 is context-free.","L1 and L2 are context-free but not regular."],correctAnswer:["A","B","C"]},
  {id:48,section:"CS",marks:2,type:"MSQ",question:"Consider the following languages:\n\nL1 = {ww | w ∈ {a, b}*}\nL2 = {aⁿbⁿcᵐ | m, n ≥ 0}\nL3 = {aᵐbⁿcⁿ | m, n ≥ 0}\n\nWhich of the following statements is/are FALSE?",options:["L1 is not context-free but L2 and L3 are deterministic context-free.","Neither L1 nor L2 is context-free.","L2, L3 and L2 ∩ L3 all are context-free.","Neither L1 nor its complement is context-free."],correctAnswer:["B","C","D"]},
  {id:49,section:"CS",marks:2,type:"MSQ",question:"Consider a simple undirected weighted graph G, all of whose edge weights are distinct. Which of the following statements about the minimum spanning trees of G is/are TRUE?",options:["The edge with the second smallest weight is always part of any minimum spanning tree of G.","One or both of the edges with the third smallest and the fourth smallest weights are part of any minimum spanning tree of G.","Suppose S ⊂ V be such that S ≠ ∅ and S ≠ V. Consider the edge with the minimum weight such that one of its vertices is in S and the other in V \\ S. Such an edge will always be part of any minimum spanning tree of G.","G can have multiple minimum spanning trees."],correctAnswer:["A","B","C"]},
  {id:50,section:"CS",marks:2,type:"MSQ",question:"Consider the Petersen graph. Which of the following statements is/are TRUE?",options:["The chromatic number of the graph is 3.","The graph has a Hamiltonian path.","The given graph is isomorphic to another representation shown.","The size of the largest independent set of the given graph is 3."],correctAnswer:["A","B","C"]},
  {id:51,section:"CS",marks:2,type:"MSQ",question:"Consider the following recurrence:\n\nf(1) = 1;\nf(2n) = 2f(n) + 1, for n ≥ 1;\nf(2n+1) = 2f(n) + 1, for n ≥ 1.\n\nWhich of the following statements is/are TRUE?",options:["f(2ⁿ - 1) = 2ⁿ - 1","f(2ⁿ) = 1","f(5·2ⁿ⁻¹) = 2ⁿ + 1","f(2ⁿ + 1) = 2ⁿ - 1"],correctAnswer:["A","B","C"]},
  {id:52,section:"CS",marks:2,type:"MSQ",question:"Which of the properties hold for the adjacency matrix A of a simple undirected unweighted graph having n vertices?",options:["The diagonal entries of A² are the degrees of the vertices of the graph.","If the graph is connected, then none of the entries of (A + I)ⁿ⁻¹ can be zero.","If the sum of all the elements of A is at most 2(n - 1), then the graph must be acyclic.","If there is at least a 1 in each of A's rows and columns, then the graph must be connected."],correctAnswer:["A"]},
  {id:53,section:"CS",marks:2,type:"MSQ",question:"Which of the following is/are the eigenvector(s) for the given 4×4 matrix?",options:["[1, -1, 0, 1]ᵀ","[1, 0, -1, 0]ᵀ","[1, 0, 2, -2]ᵀ","[0, 1, -3, 0]ᵀ"],correctAnswer:["A","C","D"]},
  {id:54,section:"CS",marks:2,type:"MSQ",question:"Consider a system with 2 KB direct mapped data cache with a block size of 64 bytes. The system has a physical address space of 64 KB and a word length of 16 bits. During the execution of a program, four data words P, Q, R, and S are accessed in that order 10 times (PQRSPQRS...). The addresses are:\n\nP: 0xA248, Q: 0xC28A, R: 0xCA8A, S: 0xA262\n\nWhich of the following is/are TRUE?",options:["Every access to S is a hit.","Once P is brought to the cache it is never evicted.","At the end of the execution only R and S reside in the cache.","Every access to R evicts Q from the cache."],correctAnswer:["A","B","D"]},
  {id:55,section:"CS",marks:2,type:"MSQ",question:"Consider a router's routing table. Which of the following prefixes in CIDR notation can be collectively used to correctly aggregate all of the subnets?",options:["12.20.164.0/20","12.20.164.0/22","12.20.164.0/21","12.20.168.0/22"],correctAnswer:["B","D"]},
  {id:56,section:"CS",marks:2,type:"NAT",question:"Consider the relational database with four schemas. The SQL query:\n\nSELECT * FROM Student AS S WHERE NOT EXISTS\n  (SELECT cNo FROM Course WHERE dNo = \"D01\"\n   EXCEPT\n   SELECT cNo FROM Register WHERE sNo = S.sNo)\n\nThe number of rows returned by the above SQL query is___________.",correctAnswer:2,tolerance:0},
  {id:57,section:"CS",marks:2,type:"NAT",question:"Consider a network with three routers P, Q, R. All links have cost of unity. The routers exchange distance vector routing information. After convergence, the link Q-R fails. Assume that P and Q send out routing updates at random times at the same average rate.\n\nThe probability of a routing loop formation (rounded off to one decimal place) between P and Q, leading to count-to-infinity problem, is___________.",correctAnswer:0.5,tolerance:0.1},
  {id:58,section:"CS",marks:2,type:"NAT",question:"Let G(V, E) be a directed graph, where V = {1, 2, 3, 4, 5}. The adjacency matrix A is defined as:\n\nA[i][j] = 1 if 1 ≤ j ≤ i ≤ 5, otherwise 0\n\nA directed spanning tree of G, rooted at r ∈ V, is defined as a subgraph T where the undirected version is a tree, and T contains a directed path from r to every other vertex.\n\nThe number of directed spanning trees rooted at vertex 5 is_____________.",correctAnswer:24,tolerance:0},
  {id:59,section:"CS",marks:2,type:"NAT",question:"Consider a 100 Mbps link between an earth station (sender) and a satellite (receiver) at an altitude of 2100 km. The signal propagates at a speed of 3×10⁸ m/s.\n\nThe time taken (in milliseconds, rounded off to two decimal places) for the receiver to completely receive a packet of 1000 bytes transmitted by the sender is_________.",correctAnswer:7.08,tolerance:0.02},
  {id:60,section:"CS",marks:2,type:"NAT",question:"Consider the data transfer using TCP over a 1 Gbps link. Assuming that the maximum segment lifetime (MSL) is set to 60 seconds, the minimum number of bits required for the sequence number field of the TCP header, to prevent the sequence number space from wrapping around during the MSL is____________.",correctAnswer:33,tolerance:0},
  {id:61,section:"CS",marks:2,type:"NAT",question:"A processor X1 operating at 2 GHz has a standard 5-stage RISC instruction pipeline having a base CPI of one without any pipeline hazards. For a given program P that has 30% branch instructions, control hazards incur 2 cycles stall for every branch. A new version of the processor X2 operating at same clock frequency has an additional branch predictor unit (BPU) that completely eliminates stalls for correctly predicted branches.\n\nIf the BPU has a prediction accuracy of 80%, the speed up (rounded off to two decimal places) obtained by X2 over X1 in executing P is____________.",correctAnswer:1.43,tolerance:0.02},
  {id:62,section:"CS",marks:2,type:"NAT",question:"Consider queues Q1 containing four elements and Q2 containing none. The only operations allowed are Enqueue(Q,element) and Dequeue(Q).\n\nThe minimum number of Enqueue operations on Q1 required to place the elements of Q1 in Q2 in reverse order without using any additional storage is___________.",correctAnswer:0,tolerance:0},
  {id:63,section:"CS",marks:2,type:"NAT",question:"Consider two file systems A and B, that use contiguous allocation and linked allocation, respectively. A file of size 100 blocks is already stored in A and also in B. Now, consider inserting a new block in the middle of the file (between 50th and 51st block), whose data is already available in the memory. Assume that there are enough free blocks at the end of the file and that the file control blocks are already in memory.\n\nLet nA and nB be the number of disk accesses required to insert a block in the middle of the file in A and B respectively, then the value of nA - nB is_________.",correctAnswer:153,tolerance:0},
  {id:64,section:"CS",marks:2,type:"NAT",question:"Consider a demand paging system with four page frames (initially empty) and LRU page replacement policy. For the following page reference string:\n\n7, 2, 7, 3, 2, 5, 3, 4, 6, 7, 7, 1, 5, 6, 1\n\nThe page fault rate, defined as the ratio of number of page faults to the number of memory accesses (rounded off to one decimal place) is_________.",correctAnswer:0.6,tolerance:0.1},
  {id:65,section:"CS",marks:2,type:"NAT",question:"Consider the following grammar along with translation rules:\n\nS → S1 # T { S.val = S1.val * T.val }\nS → T { S.val = T.val }\nT → T1 % R { T.val = T1.val % R.val }\nT → R { T.val = R.val }\nR → id { R.val = id.val }\n\nHere # and % are operators and id represents an integer. Using this translation scheme, the computed value of S.val for the expression 20#10%5#8%2%2 is _____________.",correctAnswer:80,tolerance:0}
];

let currentQuestion = 0;
let userAnswers = {};
let markedQuestions = new Set();
let visitedQuestions = new Set([0]);
let timeRemaining = 180 * 60;
let timerInterval;
let currentFilter = 'all';

function startExam() {
    document.getElementById('instructionsScreen').style.display = 'none';
    document.getElementById('examScreen').style.display = 'block';
    initializeExam();
    startTimer();
}

function initializeExam() {
    createQuestionPalette();
    loadQuestion(0);
    updateStats();
}

function createQuestionPalette() {
    const palette = document.getElementById('questionPalette');
    palette.innerHTML = '';
    questions.forEach((q, index) => {
        const btn = document.createElement('button');
        btn.className = 'palette-btn';
        btn.textContent = index + 1;
        btn.onclick = () => loadQuestion(index);
        palette.appendChild(btn);
    });
}

function loadQuestion(index) {
    currentQuestion = index;
    visitedQuestions.add(index);
    const question = questions[index];
    document.getElementById('questionNumber').textContent = `Question ${index + 1}`;
    document.getElementById('marksBadge').textContent = `${question.marks} Mark${question.marks > 1 ? 's' : ''}`;
    document.getElementById('questionText').textContent = question.question;
    const optionsContainer = document.getElementById('optionsContainer');
    optionsContainer.innerHTML = '';
    if (question.type === 'MCQ') {
        question.options.forEach((option, i) => {
            const optionDiv = document.createElement('div');
            optionDiv.className = 'option';
            if (userAnswers[index] === String.fromCharCode(65 + i)) {
                optionDiv.classList.add('selected');
            }
            const radio = document.createElement('input');
            radio.type = 'radio';
            radio.name = 'option';
            radio.value = String.fromCharCode(65 + i);
            radio.checked = userAnswers[index] === String.fromCharCode(65 + i);
            radio.onchange = () => {
                userAnswers[index] = radio.value;
                updateStats();
                document.querySelectorAll('.option').forEach(opt => opt.classList.remove('selected'));
                optionDiv.classList.add('selected');
            };
            const label = document.createElement('label');
            label.textContent = `(${String.fromCharCode(65 + i)}) ${option}`;
            optionDiv.appendChild(radio);
            optionDiv.appendChild(label);
            optionsContainer.appendChild(optionDiv);
        });
    } else if (question.type === 'MSQ') {
        question.options.forEach((option, i) => {
            const optionDiv = document.createElement('div');
            optionDiv.className = 'option';
            const letter = String.fromCharCode(65 + i);
            if (userAnswers[index] && userAnswers[index].includes(letter)) {
                optionDiv.classList.add('selected');
            }
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.value = letter;
            checkbox.checked = userAnswers[index] && userAnswers[index].includes(letter);
            checkbox.onchange = () => {
                if (!userAnswers[index]) userAnswers[index] = [];
                if (checkbox.checked) {
                    if (!userAnswers[index].includes(letter)) {
                        userAnswers[index].push(letter);
                    }
                    optionDiv.classList.add('selected');
                } else {
                    userAnswers[index] = userAnswers[index].filter(a => a !== letter);
                    optionDiv.classList.remove('selected');
                }
                if (userAnswers[index].length === 0) {
                    delete userAnswers[index];
                }
                updateStats();
            };
            const label = document.createElement('label');
            label.textContent = `(${letter}) ${option}`;
            optionDiv.appendChild(checkbox);
            optionDiv.appendChild(label);
            optionsContainer.appendChild(optionDiv);
        });
    } else if (question.type === 'NAT') {
        const input = document.createElement('input');
        input.type = 'number';
        input.step = 'any';
        input.placeholder = 'Enter your numerical answer';
        input.value = userAnswers[index] || '';
        input.oninput = () => {
            if (input.value.trim() !== '') {
                userAnswers[index] = parseFloat(input.value);
            } else {
                delete userAnswers[index];
            }
            updateStats();
        };
        optionsContainer.appendChild(input);
    }
    updatePalette();
}

function updatePalette() {
    const buttons = document.querySelectorAll('.palette-btn');
    buttons.forEach((btn, index) => {
        btn.className = 'palette-btn';
        if (index === currentQuestion) {
            btn.classList.add('current');
        } else if (userAnswers.hasOwnProperty(index)) {
            btn.classList.add('answered');
        } else if (markedQuestions.has(index)) {
            btn.classList.add('marked');
        } else if (visitedQuestions.has(index)) {
            btn.classList.add('visited');
        }
        if (currentFilter !== 'all') {
            const question = questions[index];
            if (currentFilter === 'GA' && question.section !== 'GA') {
                btn.style.display = 'none';
            } else if (currentFilter === 'CS' && question.section !== 'CS') {
                btn.style.display = 'none';
            } else if (currentFilter === 'answered' && !userAnswers.hasOwnProperty(index)) {
                btn.style.display = 'none';
            } else if (currentFilter === 'unanswered' && userAnswers.hasOwnProperty(index)) {
                btn.style.display = 'none';
            } else if (currentFilter === 'marked' && !markedQuestions.has(index)) {
                btn.style.display = 'none';
            } else {
                btn.style.display = '';
            }
        } else {
            btn.style.display = '';
        }
    });
}

function updateStats() {
    const answered = Object.keys(userAnswers).length;
    const marked = markedQuestions.size;
    const visited = visitedQuestions.size;
    const notVisited = questions.length - visited;
    document.getElementById('answeredCount').textContent = answered;
    document.getElementById('markedCount').textContent = marked;
    document.getElementById('visitedCount').textContent = visited;
    document.getElementById('notVisitedCount').textContent = notVisited;
}

function filterQuestions(filter) {
    currentFilter = filter;
    document.querySelectorAll('.nav-tab').forEach(tab => tab.classList.remove('active'));
    event.target.classList.add('active');
    updatePalette();
}

function markForReview() {
    if (markedQuestions.has(currentQuestion)) {
        markedQuestions.delete(currentQuestion);
    } else {
        markedQuestions.add(currentQuestion);
    }
    updateStats();
    updatePalette();
}

function clearResponse() {
    delete userAnswers[currentQuestion];
    loadQuestion(currentQuestion);
    updateStats();
}

function previousQuestion() {
    if (currentQuestion > 0) {
        loadQuestion(currentQuestion - 1);
    }
}

function nextQuestion() {
    if (currentQuestion < questions.length - 1) {
        loadQuestion(currentQuestion + 1);
    }
}

function startTimer() {
    timerInterval = setInterval(() => {
        timeRemaining--;
        const hours = Math.floor(timeRemaining / 3600);
        const minutes = Math.floor((timeRemaining % 3600) / 60);
        const seconds = timeRemaining % 60;
        document.getElementById('timer').textContent = 
            `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        if (timeRemaining <= 0) {
            clearInterval(timerInterval);
            submitExam();
        }
    }, 1000);
}

function submitExam() {
    if (!confirm('Are you sure you want to submit the exam?')) {
        return;
    }
    clearInterval(timerInterval);
    calculateResults();
}

function calculateResults() {
    let totalScore = 0;
    let correctCount = 0;
    let wrongCount = 0;
    let unansweredCount = 0;
    let correctMarks = 0;
    let wrongMarks = 0;
    let gaScore = 0;
    let csScore = 0;
    questions.forEach((q, index) => {
        const userAnswer = userAnswers[index];
        if (!userAnswer) {
            unansweredCount++;
            return;
        }
        let isCorrect = false;
        if (q.type === 'MCQ') {
            isCorrect = userAnswer === q.correctAnswer;
        } else if (q.type === 'MSQ') {
            const correctSet = new Set(q.correctAnswer);
            const userSet = new Set(Array.isArray(userAnswer) ? userAnswer : [userAnswer]);
            isCorrect = correctSet.size === userSet.size && 
                       [...correctSet].every(a => userSet.has(a));
        } else if (q.type === 'NAT') {
            const diff = Math.abs(userAnswer - q.correctAnswer);
            isCorrect = diff <= q.tolerance;
        }
        if (isCorrect) {
            correctCount++;
            totalScore += q.marks;
            correctMarks += q.marks;
            if (q.section === 'GA') {
                gaScore += q.marks;
            } else {
                csScore += q.marks;
            }
        } else {
            wrongCount++;
            if (q.type === 'MCQ') {
                const penalty = q.marks === 1 ? 1/3 : 2/3;
                totalScore -= penalty;
                wrongMarks += penalty;
            }
        }
    });
    totalScore = Math.max(0, totalScore);
    const accuracy = correctCount > 0 ? ((correctCount / (correctCount + wrongCount)) * 100).toFixed(2) : 0;
    document.getElementById('totalScore').textContent = totalScore.toFixed(2);
    document.getElementById('correctCount').textContent = correctCount;
    document.getElementById('correctMarks').textContent = `+${correctMarks} marks`;
    document.getElementById('wrongCount').textContent = wrongCount;
    document.getElementById('wrongMarks').textContent = `-${wrongMarks.toFixed(2)} marks`;
    document.getElementById('unansweredCount').textContent = unansweredCount;
    document.getElementById('accuracyPercent').textContent = accuracy + '%';
    document.getElementById('gaScore').textContent = gaScore.toFixed(2);
    document.getElementById('techScore').textContent = csScore.toFixed(2);
    createChart(correctCount, wrongCount, unansweredCount);
    document.getElementById('examScreen').style.display = 'none';
    document.getElementById('resultsModal').style.display = 'block';
}

function createChart(correct, wrong, unanswered) {
    const ctx = document.getElementById('performanceChart').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Correct', 'Wrong', 'Unanswered'],
            datasets: [{
                data: [correct, wrong, unanswered],
                backgroundColor: ['#10b981', '#ef4444', '#9ca3af'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        font: {
                            size: 14
                        }
                    }
                }
            }
        }
    });
}

function showReview() {
    document.getElementById('resultsModal').style.display = 'none';
    document.getElementById('reviewScreen').style.display = 'block';
    generateReview();
}

function generateReview() {
    const reviewContent = document.getElementById('reviewContent');
    reviewContent.innerHTML = '';
    questions.forEach((q, index) => {
        const reviewDiv = document.createElement('div');
        reviewDiv.className = 'review-question';
        const userAnswer = userAnswers[index];
        let isCorrect = false;
        let status = 'unanswered';
        if (userAnswer) {
            if (q.type === 'MCQ') {
                isCorrect = userAnswer === q.correctAnswer;
            } else if (q.type === 'MSQ') {
                const correctSet = new Set(q.correctAnswer);
                const userSet = new Set(Array.isArray(userAnswer) ? userAnswer : [userAnswer]);
                isCorrect = correctSet.size === userSet.size && 
                           [...correctSet].every(a => userSet.has(a));
            } else if (q.type === 'NAT') {
                const diff = Math.abs(userAnswer - q.correctAnswer);
                isCorrect = diff <= q.tolerance;
            }
            status = isCorrect ? 'correct' : 'wrong';
        }
        reviewDiv.classList.add(status);
        let html = `
            <div class="review-q-header">
                <div class="review-q-number">Question ${index + 1} (${q.section} - ${q.marks} Mark${q.marks > 1 ? 's' : ''} - ${q.type})</div>
                <span class="status-badge ${status}">${status.toUpperCase()}</span>
            </div>
            <div style="margin: 15px 0; font-size: 1.05em; line-height: 1.6; white-space: pre-wrap;">${q.question}</div>
        `;
        if (q.type === 'MCQ' || q.type === 'MSQ') {
            html += '<div style="margin: 15px 0;">';
            q.options.forEach((option, i) => {
                const letter = String.fromCharCode(65 + i);
                let optionClass = 'review-option';
                if (q.type === 'MCQ') {
                    if (userAnswer === letter) {
                        optionClass += ' user-answer';
                        if (isCorrect) {
                            optionClass += ' correct';
                        } else {
                            optionClass += ' wrong';
                        }
                    }
                    if (q.correctAnswer === letter && userAnswer !== letter) {
                        optionClass += ' correct-answer';
                    }
                } else if (q.type === 'MSQ') {
                    const userAnswerArray = Array.isArray(userAnswer) ? userAnswer : [];
                    if (userAnswerArray.includes(letter)) {
                        optionClass += ' user-answer';
                        if (q.correctAnswer.includes(letter)) {
                            optionClass += ' correct';
                        } else {
                            optionClass += ' wrong';
                        }
                    }
                    if (q.correctAnswer.includes(letter) && !userAnswerArray.includes(letter)) {
                        optionClass += ' correct-answer';
                    }
                }
                html += `<div class="${optionClass}">(${letter}) ${option}</div>`;
            });
            html += '</div>';
            if (q.type === 'MCQ') {
                html += `<div style="margin-top: 15px; padding: 12px; background: #f0fdf4; border-radius: 8px; border-left: 3px solid #10b981;">
                    <strong>Correct Answer:</strong> ${q.correctAnswer}
                </div>`;
            } else if (q.type === 'MSQ') {
                html += `<div style="margin-top: 15px; padding: 12px; background: #f0fdf4; border-radius: 8px; border-left: 3px solid #10b981;">
                    <strong>Correct Answers:</strong> ${q.correctAnswer.join(', ')}
                </div>`;
            }
            if (userAnswer) {
                if (q.type === 'MCQ') {
                    html += `<div style="margin-top: 10px; padding: 12px; background: ${isCorrect ? '#f0fdf4' : '#fef2f2'}; border-radius: 8px; border-left: 3px solid ${isCorrect ? '#10b981' : '#ef4444'};">
                        <strong>Your Answer:</strong> ${userAnswer}
                    </div>`;
                } else if (q.type === 'MSQ') {
                    html += `<div style="margin-top: 10px; padding: 12px; background: ${isCorrect ? '#f0fdf4' : '#fef2f2'}; border-radius: 8px; border-left: 3px solid ${isCorrect ? '#10b981' : '#ef4444'};">
                        <strong>Your Answers:</strong> ${Array.isArray(userAnswer) ? userAnswer.join(', ') : userAnswer}
                    </div>`;
                }
            } else {
                html += `<div style="margin-top: 10px; padding: 12px; background: #f9fafb; border-radius: 8px; border-left: 3px solid #9ca3af;">
                    <strong>Your Answer:</strong> Not Answered
                </div>`;
            }
        } else if (q.type === 'NAT') {
            html += `<div style="margin-top: 15px; padding: 12px; background: #f0fdf4; border-radius: 8px; border-left: 3px solid #10b981;">
                <strong>Correct Answer:</strong> ${q.correctAnswer}${q.tolerance > 0 ? ` (±${q.tolerance} tolerance)` : ''}
            </div>`;
            if (userAnswer !== undefined) {
                html += `<div style="margin-top: 10px; padding: 12px; background: ${isCorrect ? '#f0fdf4' : '#fef2f2'}; border-radius: 8px; border-left: 3px solid ${isCorrect ? '#10b981' : '#ef4444'};">
                    <strong>Your Answer:</strong> ${userAnswer}
                </div>`;
            } else {
                html += `<div style="margin-top: 10px; padding: 12px; background: #f9fafb; border-radius: 8px; border-left: 3px solid #9ca3af;">
                    <strong>Your Answer:</strong> Not Answered
                </div>`;
            }
        }
        reviewDiv.innerHTML = html;
        reviewContent.appendChild(reviewDiv);
    });
}

function backToResults() {
    document.getElementById('reviewScreen').style.display = 'none';
    document.getElementById('resultsModal').style.display = 'block';
}

function restartExam() {
    if (!confirm('Are you sure you want to restart the exam? All your progress will be lost.')) {
        return;
    }
    currentQuestion = 0;
    userAnswers = {};
    markedQuestions = new Set();
    visitedQuestions = new Set([0]);
    timeRemaining = 180 * 60;
    currentFilter = 'all';
    document.getElementById('resultsModal').style.display = 'none';
    document.getElementById('reviewScreen').style.display = 'none';
    document.getElementById('examScreen').style.display = 'none';
    document.getElementById('instructionsScreen').style.display = 'block';
}
    </script>
</body>
</html>
