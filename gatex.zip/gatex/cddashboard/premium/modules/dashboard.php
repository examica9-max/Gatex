<?php
/* === SESSION PROTECTION === */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["premium_access"]) || $_SESSION["premium_access"] !== true) {
    $path = $_SERVER["SCRIPT_NAME"];
    if (strpos($path, "/modules/") !== false) {
        header("Location: ../index.php");
    } else {
        header("Location: index.php");
    }
    exit;
}
/* === END SESSION PROTECTION === */
?>
<?php
require_once '../includes/premium-check.php';
checkPremiumAccess();
$userInfo = getPremiumUserInfo();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium Dashboard - GATEX</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            color: #f8fafc;
            min-height: 100vh;
        }

        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
        }

        .gradient-orb {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.3;
            animation: float 20s ease-in-out infinite;
        }

        .orb1 { width: 500px; height: 500px; background: #6366f1; top: -100px; left: -100px; }
        .orb2 { width: 400px; height: 400px; background: #ec4899; bottom: -100px; right: -100px; animation-delay: -5s; }

        @keyframes float {
            0%, 100% { transform: translate(0, 0); }
            50% { transform: translate(50px, -50px); }
        }

        .container {
            position: relative;
            z-index: 1;
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .header h1 {
            font-size: 32px;
            background: linear-gradient(135deg, #6366f1 0%, #ec4899 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .premium-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%);
            color: #78350f;
            border-radius: 20px;
            font-weight: 700;
            font-size: 14px;
        }

        .logout-btn {
            padding: 10px 20px;
            background: rgba(239, 68, 68, 0.2);
            color: #fca5a5;
            border: 1px solid #ef4444;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }

        .logout-btn:hover {
            background: rgba(239, 68, 68, 0.3);
            transform: translateY(-2px);
        }

        .welcome-card {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.2), rgba(236, 72, 153, 0.2));
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 40px;
            margin-bottom: 30px;
            text-align: center;
        }

        .welcome-card h2 { font-size: 28px; margin-bottom: 15px; }
        .welcome-card p { color: #cbd5e1; font-size: 16px; }

        .info-box {
            background: rgba(34, 197, 94, 0.1);
            border: 1px solid rgba(34, 197, 94, 0.3);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 30px;
        }

        .info-box p { color: #86efac; margin: 0; }

        .modules-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .module-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 30px;
            transition: all 0.3s;
            cursor: pointer;
        }

        .module-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            border-color: rgba(99, 102, 241, 0.5);
        }

        .module-icon { font-size: 48px; margin-bottom: 15px; }
        .module-card h3 { font-size: 22px; margin-bottom: 10px; color: #a78bfa; }
        .module-card p { color: #94a3b8; margin-bottom: 20px; line-height: 1.6; }

        .module-btn {
            display: inline-block;
            padding: 12px 30px;
            background: linear-gradient(135deg, #6366f1 0%, #ec4899 100%);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s;
        }

        .module-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(99, 102, 241, 0.4);
        }

        @media (max-width: 768px) {
            .header { flex-direction: column; text-align: center; }
            .modules-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="animated-bg">
        <div class="gradient-orb orb1"></div>
        <div class="gradient-orb orb2"></div>
    </div>

    <div class="container">
        <div class="header">
            <div>
                <h1>🚀 GATEX Premium</h1>
                <span class="premium-badge">
                    <span>👑</span>
                    <span>Premium Member</span>
                </span>
            </div>
            <a href="../purchase.php?logout" class="logout-btn">Logout</a>
        </div>

        <div class="info-box">
            <p><strong>✅ Premium Active</strong> • Code: <?php echo htmlspecialchars($userInfo['code']); ?> • Activated: <?php echo date('M d, Y', $userInfo['activated_at']); ?></p>
        </div>

        <div class="welcome-card">
            <h2>Welcome to Premium! 🎉</h2>
            <p>Unlimited access to all AI-powered features and GATE preparation tools</p>
        </div>

        <div class="modules-grid">
            <div class="module-card">
                <div class="module-icon">🤖</div>
                <h3>AI Questions Generator</h3>
                <p>Generate unlimited AI-powered GATE questions with detailed solutions.</p>
                <a href="gatecs/index.html" class="module-btn">Launch Generator</a>
            </div>

            <div class="module-card">
                <div class="module-icon">📚</div>
                <h3>AI Study Last Minuute Notes</h3>
                <p>Comprehensive AI-generated notes covering entire GATE CS syllabus.</p>
                <a href="notes/index.php" class="module-btn">View Notes</a>
            </div>
            
            <div class="module-card">
    <div class="module-icon">📝</div>
    <h3>AI Study Detailed Notes</h3>
    <p>In-depth AI-generated detailed notes for complete GATE CS preparation.</p>
    <a href="detailed/index.php" class="module-btn">View Detailed Notes</a>
</div>


            <div class="module-card">
                <div class="module-icon">📝</div>
                <h3>AI Full Papers</h3>
                <p>Create unlimited custom full-length papers matching GATE patterns.</p>
                <a href="papers/index.html" class="module-btn">Create Paper</a>
            </div>

            <div class="module-card">
                <div class="module-icon">📄</div>
                <h3>Previous Year Papers</h3>
                <p>Practice with actual GATE CS papers from 2022-2025.</p>
                <a href="pyq/index.html" class="module-btn">Start Practice</a>
            </div>
        </div>
    </div>
</body>
</html>
