<?php
// GATE CS Paper Generator - GATEX Product
// © 2025 GATEX - Product of Tech Eagles under Mahakumbrix Innovation
// Powered By Rocket Examica. All Rights Reserved.


/* === PERSISTENT SESSION PROTECTION === */

// Start session with 1 year lifetime
if (session_status() === PHP_SESSION_NONE) {
    ini_set("session.gc_maxlifetime", 31536000); // 1 year
    session_set_cookie_params(31536000);
    session_start();
}

// Check if user has premium access
if (!isset($_SESSION["premium_access"]) || $_SESSION["premium_access"] !== true) {
    header("Location: ../../index.php");
    exit;
}

// Validate code has not expired
if (isset($_SESSION["code_expiry"])) {
    $expiry = strtotime($_SESSION["code_expiry"]);
    $today = strtotime(date("Y-m-d"));
    
    if ($today > $expiry) {
        session_destroy();
        header("Location: ../../index.php?error=expired");
        exit;
    }
}

/* === END PERSISTENT SESSION PROTECTION === */


$CLAUDE_API_KEY = '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';
$CLAUDE_API_URL = 'https://api.anthropic.com/v1/messages';

header('Content-Type: text/html; charset=UTF-8');

// Handle AJAX requests for paper generation
if (isset($_POST['action']) && $_POST['action'] === 'generate_paper') {
    header('Content-Type: application/json');
    
    $sections = json_decode($_POST['sections'], true);
    $difficulty = $_POST['difficulty'] ?? 'Medium';
    $total_marks = intval($_POST['total_marks'] ?? 100);
    
    $prompt = generatePrompt($sections, $difficulty, $total_marks);
    
    $response = callClaudeAPI($CLAUDE_API_URL, $CLAUDE_API_KEY, $prompt);
    
    echo json_encode($response);
    exit;
}

function generatePrompt($sections, $difficulty, $total_marks) {
    $sectionsText = '';
    foreach ($sections as $section => $data) {
        if ($data['enabled']) {
            $sectionsText .= "- {$section}: {$data['questions']} questions, {$data['marks']} marks each\n";
        }
    }
    
    $prompt = "Generate a complete GATE Computer Science examination paper with the following specifications:

Difficulty Level: {$difficulty}
Total Marks: {$total_marks}

Sections:
{$sectionsText}

Requirements:
1. Generate REALISTIC GATE-level questions covering core CS topics: Data Structures, Algorithms, Operating Systems, DBMS, Computer Networks, Digital Logic, TOC, Compiler Design, Programming, Discrete Mathematics
2. For MCQ: Provide 4 options (A, B, C, D) with ONLY ONE correct answer
3. For MSQ: Provide 4 options where 1-4 can be correct (Multiple Select Questions)
4. For NAT: Questions requiring numerical answers (integer or decimal up to 2 places - Numerical Answer Type)
5. Include proper formatting with marks clearly indicated
6. Questions should be conceptual, numerical, and application-based mix
7. Ensure questions are exam-realistic and not too trivial
8. Make questions challenging and representative of actual GATE exam difficulty

Return ONLY a valid JSON object in this EXACT format (no markdown, no extra text, no code blocks):
{
  \"sections\": [
    {
      \"type\": \"MCQ\",
      \"title\": \"Multiple Choice Questions (Single Correct)\",
      \"questions\": [
        {
          \"id\": 1,
          \"question\": \"Question text here\",
          \"options\": [\"A) option1\", \"B) option2\", \"C) option3\", \"D) option4\"],
          \"correct_answer\": \"B\",
          \"marks\": 2,
          \"topic\": \"Data Structures\"
        }
      ]
    },
    {
      \"type\": \"MSQ\",
      \"title\": \"Multiple Select Questions (One or More Correct)\",
      \"questions\": [
        {
          \"id\": 1,
          \"question\": \"Question text here\",
          \"options\": [\"A) option1\", \"B) option2\", \"C) option3\", \"D) option4\"],
          \"correct_answer\": \"A, C\",
          \"marks\": 2,
          \"topic\": \"Operating Systems\"
        }
      ]
    },
    {
      \"type\": \"NAT\",
      \"title\": \"Numerical Answer Type\",
      \"questions\": [
        {
          \"id\": 1,
          \"question\": \"Question text here (answer should be a number)\",
          \"marks\": 2,
          \"topic\": \"Algorithms\"
        }
      ]
    }
  ]
}";
    
    return $prompt;
}

function callClaudeAPI($url, $apiKey, $prompt) {
    $data = [
        'model' => 'claude-sonnet-4-20250514',
        'max_tokens' => 8192,
        'messages' => [
            [
                'role' => 'user',
                'content' => $prompt
            ]
        ]
    ];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'x-api-key: ' . $apiKey,
        'anthropic-version: 2023-06-01'
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    
    if ($curlError) {
        return ['error' => 'Connection error: ' . $curlError];
    }
    
    if ($httpCode !== 200) {
        $errorData = json_decode($response, true);
        $errorMsg = isset($errorData['error']['message']) ? $errorData['error']['message'] : 'API request failed with code ' . $httpCode;
        return ['error' => $errorMsg];
    }
    
    $result = json_decode($response, true);
    
    if (isset($result['content'][0]['text'])) {
        $text = $result['content'][0]['text'];
        // Clean the response - remove markdown code blocks if present
        $text = preg_replace('/```json\s*/', '', $text);
        $text = preg_replace('/```\s*/', '', $text);
        $text = trim($text);
        
        return ['success' => true, 'data' => $text];
    }
    
    return ['error' => 'Invalid API response'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GATE CS Paper Generator - GATEX</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        :root {
            --primary-glow: #00ffff;
            --secondary-glow: #ff00ff;
            --accent-gold: #ffd700;
            --dark-space: #0a0e27;
            --card-bg: rgba(15, 23, 42, 0.8);
            --border-glow: rgba(0, 255, 255, 0.3);
        }
        
        body {
            font-family: 'Rajdhani', sans-serif;
            background: radial-gradient(ellipse at bottom, #1b2735 0%, #090a0f 100%);
            color: #ffffff;
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;
        }
        
        /* Stars Animation */
        .stars {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        }
        
        .star {
            position: absolute;
            width: 2px;
            height: 2px;
            background: white;
            border-radius: 50%;
            animation: twinkle 3s infinite;
        }
        
        @keyframes twinkle {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 1; }
        }
        
        /* Comet Animation */
        .comet {
            position: fixed;
            width: 2px;
            height: 2px;
            background: var(--primary-glow);
            border-radius: 50%;
            box-shadow: 0 0 10px var(--primary-glow),
                        -100px 0 50px var(--primary-glow),
                        -200px 0 30px rgba(0, 255, 255, 0.3);
            animation: comet-fly 8s linear infinite;
            z-index: 2;
        }
        
        @keyframes comet-fly {
            0% {
                transform: translate(100vw, -100px) rotate(-45deg);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translate(-100px, 100vh) rotate(-45deg);
                opacity: 0;
            }
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            position: relative;
            z-index: 10;
        }
        
        /* Header */
        .header {
            text-align: center;
            padding: 40px 20px;
            background: linear-gradient(135deg, rgba(0, 255, 255, 0.1), rgba(255, 0, 255, 0.1));
            border-radius: 20px;
            border: 2px solid var(--border-glow);
            margin-bottom: 30px;
            backdrop-filter: blur(10px);
            animation: glow-pulse 3s ease-in-out infinite;
        }
        
        @keyframes glow-pulse {
            0%, 100% {
                box-shadow: 0 0 20px rgba(0, 255, 255, 0.3),
                           inset 0 0 20px rgba(0, 255, 255, 0.1);
            }
            50% {
                box-shadow: 0 0 40px rgba(0, 255, 255, 0.5),
                           inset 0 0 30px rgba(0, 255, 255, 0.2);
            }
        }
        
        .logo {
            font-family: 'Orbitron', sans-serif;
            font-size: 3em;
            font-weight: 900;
            background: linear-gradient(135deg, var(--primary-glow), var(--secondary-glow), var(--accent-gold));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 10px;
            text-shadow: 0 0 30px rgba(0, 255, 255, 0.5);
            letter-spacing: 3px;
        }
        
        .subtitle {
            font-size: 1.3em;
            color: var(--primary-glow);
            font-weight: 500;
            letter-spacing: 2px;
        }
        
        .ai-badge {
            display: inline-block;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 0.9em;
            margin-top: 10px;
            font-weight: 600;
            letter-spacing: 1px;
            border: 2px solid rgba(255, 255, 255, 0.3);
        }
        
        /* Configuration Panel */
        .config-panel {
            background: var(--card-bg);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid var(--border-glow);
            backdrop-filter: blur(10px);
        }
        
        .config-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.8em;
            margin-bottom: 20px;
            color: var(--primary-glow);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .config-title::before {
            content: '⚙️';
            font-size: 0.9em;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 10px;
            font-size: 1.1em;
            color: var(--accent-gold);
            font-weight: 600;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid var(--border-glow);
            border-radius: 8px;
            color: white;
            font-size: 1em;
            font-family: 'Rajdhani', sans-serif;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--primary-glow);
            box-shadow: 0 0 20px rgba(0, 255, 255, 0.3);
        }
        
        /* Section Controls */
        .sections-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .section-card {
            background: linear-gradient(135deg, rgba(0, 255, 255, 0.05), rgba(255, 0, 255, 0.05));
            border: 2px solid var(--border-glow);
            border-radius: 12px;
            padding: 20px;
            transition: all 0.3s;
        }
        
        .section-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 255, 255, 0.3);
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .section-name {
            font-size: 1.3em;
            font-weight: 700;
            color: var(--primary-glow);
        }
        
        .toggle-switch {
            position: relative;
            width: 60px;
            height: 30px;
        }
        
        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid var(--border-glow);
            transition: 0.4s;
            border-radius: 30px;
        }
        
        .slider:before {
            position: absolute;
            content: "";
            height: 20px;
            width: 20px;
            left: 3px;
            bottom: 3px;
            background: white;
            transition: 0.4s;
            border-radius: 50%;
        }
        
        input:checked + .slider {
            background: var(--primary-glow);
            box-shadow: 0 0 20px var(--primary-glow);
        }
        
        input:checked + .slider:before {
            transform: translateX(28px);
        }
        
        .section-inputs {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }
        
        .mini-input {
            padding: 8px 12px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--border-glow);
            border-radius: 6px;
            color: white;
            font-size: 0.95em;
        }
        
        /* Generate Button */
        .generate-btn {
            width: 100%;
            padding: 18px;
            font-size: 1.4em;
            font-weight: 700;
            font-family: 'Orbitron', sans-serif;
            background: linear-gradient(135deg, var(--primary-glow), var(--secondary-glow));
            border: none;
            border-radius: 12px;
            color: var(--dark-space);
            cursor: pointer;
            transition: all 0.3s;
            letter-spacing: 2px;
            margin-top: 20px;
            position: relative;
            overflow: hidden;
        }
        
        .generate-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s;
        }
        
        .generate-btn:hover::before {
            left: 100%;
        }
        
        .generate-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(0, 255, 255, 0.5);
        }
        
        .generate-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        /* Loading Animation */
        .loading {
            text-align: center;
            padding: 40px;
            display: none;
        }
        
        .loading.active {
            display: block;
        }
        
        .spinner {
            width: 60px;
            height: 60px;
            border: 4px solid rgba(0, 255, 255, 0.1);
            border-top: 4px solid var(--primary-glow);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .loading-text {
            font-size: 1.2em;
            color: var(--primary-glow);
            animation: pulse 1.5s ease-in-out infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 0.5; }
            50% { opacity: 1; }
        }
        
        /* Paper Display */
        .paper-container {
            background: var(--card-bg);
            border-radius: 15px;
            padding: 30px;
            border: 1px solid var(--border-glow);
            backdrop-filter: blur(10px);
            display: none;
            animation: slideIn 0.5s ease-out;
        }
        
        .paper-container.active {
            display: block;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .paper-header {
            text-align: center;
            border-bottom: 2px solid var(--primary-glow);
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .paper-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 2em;
            color: var(--accent-gold);
            margin-bottom: 10px;
        }
        
        .paper-meta {
            color: var(--primary-glow);
            font-size: 1.1em;
        }
        
        .section {
            margin-bottom: 40px;
        }
        
        .section-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.6em;
            color: var(--secondary-glow);
            margin-bottom: 20px;
            padding: 10px;
            background: linear-gradient(90deg, rgba(255, 0, 255, 0.1), transparent);
            border-left: 4px solid var(--secondary-glow);
        }
        
        .question {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(0, 255, 255, 0.2);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            transition: all 0.3s;
        }
        
        .question:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: var(--primary-glow);
        }
        
        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 15px;
        }
        
        .question-number {
            font-weight: 700;
            color: var(--accent-gold);
            font-size: 1.1em;
        }
        
        .question-marks {
            background: var(--primary-glow);
            color: var(--dark-space);
            padding: 4px 12px;
            border-radius: 20px;
            font-weight: 700;
            font-size: 0.9em;
        }
        
        .question-text {
            font-size: 1.1em;
            line-height: 1.6;
            margin-bottom: 15px;
            color: #e0e0e0;
        }
        
        .options {
            margin-left: 20px;
        }
        
        .option {
            padding: 10px;
            margin-bottom: 8px;
            border-left: 3px solid rgba(0, 255, 255, 0.3);
            padding-left: 15px;
            transition: all 0.3s;
        }
        
        .option:hover {
            border-left-color: var(--primary-glow);
            background: rgba(0, 255, 255, 0.05);
        }
        
        .topic-tag {
            display: inline-block;
            background: rgba(255, 215, 0, 0.1);
            color: var(--accent-gold);
            padding: 4px 12px;
            border-radius: 15px;
            font-size: 0.85em;
            margin-top: 10px;
            border: 1px solid rgba(255, 215, 0, 0.3);
        }
        
        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            flex-wrap: wrap;
        }
        
        .action-btn {
            flex: 1;
            min-width: 150px;
            padding: 12px 20px;
            font-size: 1.1em;
            font-weight: 600;
            border: 2px solid var(--primary-glow);
            background: transparent;
            color: var(--primary-glow);
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Rajdhani', sans-serif;
        }
        
        .action-btn:hover {
            background: var(--primary-glow);
            color: var(--dark-space);
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(0, 255, 255, 0.4);
        }
        
        /* Footer */
        .footer {
            text-align: center;
            padding: 30px 20px;
            margin-top: 50px;
            border-top: 2px solid var(--border-glow);
            background: rgba(10, 14, 39, 0.5);
            backdrop-filter: blur(10px);
        }
        
        .branding {
            font-size: 0.95em;
            color: var(--primary-glow);
            line-height: 1.8;
        }
        
        .brand-highlight {
            color: var(--accent-gold);
            font-weight: 700;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .logo {
                font-size: 2em;
            }
            
            .subtitle {
                font-size: 1em;
            }
            
            .sections-grid {
                grid-template-columns: 1fr;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .action-btn {
                width: 100%;
            }
        }
        
        .error-message {
            background: rgba(255, 0, 0, 0.1);
            border: 2px solid rgba(255, 0, 0, 0.5);
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            color: #ff6b6b;
            display: none;
        }
        
        .error-message.active {
            display: block;
        }
    </style>
</head>
<body>
    <!-- Stars Background -->
    <div class="stars" id="stars"></div>
    
    <!-- Comets -->
    <div class="comet" style="animation-delay: 0s; top: 10%;"></div>
    <div class="comet" style="animation-delay: 3s; top: 40%;"></div>
    <div class="comet" style="animation-delay: 6s; top: 70%;"></div>
    
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="logo">GATEX</div>
            <div class="subtitle">GATE Computer Science Paper Generator</div>
           
        </div>
        
        <!-- Configuration Panel -->
        <div class="config-panel">
            <div class="config-title">⚙️ Configure Your Paper</div>
            
            <div class="form-group">
                <label class="form-label">Difficulty Level</label>
                <select id="difficulty" class="form-control">
                    <option value="Easy">Easy</option>
                    <option value="Medium" selected>Medium</option>
                    <option value="Hard">Hard</option>
                    <option value="Mixed">Mixed (Realistic GATE Level)</option>
                </select>
            </div>
            
            <div class="form-group">
                <label class="form-label">Total Marks</label>
                <input type="number" id="totalMarks" class="form-control" value="100" min="50" max="200">
            </div>
            
            <div class="form-group">
                <label class="form-label">Question Sections</label>
                <div class="sections-grid">
                    <div class="section-card">
                        <div class="section-header">
                            <span class="section-name">MCQ</span>
                            <label class="toggle-switch">
                                <input type="checkbox" id="mcq-toggle" checked>
                                <span class="slider"></span>
                            </label>
                        </div>
                        <div class="section-inputs">
                            <input type="number" id="mcq-count" class="mini-input" placeholder="Questions" value="25" min="1" max="50">
                            <input type="number" id="mcq-marks" class="mini-input" placeholder="Marks each" value="2" min="1" max="5">
                        </div>
                    </div>
                    
                    <div class="section-card">
                        <div class="section-header">
                            <span class="section-name">MSQ</span>
                            <label class="toggle-switch">
                                <input type="checkbox" id="msq-toggle" checked>
                                <span class="slider"></span>
                            </label>
                        </div>
                        <div class="section-inputs">
                            <input type="number" id="msq-count" class="mini-input" placeholder="Questions" value="10" min="1" max="30">
                            <input type="number" id="msq-marks" class="mini-input" placeholder="Marks each" value="2" min="1" max="5">
                        </div>
                    </div>
                    
                    <div class="section-card">
                        <div class="section-header">
                            <span class="section-name">NAT</span>
                            <label class="toggle-switch">
                                <input type="checkbox" id="nat-toggle" checked>
                                <span class="slider"></span>
                            </label>
                        </div>
                        <div class="section-inputs">
                            <input type="number" id="nat-count" class="mini-input" placeholder="Questions" value="15" min="1" max="30">
                            <input type="number" id="nat-marks" class="mini-input" placeholder="Marks each" value="2" min="1" max="5">
                        </div>
                    </div>
                </div>
            </div>
            
            <button class="generate-btn" id="generateBtn" onclick="generatePaper()">
                🚀 GENERATE PAPER WITH CLAUDE AI
            </button>
        </div>
        
        <!-- Loading Animation -->
        <div class="loading" id="loading">
            <div class="spinner"></div>
            <div class="loading-text">Claude AI is generating your GATE paper... Please wait...</div>
        </div>
        
        <!-- Error Message -->
        <div class="error-message" id="errorMessage"></div>
        
        <!-- Paper Display -->
        <div class="paper-container" id="paperContainer">
            <div class="paper-header">
                <div class="paper-title">GATE Computer Science & IT</div>
                <div class="paper-meta">
                    <span id="paperMarks"></span> | <span id="paperDuration"></span> | <span id="paperDifficulty"></span>
                </div>
            </div>
            
            <div id="paperContent"></div>
            
            <div class="action-buttons">
                <button class="action-btn" onclick="downloadPaper()">📥 Download PDF</button>
                <button class="action-btn" onclick="printPaper()">🖨️ Print Paper</button>
                <button class="action-btn" onclick="sharePaper()">📤 Share</button>
                <button class="action-btn" onclick="resetForm()">🔄 Generate New</button>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="footer">
            <div class="branding">
                © 2025 <span class="brand-highlight">GATEX</span><br>
                Product of <span class="brand-highlight">Tech Eagles</span> under <span class="brand-highlight">Mahakumbrix Innovation</span><br>
                Powered By <span class="brand-highlight">Rocket Examica</span>. All Rights Reserved.
            </div>
        </div>
    </div>
    
    <script>
        // Generate stars
        function createStars() {
            const starsContainer = document.getElementById('stars');
            const starCount = 200;
            
            for (let i = 0; i < starCount; i++) {
                const star = document.createElement('div');
                star.className = 'star';
                star.style.left = Math.random() * 100 + '%';
                star.style.top = Math.random() * 100 + '%';
                star.style.animationDelay = Math.random() * 3 + 's';
                star.style.opacity = Math.random() * 0.7 + 0.3;
                starsContainer.appendChild(star);
            }
        }
        
        createStars();
        
        // Generate Paper
        async function generatePaper() {
            const generateBtn = document.getElementById('generateBtn');
            const loading = document.getElementById('loading');
            const paperContainer = document.getElementById('paperContainer');
            const errorMessage = document.getElementById('errorMessage');
            
            // Get configuration
            const sections = {
                'MCQ': {
                    enabled: document.getElementById('mcq-toggle').checked,
                    questions: parseInt(document.getElementById('mcq-count').value),
                    marks: parseInt(document.getElementById('mcq-marks').value)
                },
                'MSQ': {
                    enabled: document.getElementById('msq-toggle').checked,
                    questions: parseInt(document.getElementById('msq-count').value),
                    marks: parseInt(document.getElementById('msq-marks').value)
                },
                'NAT': {
                    enabled: document.getElementById('nat-toggle').checked,
                    questions: parseInt(document.getElementById('nat-count').value),
                    marks: parseInt(document.getElementById('nat-marks').value)
                }
            };
            
            const difficulty = document.getElementById('difficulty').value;
            const totalMarks = document.getElementById('totalMarks').value;
            
            // Validate
            const enabledSections = Object.values(sections).filter(s => s.enabled);
            if (enabledSections.length === 0) {
                showError('Please enable at least one section!');
                return;
            }
            
            // Show loading
            generateBtn.disabled = true;
            loading.classList.add('active');
            paperContainer.classList.remove('active');
            errorMessage.classList.remove('active');
            
            try {
                const formData = new FormData();
                formData.append('action', 'generate_paper');
                formData.append('sections', JSON.stringify(sections));
                formData.append('difficulty', difficulty);
                formData.append('total_marks', totalMarks);
                
                const response = await fetch('', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.error) {
                    throw new Error(result.error);
                }
                
                if (result.success) {
                    const paperData = JSON.parse(result.data);
                    displayPaper(paperData, difficulty, totalMarks);
                } else {
                    throw new Error('Failed to generate paper');
                }
                
            } catch (error) {
                console.error('Error:', error);
                showError('Failed to generate paper: ' + error.message + '. Please check your API key and internet connection.');
            } finally {
                generateBtn.disabled = false;
                loading.classList.remove('active');
            }
        }
        
        function showError(message) {
            const errorMessage = document.getElementById('errorMessage');
            errorMessage.textContent = message;
            errorMessage.classList.add('active');
            setTimeout(() => {
                errorMessage.classList.remove('active');
            }, 5000);
        }
        
        function displayPaper(paperData, difficulty, totalMarks) {
            const paperContainer = document.getElementById('paperContainer');
            const paperContent = document.getElementById('paperContent');
            
            document.getElementById('paperMarks').textContent = `Total Marks: ${totalMarks}`;
            document.getElementById('paperDuration').textContent = '180 Minutes';
            document.getElementById('paperDifficulty').textContent = `Difficulty: ${difficulty}`;
            
            let html = '';
            
            if (paperData.sections && Array.isArray(paperData.sections)) {
                paperData.sections.forEach(section => {
                    html += `<div class="section">
                        <div class="section-title">${section.title || section.type}</div>`;
                    
                    if (section.questions && Array.isArray(section.questions)) {
                        section.questions.forEach((q, index) => {
                            html += `<div class="question">
                                <div class="question-header">
                                    <span class="question-number">Q${q.id || index + 1}.</span>
                                    <span class="question-marks">${q.marks || 2} Mark${(q.marks || 2) > 1 ? 's' : ''}</span>
                                </div>
                                <div class="question-text">${q.question}</div>`;
                            
                            if (q.options && Array.isArray(q.options)) {
                                html += '<div class="options">';
                                q.options.forEach(option => {
                                    html += `<div class="option">${option}</div>`;
                                });
                                html += '</div>';
                            }
                            
                            if (q.topic) {
                                html += `<span class="topic-tag">📚 ${q.topic}</span>`;
                            }
                            
                            html += '</div>';
                        });
                    }
                    
                    html += '</div>';
                });
            }
            
            paperContent.innerHTML = html;
            paperContainer.classList.add('active');
            paperContainer.scrollIntoView({ behavior: 'smooth' });
        }
        
        function downloadPaper() {
            window.print();
        }
        
        function printPaper() {
            window.print();
        }
        
        function sharePaper() {
            if (navigator.share) {
                navigator.share({
                    title: 'GATE CS Paper - GATEX',
                    text: 'Check out this GATE Computer Science practice paper generated by Claude AI!',
                    url: window.location.href
                }).catch(err => console.log('Error sharing:', err));
            } else {
                const url = window.location.href;
                navigator.clipboard.writeText(url).then(() => {
                    alert('Link copied to clipboard!');
                });
            }
        }
        
        function resetForm() {
            document.getElementById('paperContainer').classList.remove('active');
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    </script>
</body>
</html>
