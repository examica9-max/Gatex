<?php
/* === PERSISTENT SESSION PROTECTION === */

// Start session with 1 year lifetime
if (session_status() === PHP_SESSION_NONE) {
    ini_set("session.gc_maxlifetime", 31536000); // 1 year
    session_set_cookie_params(31536000);
    session_start();
}

// Check if user has premium access
if (!isset($_SESSION["premium_access"]) || $_SESSION["premium_access"] !== true) {
    header("Location: ../../index.php");
    exit;
}

// Validate code has not expired
if (isset($_SESSION["code_expiry"])) {
    $expiry = strtotime($_SESSION["code_expiry"]);
    $today = strtotime(date("Y-m-d"));
    
    if ($today > $expiry) {
        session_destroy();
        header("Location: ../../index.php?error=expired");
        exit;
    }
}

/* === END PERSISTENT SESSION PROTECTION === */
?>

<?php
// GATE Computer Science Last Minute Revision Notes Generator
// API Configuration
$GEMINI_API_KEY = 'AIzaSyAeQnuYI6Fl2zSNIqxJxoU8BVy7m1O5pOg';
$GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

$response_data = null;
$error_message = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action === 'generate_notes') {
        $topic = isset($_POST['topic']) ? trim($_POST['topic']) : '';
        $subtopic = isset($_POST['subtopic']) ? trim($_POST['subtopic']) : '';
        
        if (empty($topic)) {
            $error_message = "Please select a topic";
        } else {
            // Create the prompt for notes generation
            $prompt = "Generate comprehensive GATE Computer Science last-minute revision notes for the topic: $topic";
            if (!empty($subtopic)) {
                $prompt .= " focusing on: $subtopic";
            }
            $prompt .= "\n\nProvide:\n1. Key Concepts (5-7 bullet points)\n2. Important Formulas/Algorithms (if applicable)\n3. Quick Tips & Tricks\n4. Common Mistakes to Avoid\n5. Previous Year Question Trends\n\nFormat the response in clear sections with headings. Be concise but comprehensive for last-minute revision.";
            
            // Prepare API request
            $data = [
                'contents' => [
                    [
                        'parts' => [
                            ['text' => $prompt]
                        ]
                    ]
                ],
                'generationConfig' => [
                    'temperature' => 0.7,
                    'maxOutputTokens' => 2048
                ]
            ];
            
            // Make API call
            $ch = curl_init($GEMINI_API_URL . '?key=' . $GEMINI_API_KEY);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            
            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($http_code === 200) {
                $result = json_decode($response, true);
                if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
                    $response_data = [
                        'topic' => $topic,
                        'subtopic' => $subtopic,
                        'content' => $result['candidates'][0]['content']['parts'][0]['text']
                    ];
                } else {
                    $error_message = "Invalid response from API";
                }
            } else {
                $error_message = "API Error: HTTP $http_code";
            }
        }
    }
    
    // Return JSON for AJAX requests
    header('Content-Type: application/json');
    echo json_encode([
        'success' => $response_data !== null,
        'data' => $response_data,
        'error' => $error_message
    ]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GATE CS Notes Generator - Last Minute Revision</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --secondary-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --accent-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            --success-gradient: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            --dark-bg: #0f0f23;
            --card-bg: rgba(255, 255, 255, 0.05);
            --glass-bg: rgba(255, 255, 255, 0.08);
            --text-primary: #ffffff;
            --text-secondary: #b8b9cc;
            --border-color: rgba(255, 255, 255, 0.1);
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--dark-bg);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;
        }

        /* Animated Background */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 30%, rgba(102, 126, 234, 0.15) 0%, transparent 50%),
                radial-gradient(circle at 80% 70%, rgba(118, 75, 162, 0.15) 0%, transparent 50%),
                radial-gradient(circle at 50% 50%, rgba(75, 172, 254, 0.1) 0%, transparent 50%);
            animation: backgroundMove 20s ease-in-out infinite;
            z-index: -1;
        }

        @keyframes backgroundMove {
            0%, 100% { transform: scale(1) translate(0, 0); }
            50% { transform: scale(1.1) translate(20px, 20px); }
        }

        /* Floating Particles */
        .particle {
            position: fixed;
            width: 4px;
            height: 4px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            pointer-events: none;
            animation: float 15s infinite;
            z-index: 0;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0) translateX(0); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(-100vh) translateX(100px); opacity: 0; }
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
            position: relative;
            z-index: 1;
        }

        /* Header */
        .header {
            text-align: center;
            padding: 40px 20px;
            margin-bottom: 30px;
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid var(--border-color);
            animation: slideDown 0.6s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .header h1 {
            font-size: clamp(2rem, 5vw, 3rem);
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 10px;
            font-weight: 700;
        }

        .header .subtitle {
            font-size: clamp(1rem, 2.5vw, 1.2rem);
            color: var(--text-secondary);
            font-weight: 500;
        }

        .badge {
            display: inline-block;
            padding: 8px 20px;
            background: var(--accent-gradient);
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
            margin-top: 15px;
            animation: pulse 2s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        /* Main Content Grid */
        .content-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 25px;
            animation: fadeIn 0.8s ease-out 0.2s both;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (min-width: 1024px) {
            .content-grid {
                grid-template-columns: 380px 1fr;
            }
        }

        /* Topic Selection Card */
        .selection-card {
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            border: 1px solid var(--border-color);
            height: fit-content;
            position: sticky;
            top: 20px;
        }

        .selection-card h2 {
            font-size: 1.5rem;
            margin-bottom: 25px;
            background: var(--secondary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: var(--text-primary);
            font-size: 0.95rem;
        }

        .form-control {
            width: 100%;
            padding: 14px 18px;
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid var(--border-color);
            border-radius: 12px;
            color: var(--text-primary);
            font-size: 1rem;
            transition: all 0.3s ease;
            font-family: inherit;
        }

        .form-control:focus {
            outline: none;
            border-color: #667eea;
            background: rgba(255, 255, 255, 0.08);
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }

        select.form-control {
            cursor: pointer;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
            background-size: 20px;
            padding-right: 45px;
        }

        select.form-control option {
            background: #1a1a2e;
            color: var(--text-primary);
            padding: 10px;
        }

        .btn-generate {
            width: 100%;
            padding: 16px;
            background: var(--primary-gradient);
            border: none;
            border-radius: 12px;
            color: white;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
        }

        .btn-generate:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 12px 30px rgba(102, 126, 234, 0.4);
        }

        .btn-generate:active:not(:disabled) {
            transform: translateY(0);
        }

        .btn-generate:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        /* Notes Display Card */
        .notes-card {
            background: var(--glass-bg);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 35px;
            border: 1px solid var(--border-color);
            min-height: 500px;
        }

        .welcome-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 500px;
            text-align: center;
            opacity: 0.7;
        }

        .welcome-icon {
            font-size: 5rem;
            margin-bottom: 20px;
            animation: bounce 2s ease-in-out infinite;
        }

        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }

        .welcome-state h3 {
            font-size: 1.8rem;
            margin-bottom: 15px;
            color: var(--text-primary);
        }

        .welcome-state p {
            color: var(--text-secondary);
            font-size: 1.1rem;
        }

        /* Loading State */
        .loading-state {
            display: none;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 500px;
        }

        .loading-state.active {
            display: flex;
        }

        .loader {
            width: 60px;
            height: 60px;
            border: 5px solid rgba(255, 255, 255, 0.1);
            border-top: 5px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .loading-text {
            font-size: 1.2rem;
            color: var(--text-secondary);
        }

        /* Notes Content */
        .notes-content {
            display: none;
        }

        .notes-content.active {
            display: block;
            animation: fadeIn 0.6s ease-out;
        }

        .notes-header {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--border-color);
        }

        .notes-title {
            font-size: 2rem;
            background: var(--accent-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 8px;
        }

        .notes-subtitle {
            color: var(--text-secondary);
            font-size: 1.1rem;
        }

        .notes-body {
            line-height: 1.8;
            font-size: 1.05rem;
        }

        .notes-body h2 {
            color: #667eea;
            margin-top: 30px;
            margin-bottom: 15px;
            font-size: 1.5rem;
        }

        .notes-body h3 {
            color: #f5576c;
            margin-top: 20px;
            margin-bottom: 12px;
            font-size: 1.2rem;
        }

        .notes-body p {
            margin-bottom: 15px;
            color: var(--text-secondary);
        }

        .notes-body ul, .notes-body ol {
            margin-left: 25px;
            margin-bottom: 15px;
        }

        .notes-body li {
            margin-bottom: 10px;
            color: var(--text-secondary);
            line-height: 1.6;
        }

        .notes-body strong {
            color: var(--text-primary);
            font-weight: 600;
        }

        .notes-body code {
            background: rgba(102, 126, 234, 0.2);
            padding: 3px 8px;
            border-radius: 5px;
            font-family: 'Courier New', monospace;
            color: #00f2fe;
        }

        .notes-body pre {
            background: rgba(0, 0, 0, 0.3);
            padding: 15px;
            border-radius: 10px;
            overflow-x: auto;
            margin: 15px 0;
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            flex-wrap: wrap;
        }

        .btn-action {
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-download {
            background: var(--success-gradient);
            color: white;
            box-shadow: 0 5px 15px rgba(67, 233, 123, 0.3);
        }

        .btn-download:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(67, 233, 123, 0.4);
        }

        .btn-share {
            background: var(--accent-gradient);
            color: white;
            box-shadow: 0 5px 15px rgba(79, 172, 254, 0.3);
        }

        .btn-share:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(79, 172, 254, 0.4);
        }

        .btn-new {
            background: var(--secondary-gradient);
            color: white;
            box-shadow: 0 5px 15px rgba(245, 87, 108, 0.3);
        }

        .btn-new:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(245, 87, 108, 0.4);
        }

        /* Error Message */
        .error-message {
            display: none;
            background: rgba(245, 87, 108, 0.2);
            border: 2px solid #f5576c;
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            color: #ff6b81;
            font-weight: 500;
        }

        .error-message.active {
            display: block;
            animation: shake 0.5s ease-in-out;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-10px); }
            75% { transform: translateX(10px); }
        }

        /* Footer */
        .footer {
            text-align: center;
            padding: 30px;
            margin-top: 50px;
            color: var(--text-secondary);
            font-size: 0.95rem;
        }

        .footer-brand {
            font-weight: 700;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .header {
                padding: 30px 15px;
            }

            .selection-card, .notes-card {
                padding: 20px;
            }

            .notes-title {
                font-size: 1.5rem;
            }

            .action-buttons {
                flex-direction: column;
            }

            .btn-action {
                width: 100%;
                justify-content: center;
            }

            .container {
                padding: 15px;
            }
        }

        /* Print Styles */
        @media print {
            body {
                background: white;
                color: black;
            }

            .header, .selection-card, .action-buttons, .footer {
                display: none;
            }

            .notes-card {
                box-shadow: none;
                border: none;
            }
        }
    </style>
</head>
<body>
    <!-- Floating Particles -->
    <div class="particle" style="left: 10%; animation-delay: 0s;"></div>
    <div class="particle" style="left: 20%; animation-delay: 2s;"></div>
    <div class="particle" style="left: 30%; animation-delay: 4s;"></div>
    <div class="particle" style="left: 40%; animation-delay: 1s;"></div>
    <div class="particle" style="left: 50%; animation-delay: 3s;"></div>
    <div class="particle" style="left: 60%; animation-delay: 5s;"></div>
    <div class="particle" style="left: 70%; animation-delay: 2.5s;"></div>
    <div class="particle" style="left: 80%; animation-delay: 4.5s;"></div>
    <div class="particle" style="left: 90%; animation-delay: 1.5s;"></div>

    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>🎯 GATE CS Notes Generator</h1>
            <p class="subtitle">AI-Powered Last Minute Revision Notes</p>
            <span class="badge">⚡ Quick Revision Mode</span>
        </div>

        <!-- Main Content Grid -->
        <div class="content-grid">
            <!-- Topic Selection Sidebar -->
            <div class="selection-card">
                <h2>📚 Select Topic</h2>
                
                <div class="error-message" id="errorMessage"></div>

                <form id="notesForm">
                    <div class="form-group">
                        <label for="topic">Main Topic *</label>
                        <select id="topic" name="topic" class="form-control" required>
                            <option value="">Choose a topic...</option>
                            <optgroup label="📊 Data Structures">
                                <option value="Arrays and Strings">Arrays and Strings</option>
                                <option value="Linked Lists">Linked Lists</option>
                                <option value="Stacks and Queues">Stacks and Queues</option>
                                <option value="Trees (Binary, BST, AVL, B-Trees)">Trees (Binary, BST, AVL, B-Trees)</option>
                                <option value="Heaps">Heaps</option>
                                <option value="Hashing">Hashing</option>
                                <option value="Graphs">Graphs</option>
                            </optgroup>
                            <optgroup label="🧮 Algorithms">
                                <option value="Sorting Algorithms">Sorting Algorithms</option>
                                <option value="Searching Algorithms">Searching Algorithms</option>
                                <option value="Greedy Algorithms">Greedy Algorithms</option>
                                <option value="Dynamic Programming">Dynamic Programming</option>
                                <option value="Divide and Conquer">Divide and Conquer</option>
                                <option value="Graph Algorithms (BFS, DFS, Dijkstra, etc.)">Graph Algorithms</option>
                                <option value="Backtracking">Backtracking</option>
                            </optgroup>
                            <optgroup label="💻 Operating Systems">
                                <option value="Process Management">Process Management</option>
                                <option value="CPU Scheduling">CPU Scheduling</option>
                                <option value="Deadlocks">Deadlocks</option>
                                <option value="Memory Management">Memory Management</option>
                                <option value="Virtual Memory">Virtual Memory</option>
                                <option value="File Systems">File Systems</option>
                                <option value="Disk Scheduling">Disk Scheduling</option>
                            </optgroup>
                            <optgroup label="🗄️ Database Management">
                                <option value="ER Model and Normalization">ER Model and Normalization</option>
                                <option value="SQL Queries">SQL Queries</option>
                                <option value="Transactions and Concurrency">Transactions and Concurrency</option>
                                <option value="Indexing and B+ Trees">Indexing and B+ Trees</option>
                                <option value="File Organization">File Organization</option>
                                <option value="Query Optimization">Query Optimization</option>
                            </optgroup>
                            <optgroup label="🌐 Computer Networks">
                                <option value="OSI and TCP/IP Model">OSI and TCP/IP Model</option>
                                <option value="Data Link Layer">Data Link Layer</option>
                                <option value="Network Layer (IP, Routing)">Network Layer</option>
                                <option value="Transport Layer (TCP, UDP)">Transport Layer</option>
                                <option value="Application Layer">Application Layer</option>
                                <option value="Network Security">Network Security</option>
                            </optgroup>
                            <optgroup label="🖥️ Computer Organization">
                                <option value="Number Systems">Number Systems</option>
                                <option value="Boolean Algebra">Boolean Algebra</option>
                                <option value="Digital Logic">Digital Logic</option>
                                <option value="Combinational Circuits">Combinational Circuits</option>
                                <option value="Sequential Circuits">Sequential Circuits</option>
                                <option value="Computer Arithmetic">Computer Arithmetic</option>
                                <option value="Instruction Set Architecture">Instruction Set Architecture</option>
                                <option value="Pipelining">Pipelining</option>
                                <option value="Cache Memory">Cache Memory</option>
                                <option value="I/O Organization">I/O Organization</option>
                            </optgroup>
                            <optgroup label="🔤 Theory of Computation">
                                <option value="Finite Automata">Finite Automata</option>
                                <option value="Regular Expressions">Regular Expressions</option>
                                <option value="Context-Free Grammars">Context-Free Grammars</option>
                                <option value="Pushdown Automata">Pushdown Automata</option>
                                <option value="Turing Machines">Turing Machines</option>
                                <option value="Decidability">Decidability</option>
                                <option value="Complexity Classes (P, NP)">Complexity Classes</option>
                            </optgroup>
                            <optgroup label="⚙️ Compiler Design">
                                <option value="Lexical Analysis">Lexical Analysis</option>
                                <option value="Syntax Analysis (Parsing)">Syntax Analysis</option>
                                <option value="Semantic Analysis">Semantic Analysis</option>
                                <option value="Intermediate Code Generation">Intermediate Code Generation</option>
                                <option value="Code Optimization">Code Optimization</option>
                                <option value="Code Generation">Code Generation</option>
                            </optgroup>
                            <optgroup label="➗ Discrete Mathematics">
                                <option value="Set Theory">Set Theory</option>
                                <option value="Relations and Functions">Relations and Functions</option>
                                <option value="Combinatorics">Combinatorics</option>
                                <option value="Graph Theory">Graph Theory</option>
                                <option value="Probability">Probability</option>
                                <option value="Mathematical Logic">Mathematical Logic</option>
                            </optgroup>
                            <optgroup label="💾 Software Engineering">
                                <option value="SDLC Models">SDLC Models</option>
                                <option value="Software Requirements">Software Requirements</option>
                                <option value="Software Design">Software Design</option>
                                <option value="Software Testing">Software Testing</option>
                                <option value="Software Maintenance">Software Maintenance</option>
                            </optgroup>
                            <optgroup label="🔐 Information Security">
                                <option value="Cryptography Basics">Cryptography Basics</option>
                                <option value="Symmetric Key Cryptography">Symmetric Key Cryptography</option>
                                <option value="Public Key Cryptography">Public Key Cryptography</option>
                                <option value="Digital Signatures">Digital Signatures</option>
                                <option value="Network Security Protocols">Network Security Protocols</option>
                            </optgroup>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="subtopic">Specific Sub-topic (Optional)</label>
                        <input type="text" id="subtopic" name="subtopic" class="form-control" 
                               placeholder="e.g., Dijkstra's Algorithm, FCFS Scheduling...">
                    </div>

                    <button type="submit" class="btn-generate" id="generateBtn">
                        🚀 Generate Notes
                    </button>
                </form>
            </div>

            <!-- Notes Display Area -->
            <div class="notes-card">
                <!-- Welcome State -->
                <div class="welcome-state" id="welcomeState">
                    <div class="welcome-icon">📖</div>
                    <h3>Ready for Last Minute Revision?</h3>
                    <p>Select a topic from the sidebar to generate AI-powered revision notes</p>
                </div>

                <!-- Loading State -->
                <div class="loading-state" id="loadingState">
                    <div class="loader"></div>
                    <div class="loading-text">Generating your revision notes...</div>
                </div>

                <!-- Notes Content -->
                <div class="notes-content" id="notesContent">
                    <div class="notes-header">
                        <h2 class="notes-title" id="notesTitle"></h2>
                        <p class="notes-subtitle" id="notesSubtitle"></p>
                    </div>
                    <div class="notes-body" id="notesBody"></div>
                    
                    <div class="action-buttons">
                        <button class="btn-action btn-download" onclick="downloadNotes()">
                            📥 Download PDF
                        </button>
                        <button class="btn-action btn-share" onclick="copyNotes()">
                            📋 Copy Notes
                        </button>
                        <button class="btn-action btn-new" onclick="generateNew()">
                            ✨ New Topic
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>Powered by <span class="footer-brand">Rocket Examica</span> × <span class="footer-brand">TechEagles</span></p>
            <p>🎓 Good Luck with Your GATE Exam! 🎓</p>
        </div>
    </div>

    <script>
        // Form submission
        document.getElementById('notesForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const topic = document.getElementById('topic').value;
            const subtopic = document.getElementById('subtopic').value;
            const errorMessage = document.getElementById('errorMessage');
            const generateBtn = document.getElementById('generateBtn');
            
            // Hide error message
            errorMessage.classList.remove('active');
            
            // Validation
            if (!topic) {
                showError('Please select a topic');
                return;
            }
            
            // Show loading state
            document.getElementById('welcomeState').style.display = 'none';
            document.getElementById('notesContent').classList.remove('active');
            document.getElementById('loadingState').classList.add('active');
            generateBtn.disabled = true;
            generateBtn.textContent = 'Generating...';
            
            // Prepare form data
            const formData = new FormData();
            formData.append('action', 'generate_notes');
            formData.append('topic', topic);
            formData.append('subtopic', subtopic);
            
            try {
                const response = await fetch('', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    displayNotes(result.data);
                } else {
                    showError(result.error || 'Failed to generate notes');
                    document.getElementById('loadingState').classList.remove('active');
                    document.getElementById('welcomeState').style.display = 'flex';
                }
            } catch (error) {
                showError('Network error. Please try again.');
                document.getElementById('loadingState').classList.remove('active');
                document.getElementById('welcomeState').style.display = 'flex';
            } finally {
                generateBtn.disabled = false;
                generateBtn.textContent = '🚀 Generate Notes';
            }
        });
        
        function displayNotes(data) {
            document.getElementById('loadingState').classList.remove('active');
            
            // Set title and subtitle
            document.getElementById('notesTitle').textContent = data.topic;
            document.getElementById('notesSubtitle').textContent = data.subtopic 
                ? `Focus: ${data.subtopic}` 
                : 'Complete Overview';
            
            // Format and display content
            const formattedContent = formatMarkdown(data.content);
            document.getElementById('notesBody').innerHTML = formattedContent;
            
            // Show notes content
            document.getElementById('notesContent').classList.add('active');
            
            // Scroll to notes
            document.getElementById('notesContent').scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        
        function formatMarkdown(text) {
            // Convert markdown-style formatting to HTML
            let html = text;
            
            // Headers
            html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
            html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
            html = html.replace(/^# (.*$)/gim, '<h2>$1</h2>');
            
            // Bold
            html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
            
            // Lists
            html = html.replace(/^\* (.*$)/gim, '<li>$1</li>');
            html = html.replace(/^\d+\. (.*$)/gim, '<li>$1</li>');
            
            // Wrap consecutive list items in ul/ol
            html = html.replace(/(<li>.*<\/li>\n?)+/g, function(match) {
                return '<ul>' + match + '</ul>';
            });
            
            // Code blocks
            html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
            
            // Line breaks
            html = html.replace(/\n\n/g, '</p><p>');
            html = '<p>' + html + '</p>';
            
            // Clean up empty paragraphs
            html = html.replace(/<p><\/p>/g, '');
            html = html.replace(/<p>(<h[23]>)/g, '$1');
            html = html.replace(/(<\/h[23]>)<\/p>/g, '$1');
            html = html.replace(/<p>(<ul>)/g, '$1');
            html = html.replace(/(<\/ul>)<\/p>/g, '$1');
            
            return html;
        }
        
        function showError(message) {
            const errorElement = document.getElementById('errorMessage');
            errorElement.textContent = message;
            errorElement.classList.add('active');
            
            setTimeout(() => {
                errorElement.classList.remove('active');
            }, 5000);
        }
        
        function downloadNotes() {
            const title = document.getElementById('notesTitle').textContent;
            const content = document.getElementById('notesBody').innerText;
            
            const text = `GATE CS Revision Notes\n\n${title}\n${'='.repeat(50)}\n\n${content}\n\nGenerated by Rocket Examica - TechEagles`;
            
            const blob = new Blob([text], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `GATE_CS_${title.replace(/\s+/g, '_')}.txt`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }
        
        function copyNotes() {
            const title = document.getElementById('notesTitle').textContent;
            const content = document.getElementById('notesBody').innerText;
            const text = `${title}\n\n${content}`;
            
            navigator.clipboard.writeText(text).then(() => {
                const btn = event.target;
                const originalText = btn.innerHTML;
                btn.innerHTML = '✓ Copied!';
                setTimeout(() => {
                    btn.innerHTML = originalText;
                }, 2000);
            });
        }
        
        function generateNew() {
            document.getElementById('notesContent').classList.remove('active');
            document.getElementById('welcomeState').style.display = 'flex';
            document.getElementById('notesForm').reset();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    </script>
</body>
</html>
