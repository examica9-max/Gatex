<?php
/* === PERSISTENT SESSION PROTECTION === */

// Start session with 1 year lifetime
if (session_status() === PHP_SESSION_NONE) {
    ini_set("session.gc_maxlifetime", 31536000); // 1 year
    session_set_cookie_params(31536000);
    session_start();
}

// Check if user has premium access
if (!isset($_SESSION["premium_access"]) || $_SESSION["premium_access"] !== true) {
    header("Location: ../../index.php");
    exit;
}

// Validate code has not expired
if (isset($_SESSION["code_expiry"])) {
    $expiry = strtotime($_SESSION["code_expiry"]);
    $today = strtotime(date("Y-m-d"));
    
    if ($today > $expiry) {
        session_destroy();
        header("Location: ../../index.php?error=expired");
        exit;
    }
}

/* === END PERSISTENT SESSION PROTECTION === */
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GATE CS Companion - Rocket Examica</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a0e27 0%, #1a1f3a 50%, #0a0e27 100%);
            color: #fff;
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;
        }

        .stars {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
        }

        .star {
            position: absolute;
            background: white;
            border-radius: 50%;
            animation: twinkle 3s infinite;
        }

        @keyframes twinkle {
            0%, 100% { opacity: 0.3; transform: scale(1); }
            50% { opacity: 1; transform: scale(1.2); }
        }

        .comet {
            position: fixed;
            width: 3px;
            height: 3px;
            background: #7ee8fa;
            border-radius: 50%;
            box-shadow: 0 0 10px #7ee8fa, 0 0 20px #58a6ff;
            animation: comet-fly 8s linear infinite;
            z-index: 1;
        }

        .comet::before {
            content: '';
            position: absolute;
            width: 100px;
            height: 2px;
            background: linear-gradient(90deg, transparent, #7ee8fa);
            transform: translateX(-100px);
        }

        @keyframes comet-fly {
            0% { transform: translateX(-100px) translateY(-100px); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateX(100vw) translateY(100vh); opacity: 0; }
        }

        .comet:nth-child(1) { top: 10%; animation-delay: 0s; }
        .comet:nth-child(2) { top: 40%; animation-delay: 3s; }
        .comet:nth-child(3) { top: 70%; animation-delay: 6s; }

        .header {
            text-align: center;
            padding: 15px 20px;
            background: linear-gradient(135deg, rgba(255, 107, 107, 0.1), rgba(88, 166, 255, 0.1));
            backdrop-filter: blur(10px);
            border-bottom: 2px solid rgba(126, 232, 250, 0.3);
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            transition: transform 0.3s ease;
        }

        .header.hidden { transform: translateY(-100%); }

        .header h1 {
            font-size: 1.8rem;
            margin: 0;
            background: linear-gradient(135deg, #ff6b6b, #58a6ff, #7ee8fa);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-weight: 800;
        }

        .tagline {
            color: #7ee8fa;
            font-size: 0.9rem;
            margin-top: 5px;
            font-style: italic;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            padding-top: 100px;
            padding-bottom: 100px;
            position: relative;
            z-index: 2;
        }

        .section {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            border: 2px solid rgba(126, 232, 250, 0.2);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .section-title {
            font-size: 1.8rem;
            margin-bottom: 20px;
            color: #7ee8fa;
            text-align: center;
            font-weight: 700;
            text-shadow: 0 0 20px rgba(126, 232, 250, 0.5);
        }

        .subjects-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .subject-card {
            background: linear-gradient(135deg, rgba(88, 166, 255, 0.1), rgba(126, 232, 250, 0.1));
            border: 2px solid rgba(126, 232, 250, 0.3);
            border-radius: 15px;
            padding: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .subject-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
            transition: left 0.5s;
        }

        .subject-card:hover::before { left: 100%; }

        .subject-card:hover {
            transform: translateY(-10px);
            border-color: #ff6b6b;
            box-shadow: 0 10px 30px rgba(255, 107, 107, 0.3);
        }

        .subject-card.selected {
            background: linear-gradient(135deg, rgba(255, 107, 107, 0.3), rgba(88, 166, 255, 0.3));
            border-color: #ff6b6b;
            box-shadow: 0 0 30px rgba(255, 107, 107, 0.5);
        }

        .subject-icon {
            font-size: 3rem;
            margin-bottom: 15px;
            display: block;
        }

        .subject-name {
            font-size: 1.2rem;
            font-weight: 600;
            color: #fff;
        }

        .topics-container {
            display: none;
            margin-top: 20px;
        }

        .topics-container.active { display: block; }

        .topics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }

        .topic-btn {
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid rgba(126, 232, 250, 0.3);
            border-radius: 10px;
            padding: 15px;
            color: #fff;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 1rem;
            font-weight: 500;
        }

        .topic-btn:hover {
            background: rgba(88, 166, 255, 0.2);
            border-color: #58a6ff;
            transform: scale(1.05);
        }

        .topic-btn.selected {
            background: linear-gradient(135deg, #ff6b6b, #58a6ff);
            border-color: #ff6b6b;
            box-shadow: 0 5px 15px rgba(255, 107, 107, 0.4);
        }

        .difficulty-container {
            text-align: center;
            margin: 30px 0;
        }

        .difficulty-btns {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
            margin-top: 20px;
        }

        .difficulty-btn {
            padding: 15px 40px;
            border: 2px solid;
            border-radius: 12px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            position: relative;
            overflow: hidden;
        }

        .difficulty-btn span {
            position: relative;
            z-index: 1;
        }

        .difficulty-easy {
            border-color: #4ade80;
            color: #4ade80;
        }

        .difficulty-easy:hover, .difficulty-easy.selected {
            background: linear-gradient(135deg, #4ade80, #22c55e);
            color: #fff;
            box-shadow: 0 5px 20px rgba(74, 222, 128, 0.4);
        }

        .difficulty-medium {
            border-color: #fbbf24;
            color: #fbbf24;
        }

        .difficulty-medium:hover, .difficulty-medium.selected {
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
            color: #fff;
            box-shadow: 0 5px 20px rgba(251, 191, 36, 0.4);
        }

        .difficulty-hard {
            border-color: #f87171;
            color: #f87171;
        }

        .difficulty-hard:hover, .difficulty-hard.selected {
            background: linear-gradient(135deg, #f87171, #ef4444);
            color: #fff;
            box-shadow: 0 5px 20px rgba(248, 113, 113, 0.4);
        }

        .generate-btn {
            display: block;
            margin: 40px auto;
            padding: 20px 60px;
            background: linear-gradient(135deg, #ff6b6b, #58a6ff);
            border: none;
            border-radius: 15px;
            color: #fff;
            font-size: 1.3rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 10px 30px rgba(255, 107, 107, 0.4);
        }

        .generate-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(255, 107, 107, 0.6);
        }

        .loading {
            display: none;
            text-align: center;
            padding: 40px;
        }

        .loading.active { display: block; }

        .spinner {
            border: 4px solid rgba(126, 232, 250, 0.1);
            border-top: 4px solid #7ee8fa;
            border-radius: 50%;
            width: 60px;
            height: 60px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .loading-text {
            font-size: 1.2rem;
            color: #7ee8fa;
            font-weight: 600;
        }

        .quiz-container { display: none; }
        .quiz-container.active { display: block; }

        .quiz-header {
            background: linear-gradient(135deg, rgba(255, 107, 107, 0.2), rgba(88, 166, 255, 0.2));
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 30px;
            text-align: center;
            border: 2px solid rgba(126, 232, 250, 0.3);
        }

        .quiz-info {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 15px;
        }

        .info-item {
            font-size: 1.1rem;
            color: #7ee8fa;
            font-weight: 600;
        }

        .info-item span {
            color: #fff;
            font-weight: 700;
        }

        .question-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 2px solid rgba(126, 232, 250, 0.2);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            transition: all 0.3s ease;
        }

        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .question-number {
            color: #ff6b6b;
            font-weight: 700;
            font-size: 1.1rem;
        }

        .question-type-badge {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .badge-mcq {
            background: linear-gradient(135deg, #4ade80, #22c55e);
            color: #fff;
        }

        .badge-msq {
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
            color: #fff;
        }

        .badge-numerical {
            background: linear-gradient(135deg, #c792ea, #a855f7);
            color: #fff;
        }

        .question-marks {
            color: #7ee8fa;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .question-text {
            font-size: 1.15rem;
            line-height: 1.6;
            margin-bottom: 20px;
            color: #fff;
            font-weight: 500;
        }

        .options { display: grid; gap: 12px; }

        .option-btn {
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid rgba(126, 232, 250, 0.3);
            border-radius: 10px;
            padding: 15px 20px;
            text-align: left;
            color: #fff;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 1rem;
        }

        .option-btn:hover {
            background: rgba(88, 166, 255, 0.2);
            border-color: #58a6ff;
            transform: translateX(5px);
        }

        .option-btn.selected {
            background: linear-gradient(135deg, rgba(88, 166, 255, 0.3), rgba(126, 232, 250, 0.3));
            border-color: #58a6ff;
        }

        .option-btn.correct {
            background: linear-gradient(135deg, #4ade80, #22c55e);
            border-color: #4ade80;
            color: #fff;
        }

        .option-btn.incorrect {
            background: linear-gradient(135deg, #f87171, #ef4444);
            border-color: #f87171;
            color: #fff;
        }

        .option-btn.disabled { cursor: not-allowed; opacity: 0.7; }

        .numerical-input {
            width: 100%;
            padding: 15px 20px;
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid rgba(126, 232, 250, 0.3);
            border-radius: 10px;
            color: #fff;
            font-size: 1.1rem;
            font-weight: 600;
            text-align: center;
        }

        .numerical-input:focus {
            outline: none;
            border-color: #58a6ff;
            background: rgba(88, 166, 255, 0.1);
        }

        .numerical-input.correct {
            background: linear-gradient(135deg, rgba(74, 222, 128, 0.2), rgba(34, 197, 94, 0.2));
            border-color: #4ade80;
        }

        .numerical-input.incorrect {
            background: linear-gradient(135deg, rgba(248, 113, 113, 0.2), rgba(239, 68, 68, 0.2));
            border-color: #f87171;
        }

        .correct-answer-display {
            margin-top: 10px;
            padding: 10px;
            background: rgba(74, 222, 128, 0.1);
            border: 2px solid #4ade80;
            border-radius: 8px;
            color: #4ade80;
            font-weight: 600;
            display: none;
        }

        .correct-answer-display.show {
            display: block;
        }

        .submit-btn {
            display: block;
            margin: 40px auto;
            padding: 18px 50px;
            background: linear-gradient(135deg, #c792ea, #58a6ff);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-size: 1.2rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 8px 25px rgba(199, 146, 234, 0.4);
        }

        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 35px rgba(199, 146, 234, 0.6);
        }

        .results-container {
            display: none;
            background: linear-gradient(135deg, rgba(255, 107, 107, 0.2), rgba(88, 166, 255, 0.2));
            border: 2px solid rgba(126, 232, 250, 0.5);
            border-radius: 20px;
            padding: 40px;
            margin: 30px 0;
            text-align: center;
            animation: slideIn 0.5s ease;
        }

        .results-container.active { display: block; }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .results-title {
            font-size: 2rem;
            color: #7ee8fa;
            margin-bottom: 20px;
            font-weight: 700;
        }

        .score-display {
            font-size: 3.5rem;
            font-weight: 800;
            margin: 20px 0;
            background: linear-gradient(135deg, #ff6b6b, #58a6ff, #7ee8fa);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .score-breakdown {
            display: flex;
            justify-content: center;
            gap: 40px;
            margin: 30px 0;
            flex-wrap: wrap;
        }

        .score-item { font-size: 1.2rem; }

        .score-item span {
            font-weight: 700;
            font-size: 1.4rem;
        }

        .correct-count { color: #4ade80; }
        .incorrect-count { color: #f87171; }

        .motivational-msg {
            font-size: 1.3rem;
            color: #c792ea;
            margin: 20px 0;
            font-weight: 600;
            font-style: italic;
        }

        .charts-section {
            display: none;
            margin-top: 40px;
        }

        .charts-section.active { display: block; }

        .charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 30px;
            margin-top: 30px;
        }

        .chart-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 2px solid rgba(126, 232, 250, 0.3);
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .chart-title {
            font-size: 1.3rem;
            color: #7ee8fa;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 700;
        }

        .chart-container {
            position: relative;
            height: 280px;
            width: 100%;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }

        .stat-card {
            background: linear-gradient(135deg, rgba(88, 166, 255, 0.1), rgba(126, 232, 250, 0.1));
            border: 2px solid rgba(126, 232, 250, 0.3);
            border-radius: 15px;
            padding: 20px;
            text-align: center;
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 800;
            background: linear-gradient(135deg, #ff6b6b, #58a6ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 8px;
        }

        .stat-label {
            color: #7ee8fa;
            font-size: 0.95rem;
            font-weight: 600;
        }

        .restart-btn {
            margin-top: 30px;
            padding: 15px 40px;
            background: linear-gradient(135deg, #ff6b6b, #c792ea);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 20px rgba(255, 107, 107, 0.4);
        }

        .restart-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 30px rgba(255, 107, 107, 0.6);
        }

        .footer {
            text-align: center;
            padding: 15px 20px;
            background: rgba(10, 14, 39, 0.95);
            backdrop-filter: blur(10px);
            border-top: 2px solid rgba(126, 232, 250, 0.2);
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            transition: transform 0.3s ease;
        }

        .footer.hidden { transform: translateY(100%); }

        .footer-text {
            color: #7ee8fa;
            font-size: 1rem;
            font-weight: 600;
        }

        .footer-tagline {
            color: #c792ea;
            font-size: 0.85rem;
            margin-top: 5px;
            font-style: italic;
        }

        @media (max-width: 768px) {
            .container { padding-top: 90px; padding-bottom: 90px; }
            .header { padding: 12px 15px; }
            .header h1 { font-size: 1.4rem; }
            .tagline { font-size: 0.8rem; }
            .subjects-grid, .charts-grid { grid-template-columns: 1fr; }
            .difficulty-btns { flex-direction: column; }
            .quiz-info, .score-breakdown { flex-direction: column; gap: 10px; }
            .footer { padding: 12px 15px; }
        }
    </style>
</head>
<body>
    <div class="stars" id="starfield"></div>
    <div class="comet"></div>
    <div class="comet"></div>
    <div class="comet"></div>

    <div class="header" id="mainHeader">
        <h1>GATE CS Companion</h1>
        <div class="tagline">under Mahakumbrix Innovation</div>
    </div>

    <div class="container">
        <div id="setupSection">
            <div class="section">
                <h2 class="section-title">Select Subject</h2>
                <div class="subjects-grid" id="subjectsGrid"></div>
                <div id="topicsContainer"></div>
            </div>

            <div class="section">
                <div class="difficulty-container">
                    <h2 class="section-title">Select Difficulty Level</h2>
                    <div class="difficulty-btns">
                        <button class="difficulty-btn difficulty-easy" data-difficulty="easy">
                            <span>⭐ Easy</span>
                        </button>
                        <button class="difficulty-btn difficulty-medium" data-difficulty="medium">
                            <span>⭐⭐ Medium</span>
                        </button>
                        <button class="difficulty-btn difficulty-hard" data-difficulty="hard">
                            <span>⭐⭐⭐ Hard</span>
                        </button>
                    </div>
                </div>
            </div>

            <button class="generate-btn" id="generateBtn">🎯 Generate Practice Set (10 Qs)</button>
        </div>

        <div class="loading" id="loadingSection">
            <div class="spinner"></div>
            <div class="loading-text">Generating GATE CS practice questions...</div>
        </div>

        <div class="quiz-container" id="quizSection">
            <div class="quiz-header">
                <h2 class="section-title">GATE CS Practice Set</h2>
                <div class="quiz-info">
                    <div class="info-item">Subject: <span id="quizSubject"></span></div>
                    <div class="info-item">Topic: <span id="quizTopic"></span></div>
                    <div class="info-item">Difficulty: <span id="quizDifficulty"></span></div>
                    <div class="info-item">Questions: <span>10</span></div>
                </div>
            </div>

            <div id="questionsContainer"></div>
            <button class="submit-btn" id="submitBtn">📊 Submit Answers</button>

            <div class="results-container" id="resultsContainer">
                <h2 class="results-title">📊 Results & Performance Analysis</h2>
                <div class="score-display" id="scoreDisplay"></div>
                <div class="score-breakdown">
                    <div class="score-item">Correct: <span class="correct-count" id="correctCount"></span></div>
                    <div class="score-item">Incorrect: <span class="incorrect-count" id="incorrectCount"></span></div>
                </div>
                <div class="motivational-msg" id="motivationalMsg"></div>

                <div class="charts-section" id="chartsSection">
                    <h3 class="section-title" style="font-size: 1.6rem; margin-top: 40px;">Performance Analytics</h3>
                    
                    <div class="charts-grid">
                        <div class="chart-card">
                            <div class="chart-title">Score Distribution</div>
                            <div class="chart-container">
                                <canvas id="scoreChart"></canvas>
                            </div>
                        </div>

                        <div class="chart-card">
                            <div class="chart-title">Question Type Analysis</div>
                            <div class="chart-container">
                                <canvas id="typeChart"></canvas>
                            </div>
                        </div>

                        <div class="chart-card">
                            <div class="chart-title">Performance Radar</div>
                            <div class="chart-container">
                                <canvas id="radarChart"></canvas>
                            </div>
                        </div>

                        <div class="chart-card">
                            <div class="chart-title">Score Comparison</div>
                            <div class="chart-container">
                                <canvas id="comparisonChart"></canvas>
                            </div>
                        </div>
                    </div>

                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-value" id="accuracyRate">0%</div>
                            <div class="stat-label">Accuracy Rate</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value" id="totalMarks">0</div>
                            <div class="stat-label">Total Marks</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value" id="timeSpent">0m</div>
                            <div class="stat-label">Time Spent</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value" id="gateScore">0</div>
                            <div class="stat-label">GATE Score/100</div>
                        </div>
                    </div>
                </div>

                <button class="restart-btn" id="restartBtn">🔄 Generate New Set</button>
            </div>
        </div>
    </div>

    <div class="footer" id="mainFooter">
        <div class="footer-text">Rocket Examica</div>
        <div class="footer-tagline">under Mahakumbrix Innovation</div>
    </div>

    <script>
        const gateSyllabus = {
            'Programming & DS': {
                icon: '💻',
                topics: ['C Programming', 'Data Structures', 'Arrays & Linked Lists', 'Stacks & Queues', 'Trees & Graphs', 'Hashing', 'Sorting & Searching', 'Recursion', 'Dynamic Programming']
            },
            'Algorithms': {
                icon: '⚡',
                topics: ['Time Complexity', 'Greedy Algorithms', 'Divide & Conquer', 'Graph Algorithms', 'String Algorithms', 'Searching Algorithms', 'Dynamic Programming', 'Backtracking']
            },
            'Theory of Computation': {
                icon: '🔤',
                topics: ['Regular Languages', 'Context-Free Grammar', 'Turing Machines', 'Decidability', 'Complexity Classes', 'Automata Theory', 'Pumping Lemma', 'Regular Expressions']
            },
            'Compiler Design': {
                icon: '⚙️',
                topics: ['Lexical Analysis', 'Syntax Analysis', 'Semantic Analysis', 'Code Generation', 'Code Optimization', 'Parsing Techniques', 'Symbol Table', 'Runtime Environment']
            },
            'Operating Systems': {
                icon: '🖥️',
                topics: ['Process Management', 'CPU Scheduling', 'Deadlock', 'Memory Management', 'Virtual Memory', 'File Systems', 'Synchronization', 'Concurrency']
            },
            'Database Management': {
                icon: '🗄️',
                topics: ['ER Model', 'Relational Model', 'SQL', 'Normalization', 'Transactions', 'Indexing', 'Query Optimization', 'Concurrency Control']
            },
            'Computer Networks': {
                icon: '🌐',
                topics: ['OSI Model', 'TCP/IP', 'Routing Algorithms', 'Network Layer', 'Transport Layer', 'Application Layer', 'Network Security', 'DNS & HTTP']
            },
            'Digital Logic': {
                icon: '🔌',
                topics: ['Boolean Algebra', 'Logic Gates', 'Combinational Circuits', 'Sequential Circuits', 'K-Maps', 'Flip Flops', 'Counters', 'Memory Elements']
            },
            'Computer Organization': {
                icon: '🔧',
                topics: ['CPU Architecture', 'Pipelining', 'Memory Hierarchy', 'Cache Memory', 'Virtual Memory', 'I/O Organization', 'Instruction Set', 'Performance']
            }
        };

        let selectedSubject = '';
        let selectedTopic = '';
        let selectedDifficulty = '';
        let questions = [];
        let userAnswers = {};
        let startTime = Date.now();

        function createStars() {
            const starfield = document.getElementById('starfield');
            for (let i = 0; i < 200; i++) {
                const star = document.createElement('div');
                star.className = 'star';
                star.style.left = Math.random() * 100 + '%';
                star.style.top = Math.random() * 100 + '%';
                star.style.width = Math.random() * 2 + 1 + 'px';
                star.style.height = star.style.width;
                star.style.animationDelay = Math.random() * 3 + 's';
                starfield.appendChild(star);
            }
        }

        function initializeSubjects() {
            const grid = document.getElementById('subjectsGrid');
            Object.keys(gateSyllabus).forEach(subject => {
                const card = document.createElement('div');
                card.className = 'subject-card';
                card.innerHTML = `
                    <span class="subject-icon">${gateSyllabus[subject].icon}</span>
                    <div class="subject-name">${subject}</div>
                `;
                card.addEventListener('click', () => selectSubject(subject, card));
                grid.appendChild(card);
            });
        }

        function selectSubject(subject, card) {
            document.querySelectorAll('.subject-card').forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
            selectedSubject = subject;
            selectedTopic = '';
            showTopics(subject);
        }

        function showTopics(subject) {
            const container = document.getElementById('topicsContainer');
            container.innerHTML = `
                <div class="topics-container active">
                    <h3 class="section-title" style="font-size: 1.4rem; margin-top: 20px;">Select Topic</h3>
                    <div class="topics-grid" id="topicsGrid"></div>
                </div>
            `;

            const grid = document.getElementById('topicsGrid');
            gateSyllabus[subject].topics.forEach(topic => {
                const btn = document.createElement('button');
                btn.className = 'topic-btn';
                btn.textContent = topic;
                btn.addEventListener('click', () => selectTopic(topic, btn));
                grid.appendChild(btn);
            });
        }

        function selectTopic(topic, btn) {
            document.querySelectorAll('.topic-btn').forEach(b => b.classList.remove('selected'));
            btn.classList.add('selected');
            selectedTopic = topic;
        }

        document.querySelectorAll('.difficulty-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.difficulty-btn').forEach(b => b.classList.remove('selected'));
                btn.classList.add('selected');
                selectedDifficulty = btn.dataset.difficulty;
            });
        });

        document.getElementById('generateBtn').addEventListener('click', async () => {
            if (!selectedSubject || !selectedTopic || !selectedDifficulty) {
                alert('Please select subject, topic, and difficulty level!');
                return;
            }

            startTime = Date.now();
            document.getElementById('setupSection').style.display = 'none';
            document.getElementById('loadingSection').classList.add('active');

            try {
                const response = await fetch('generate-quiz-gate-cs.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        subject: selectedSubject,
                        topic: selectedTopic,
                        difficulty: selectedDifficulty,
                        count: 10
                    })
                });

                const data = await response.json();

                if (data.success) {
                    questions = data.questions;
                    displayQuiz();
                } else {
                    throw new Error(data.error || 'Failed to generate quiz');
                }
            } catch (error) {
                alert('Error generating quiz: ' + error.message);
                document.getElementById('setupSection').style.display = 'block';
                document.getElementById('loadingSection').classList.remove('active');
            }
        });

        function displayQuiz() {
            document.getElementById('loadingSection').classList.remove('active');
            document.getElementById('quizSection').classList.add('active');

            document.getElementById('quizSubject').textContent = selectedSubject;
            document.getElementById('quizTopic').textContent = selectedTopic;
            document.getElementById('quizDifficulty').textContent = selectedDifficulty.toUpperCase();

            const container = document.getElementById('questionsContainer');
            container.innerHTML = '';

            questions.forEach((q, index) => {
                const card = document.createElement('div');
                card.className = 'question-card';
                
                let badgeClass = 'badge-mcq';
                let badgeText = 'MCQ';
                if (q.type === 'MSQ') {
                    badgeClass = 'badge-msq';
                    badgeText = 'MSQ';
                } else if (q.type === 'NAT') {
                    badgeClass = 'badge-numerical';
                    badgeText = 'NAT';
                }

                let optionsHTML = '';
                if (q.type === 'NAT') {
                    optionsHTML = `
                        <input type="number" step="0.01" class="numerical-input" 
                               data-question="${index}" placeholder="Enter your answer">
                        <div class="correct-answer-display" id="correctAnswer${index}"></div>
                    `;
                } else {
                    optionsHTML = `<div class="options">
                        ${q.options.map((option, optIndex) => `
                            <button class="option-btn" data-question="${index}" data-option="${optIndex}">
                                ${String.fromCharCode(65 + optIndex)}. ${option}
                            </button>
                        `).join('')}
                    </div>`;
                }

                card.innerHTML = `
                    <div class="question-header">
                        <div class="question-number">Question ${index + 1}</div>
                        <div>
                            <span class="question-type-badge ${badgeClass}">${badgeText}</span>
                            <span class="question-marks">${q.marks} ${q.marks === 1 ? 'Mark' : 'Marks'}</span>
                        </div>
                    </div>
                    <div class="question-text">${q.question}</div>
                    ${optionsHTML}
                `;
                container.appendChild(card);
            });

            document.querySelectorAll('.option-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const questionIndex = parseInt(btn.dataset.question);
                    const optionIndex = parseInt(btn.dataset.option);
                    selectAnswer(questionIndex, optionIndex);
                });
            });

            document.querySelectorAll('.numerical-input').forEach(input => {
                input.addEventListener('input', (e) => {
                    const questionIndex = parseInt(input.dataset.question);
                    userAnswers[questionIndex] = parseFloat(e.target.value);
                });
            });

            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        function selectAnswer(questionIndex, optionIndex) {
            const q = questions[questionIndex];
            
            if (q.type === 'MSQ') {
                if (!userAnswers[questionIndex]) {
                    userAnswers[questionIndex] = [];
                }
                const btn = document.querySelector(`[data-question="${questionIndex}"][data-option="${optionIndex}"]`);
                
                if (userAnswers[questionIndex].includes(optionIndex)) {
                    userAnswers[questionIndex] = userAnswers[questionIndex].filter(i => i !== optionIndex);
                    btn.classList.remove('selected');
                } else {
                    userAnswers[questionIndex].push(optionIndex);
                    btn.classList.add('selected');
                }
            } else {
                document.querySelectorAll(`[data-question="${questionIndex}"]`).forEach(btn => {
                    btn.classList.remove('selected');
                });
                document.querySelector(`[data-question="${questionIndex}"][data-option="${optionIndex}"]`).classList.add('selected');
                userAnswers[questionIndex] = optionIndex;
            }
        }

        document.getElementById('submitBtn').addEventListener('click', () => {
            if (Object.keys(userAnswers).length < questions.length) {
                if (!confirm('You have not answered all questions. Submit anyway?')) {
                    return;
                }
            }

            let correctCount = 0;
            let totalMarks = 0;
            let earnedMarks = 0;

            questions.forEach((q, index) => {
                totalMarks += q.marks;
                const userAnswer = userAnswers[index];

                if (q.type === 'NAT') {
                    const input = document.querySelector(`[data-question="${index}"]`);
                    const correctAnswer = parseFloat(q.correctAnswer);
                    const userAns = parseFloat(userAnswer);
                    
                    const tolerance = 0.01;
                    const isCorrect = Math.abs(userAns - correctAnswer) <= tolerance;
                    
                    if (isCorrect) {
                        correctCount++;
                        earnedMarks += q.marks;
                        input.classList.add('correct');
                    } else {
                        input.classList.add('incorrect');
                    }
                    input.disabled = true;
                    
                    const correctAnswerDiv = document.getElementById(`correctAnswer${index}`);
                    correctAnswerDiv.textContent = `Correct Answer: ${correctAnswer}`;
                    correctAnswerDiv.classList.add('show');
                } else if (q.type === 'MSQ') {
                    const correctAnswers = q.correctAnswer.sort();
                    const userAnswers = (userAnswer || []).sort();
                    const isCorrect = JSON.stringify(correctAnswers) === JSON.stringify(userAnswers);

                    const btns = document.querySelectorAll(`[data-question="${index}"]`);
                    btns.forEach(btn => btn.classList.add('disabled'));

                    correctAnswers.forEach(ansIdx => {
                        btns[ansIdx].classList.add('correct');
                    });

                    if (!isCorrect && userAnswers) {
                        userAnswers.forEach(ansIdx => {
                            if (!correctAnswers.includes(ansIdx)) {
                                btns[ansIdx].classList.add('incorrect');
                            }
                        });
                    }

                    if (isCorrect) {
                        correctCount++;
                        earnedMarks += q.marks;
                    }
                } else {
                    const correctAnswer = q.correctAnswer;
                    const btns = document.querySelectorAll(`[data-question="${index}"]`);

                    btns.forEach(btn => btn.classList.add('disabled'));
                    btns[correctAnswer].classList.add('correct');

                    if (userAnswer !== undefined && userAnswer !== correctAnswer) {
                        btns[userAnswer].classList.add('incorrect');
                    } else if (userAnswer === correctAnswer) {
                        correctCount++;
                        earnedMarks += q.marks;
                    }
                }
            });

            showResults(correctCount, earnedMarks, totalMarks);
        });

        function showResults(correctCount, earnedMarks, totalMarks) {
            const incorrectCount = questions.length - correctCount;
            const percentage = ((correctCount / questions.length) * 100).toFixed(1);
            const timeSpent = Math.round((Date.now() - startTime) / 60000);
            const gateScore = Math.round((earnedMarks / totalMarks) * 100);

            document.getElementById('scoreDisplay').textContent = percentage + '%';
            document.getElementById('correctCount').textContent = correctCount;
            document.getElementById('incorrectCount').textContent = incorrectCount;

            let message = '';
            if (percentage >= 90) message = '🎉 Outstanding! GATE-level expertise!';
            else if (percentage >= 70) message = '🌟 Excellent! Strong preparation!';
            else if (percentage >= 50) message = '👍 Good! Keep practicing!';
            else message = '📚 Keep going! Practice makes perfect!';

            document.getElementById('motivationalMsg').textContent = message;
            document.getElementById('accuracyRate').textContent = percentage + '%';
            document.getElementById('totalMarks').textContent = `${earnedMarks}/${totalMarks}`;
            document.getElementById('timeSpent').textContent = timeSpent + 'm';
            document.getElementById('gateScore').textContent = gateScore;

            document.getElementById('resultsContainer').classList.add('active');
            document.getElementById('chartsSection').classList.add('active');
            document.getElementById('submitBtn').style.display = 'none';

            createCharts(correctCount, incorrectCount, percentage, earnedMarks, totalMarks);

            document.getElementById('resultsContainer').scrollIntoView({ behavior: 'smooth' });
        }

        function createCharts(correct, incorrect, percentage, earnedMarks, totalMarks) {
            const mcqCount = questions.filter(q => q.type === 'MCQ').length;
            const msqCount = questions.filter(q => q.type === 'MSQ').length;
            const natCount = questions.filter(q => q.type === 'NAT').length;

            new Chart(document.getElementById('scoreChart'), {
                type: 'doughnut',
                data: {
                    labels: ['Correct', 'Incorrect'],
                    datasets: [{
                        data: [correct, incorrect],
                        backgroundColor: ['#4ade80', '#f87171'],
                        borderColor: ['#22c55e', '#ef4444'],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { labels: { color: '#fff', font: { size: 14 } } } }
                }
            });

            new Chart(document.getElementById('typeChart'), {
                type: 'bar',
                data: {
                    labels: ['MCQ', 'MSQ', 'NAT'],
                    datasets: [{
                        label: 'Question Count',
                        data: [mcqCount, msqCount, natCount],
                        backgroundColor: ['#4ade80', '#fbbf24', '#c792ea'],
                        borderColor: ['#22c55e', '#f59e0b', '#a855f7'],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: { color: '#fff' },
                            grid: { color: 'rgba(126, 232, 250, 0.1)' }
                        },
                        x: {
                            ticks: { color: '#fff' },
                            grid: { color: 'rgba(126, 232, 250, 0.1)' }
                        }
                    },
                    plugins: { legend: { labels: { color: '#fff' } } }
                }
            });

            new Chart(document.getElementById('radarChart'), {
                type: 'radar',
                data: {
                    labels: ['Accuracy', 'Speed', 'Problem Solving', 'Conceptual', 'Technical'],
                    datasets: [{
                        label: 'Performance',
                        data: [percentage, 85, percentage * 0.9, percentage * 1.1, percentage * 0.95],
                        backgroundColor: 'rgba(199, 146, 234, 0.2)',
                        borderColor: '#c792ea',
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        r: {
                            beginAtZero: true,
                            max: 100,
                            ticks: { color: '#fff' },
                            grid: { color: 'rgba(126, 232, 250, 0.2)' },
                            pointLabels: { color: '#7ee8fa', font: { size: 12 } }
                        }
                    },
                    plugins: { legend: { labels: { color: '#fff' } } }
                }
            });

            new Chart(document.getElementById('comparisonChart'), {
                type: 'bar',
                data: {
                    labels: ['Your Score', 'Total Marks'],
                    datasets: [{
                        label: 'Marks',
                        data: [earnedMarks, totalMarks],
                        backgroundColor: ['#58a6ff', '#c792ea'],
                        borderColor: ['#7ee8fa', '#ff6b6b'],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: { color: '#fff' },
                            grid: { color: 'rgba(126, 232, 250, 0.1)' }
                        },
                        x: {
                            ticks: { color: '#fff' },
                            grid: { color: 'rgba(126, 232, 250, 0.1)' }
                        }
                    },
                    plugins: { legend: { labels: { color: '#fff' } } }
                }
            });
        }

        document.getElementById('restartBtn').addEventListener('click', () => {
            location.reload();
        });

        createStars();
        initializeSubjects();

        let lastScrollTop = 0;
        const header = document.getElementById('mainHeader');
        const footer = document.getElementById('mainFooter');
        const scrollThreshold = 100;

        window.addEventListener('scroll', () => {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

            if (scrollTop > scrollThreshold) {
                if (scrollTop > lastScrollTop) {
                    header.classList.add('hidden');
                    footer.classList.add('hidden');
                } else {
                    header.classList.remove('hidden');
                    footer.classList.remove('hidden');
                }
            } else {
                header.classList.remove('hidden');
                footer.classList.remove('hidden');
            }

            lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
        }, false);
    </script>
</body>
</html>
