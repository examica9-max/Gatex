<?php
/* === PERSISTENT SESSION PROTECTION === */

// Start session with 1 year lifetime
if (session_status() === PHP_SESSION_NONE) {
    ini_set("session.gc_maxlifetime", 31536000); // 1 year
    session_set_cookie_params(31536000);
    session_start();
}

// Check if user has premium access
if (!isset($_SESSION["premium_access"]) || $_SESSION["premium_access"] !== true) {
    header("Location: ../../index.php");
    exit;
}

// Validate code has not expired
if (isset($_SESSION["code_expiry"])) {
    $expiry = strtotime($_SESSION["code_expiry"]);
    $today = strtotime(date("Y-m-d"));
    
    if ($today > $expiry) {
        session_destroy();
        header("Location: ../../index.php?error=expired");
        exit;
    }
}

/* === END PERSISTENT SESSION PROTECTION === */
?>

<?php
// Set your API Key here. REPLACE 'YOUR_API_KEY' with your actual key.
$GEMINI_API_KEY = 'AIzaSyCDGq-3PDTLaGLA9Qukt9SfIxCXJrU3H70'; 

// Define the API endpoint and model (using 2.5-flash for a fast test)
$GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

// The simple test prompt
$prompt = "Respond with only the word 'OK' if you receive this message.";

$requestData = [
    'contents' => [
        [
            'parts' => [
                ['text' => $prompt]
            ]
        ]
    ],
    'generationConfig' => [
        'temperature' => 0.0, // Set low for a predictable response
    ]
];

// --- cURL Setup and Execution ---
$ch = curl_init($GEMINI_API_URL . '?key=' . $GEMINI_API_KEY);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));

echo "Sending request to Gemini API...\n\n";

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);
// --- End cURL ---

echo "## Test Results ##\n";
echo "HTTP Status Code: " . $httpCode . "\n";

if ($httpCode === 200) {
    echo "✅ **SUCCESS: API Key is Valid and Working!**\n";
    
    $apiResponse = json_decode($response, true);
    $responseText = $apiResponse['candidates'][0]['content']['parts'][0]['text'] ?? 'Response text not found.';
    
    echo "API Response Text: **" . trim($responseText) . "**\n";
    echo "\nYour key is valid. The previous error was likely due to the model endpoint (404) or a prompt issue.\n";
    
} elseif ($httpCode === 400) {
    echo "❌ **FAILURE: Check API Key and Endpoint**\n";
    echo "Error Details: The API returned a 400 Bad Request. This often means the API key is incorrect or invalid, or the request body is malformed.\n";
    echo "Raw Response: " . $response . "\n";
    
} elseif ($httpCode === 404) {
    echo "❌ **FAILURE: Endpoint Not Found**\n";
    echo "Error Details: The API returned a 404 Not Found. This means the URL, including the model name, is incorrect. (This was the error in your original file).\n";
    
} else {
    echo "❌ **FAILURE: Other Error**\n";
    echo "cURL Error: " . ($curlError ? $curlError : 'None') . "\n";
    echo "HTTP Code Error: " . $httpCode . "\n";
    echo "Raw Response: " . $response . "\n";
}
?>
