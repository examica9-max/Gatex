<?php
require_once 'auth.php';
require_once 'secret-manager.php';

requireAdmin();

$manager = new SecretManager();
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'create':
            $secret = $_POST['secret'] ?? '';
            $expiry = $_POST['expiry'] ?? '';
            if ($secret && $expiry) {
                if ($manager->createSecret($secret, $expiry)) {
                    $message = 'Secret code created successfully!';
                    $messageType = 'success';
                } else {
                    $message = 'Failed to create secret code';
                    $messageType = 'error';
                }
            }
            break;
            
        case 'generate':
            $generatedSecret = $manager->generateSecretCode();
            $expiry = $_POST['expiry'] ?? date('Y-m-d', strtotime('+1 year'));
            if ($manager->createSecret($generatedSecret, $expiry)) {
                $message = "Generated code: <strong>$generatedSecret</strong>";
                $messageType = 'success';
            }
            break;
            
        case 'update_status':
            $secret = $_POST['secret'] ?? '';
            $status = $_POST['status'] ?? '';
            if ($manager->updateStatus($secret, $status)) {
                $message = 'Status updated!';
                $messageType = 'success';
            }
            break;
            
        case 'delete':
            $secret = $_POST['secret'] ?? '';
            if ($manager->deleteSecret($secret)) {
                $message = 'Secret code deleted!';
                $messageType = 'success';
            }
            break;
    }
}

$secrets = $manager->getAllSecrets();
$totalCodes = count($secrets);
$activeCodes = count(array_filter($secrets, function($s) { return $s['status'] === 'active' && $s['used'] === 'false'; }));
$usedCodes = count(array_filter($secrets, function($s) { return $s['used'] === 'true'; }));
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard - GATEX</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Inter', sans-serif; background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: #f8fafc; min-height: 100vh; padding: 20px; }
.container { max-width: 1400px; margin: 0 auto; }
.header { background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(10px); padding: 25px 35px; border-radius: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; }
.header h1 { font-size: 32px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.logout-btn { padding: 12px 24px; background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 600; text-decoration: none; display: inline-block; transition: transform 0.2s; }
.logout-btn:hover { transform: translateY(-2px); }
.message { padding: 18px 25px; border-radius: 12px; margin-bottom: 25px; animation: slideDown 0.3s ease; }
.message.success { background: rgba(34, 197, 94, 0.2); border: 1px solid #22c55e; color: #86efac; }
.message.error { background: rgba(239, 68, 68, 0.2); border: 1px solid #ef4444; color: #fca5a5; }
@keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
.stat-card { background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(10px); border-radius: 15px; padding: 25px; border: 1px solid rgba(255, 255, 255, 0.1); }
.stat-value { font-size: 36px; font-weight: 800; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.stat-label { font-size: 14px; color: #94a3b8; margin-top: 5px; }
.dashboard-grid { display: grid; grid-template-columns: 1fr 2fr; gap: 30px; margin-bottom: 30px; }
.card { background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(10px); border-radius: 20px; padding: 30px; border: 1px solid rgba(255, 255, 255, 0.1); }
.card h2 { margin-bottom: 25px; font-size: 22px; color: #a78bfa; }
.form-group { margin-bottom: 20px; }
label { display: block; margin-bottom: 8px; font-weight: 600; font-size: 14px; }
input { width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 10px; color: white; font-size: 14px; font-family: 'Inter', sans-serif; }
input:focus { outline: none; border-color: #667eea; }
button[type="submit"] { width: 100%; padding: 14px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 10px; font-weight: 600; cursor: pointer; transition: transform 0.2s; margin-top: 10px; }
button[type="submit"]:hover { transform: translateY(-2px); }
.quick-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 20px; }
.quick-btn { padding: 15px; background: rgba(102, 126, 234, 0.1); border: 1px solid rgba(102, 126, 234, 0.3); border-radius: 10px; color: #a78bfa; font-weight: 600; cursor: pointer; transition: all 0.3s; }
.quick-btn:hover { background: rgba(102, 126, 234, 0.2); transform: translateY(-2px); }
table { width: 100%; border-collapse: collapse; }
th { background: rgba(102, 126, 234, 0.2); padding: 15px; text-align: left; font-weight: 600; border-bottom: 2px solid rgba(102, 126, 234, 0.3); }
td { padding: 15px; border-bottom: 1px solid rgba(255, 255, 255, 0.1); }
tr:hover { background: rgba(255, 255, 255, 0.02); }
.status-badge { display: inline-block; padding: 5px 14px; border-radius: 20px; font-size: 12px; font-weight: 600; }
.status-active { background: rgba(34, 197, 94, 0.2); color: #86efac; }
.status-inactive { background: rgba(239, 68, 68, 0.2); color: #fca5a5; }
.status-used { background: rgba(251, 191, 36, 0.2); color: #fcd34d; }
.action-btns { display: flex; gap: 10px; }
.btn-small { padding: 7px 14px; border-radius: 6px; font-size: 12px; font-weight: 600; cursor: pointer; border: none; transition: transform 0.2s; }
.btn-deactivate { background: #f59e0b; color: white; }
.btn-delete { background: #ef4444; color: white; }
.btn-small:hover { transform: translateY(-1px); }
@media (max-width: 968px) { .dashboard-grid { grid-template-columns: 1fr; } }
@media (max-width: 768px) { .quick-actions { grid-template-columns: 1fr; } .action-btns { flex-direction: column; } }
</style>
</head>
<body>
<div class="container">
<div class="header">
<div>
<h1>🚀 GATEX Admin</h1>
<p style="color: #94a3b8; margin-top: 5px;">Secret Code Management</p>
</div>
<a href="logout.php" class="logout-btn">Logout</a>
</div>

<?php if ($message): ?>
<div class="message <?php echo $messageType; ?>">
<?php echo $message; ?>
</div>
<?php endif; ?>

<div class="stats-grid">
<div class="stat-card">
<div class="stat-value"><?php echo $totalCodes; ?></div>
<div class="stat-label">Total Codes</div>
</div>
<div class="stat-card">
<div class="stat-value"><?php echo $activeCodes; ?></div>
<div class="stat-label">Active & Unused</div>
</div>
<div class="stat-card">
<div class="stat-value"><?php echo $usedCodes; ?></div>
<div class="stat-label">Used Codes</div>
</div>
</div>

<div class="dashboard-grid">
<div class="card">
<h2>Create New Secret Code</h2>

<form method="POST">
<input type="hidden" name="action" value="create">
<div class="form-group">
<label>Secret Code</label>
<input type="text" name="secret" placeholder="GATEX-XXXXX" required>
</div>
<div class="form-group">
<label>Expiry Date</label>
<input type="date" name="expiry" value="<?php echo date('Y-m-d', strtotime('+1 year')); ?>" required>
</div>
<button type="submit">Create Code</button>
</form>

<div class="quick-actions">
<form method="POST" style="margin: 0;">
<input type="hidden" name="action" value="generate">
<input type="hidden" name="expiry" value="<?php echo date('Y-m-d', strtotime('+1 year')); ?>">
<button type="submit" class="quick-btn">🎲 Auto Generate</button>
</form>
<button class="quick-btn" onclick="location.reload()">🔄 Refresh</button>
</div>
</div>

<div class="card">
<h2>All Secret Codes (<?php echo $totalCodes; ?>)</h2>
<div style="overflow-x: auto;">
<table>
<thead>
<tr>
<th>Secret Code</th>
<th>Status</th>
<th>Used</th>
<th>Expiry</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php if (empty($secrets)): ?>
<tr>
<td colspan="5" style="text-align: center; padding: 40px; color: #94a3b8;">
No codes yet. Create one!
</td>
</tr>
<?php else: ?>
<?php foreach ($secrets as $secret): ?>
<tr>
<td><strong><?php echo htmlspecialchars($secret['secret']); ?></strong></td>
<td>
<span class="status-badge status-<?php echo $secret['status']; ?>">
<?php echo ucfirst($secret['status']); ?>
</span>
</td>
<td>
<?php if ($secret['used'] === 'true'): ?>
<span class="status-badge status-used">✓ Used</span>
<?php else: ?>
<span style="color: #94a3b8;">Not Used</span>
<?php endif; ?>
</td>
<td><?php echo date('d M Y', strtotime($secret['expiry'])); ?></td>
<td>
<div class="action-btns">
<form method="POST" style="display: inline;">
<input type="hidden" name="action" value="update_status">
<input type="hidden" name="secret" value="<?php echo htmlspecialchars($secret['secret']); ?>">
<input type="hidden" name="status" value="<?php echo $secret['status'] === 'active' ? 'inactive' : 'active'; ?>">
<button type="submit" class="btn-small btn-deactivate">
<?php echo $secret['status'] === 'active' ? 'Deactivate' : 'Activate'; ?>
</button>
</form>
<form method="POST" style="display: inline;" onsubmit="return confirm('Delete?');">
<input type="hidden" name="action" value="delete">
<input type="hidden" name="secret" value="<?php echo htmlspecialchars($secret['secret']); ?>">
<button type="submit" class="btn-small btn-delete">Delete</button>
</form>
</div>
</td>
</tr>
<?php endforeach; ?>
<?php endif; ?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</body>
</html>
