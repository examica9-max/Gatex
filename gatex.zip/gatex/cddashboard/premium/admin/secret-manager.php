<?php
// Secret Code Manager - CRUD Operations

class SecretManager {
    private $xmlFile;

    public function __construct() {
        $this->xmlFile = __DIR__ . '/secrets.xml';
        
        if (!file_exists($this->xmlFile)) {
            $this->createXMLFile();
        }
    }

    private function createXMLFile() {
        $xml = new DOMDocument('1.0', 'UTF-8');
        $xml->formatOutput = true;
        $root = $xml->createElement('secrets');
        $xml->appendChild($root);
        $xml->save($this->xmlFile);
    }

    // CREATE
    public function createSecret($secret, $expiry) {
        $xml = new DOMDocument();
        $xml->load($this->xmlFile);
        $xml->formatOutput = true;

        $root = $xml->documentElement;
        $codeElement = $xml->createElement('code');
        
        $secretElement = $xml->createElement('secret', htmlspecialchars(strtoupper(trim($secret))));
        $statusElement = $xml->createElement('status', 'active');
        $createdElement = $xml->createElement('created', date('Y-m-d H:i:s'));
        $usedElement = $xml->createElement('used', 'false');
        $userElement = $xml->createElement('user', '');
        
        if (strtotime($expiry)) {
            $expiryElement = $xml->createElement('expiry', date('Y-m-d', strtotime($expiry)));
        } else {
            $expiryElement = $xml->createElement('expiry', $expiry);
        }
        
        $codeElement->appendChild($secretElement);
        $codeElement->appendChild($statusElement);
        $codeElement->appendChild($createdElement);
        $codeElement->appendChild($usedElement);
        $codeElement->appendChild($userElement);
        $codeElement->appendChild($expiryElement);
        
        $root->appendChild($codeElement);
        
        return $xml->save($this->xmlFile);
    }

    // READ - All
    public function getAllSecrets() {
        if (!file_exists($this->xmlFile)) {
            return [];
        }
        
        $xml = simplexml_load_file($this->xmlFile);
        $secrets = [];
        
        if ($xml && $xml->code) {
            foreach ($xml->code as $code) {
                $secrets[] = [
                    'secret' => (string)$code->secret,
                    'status' => (string)$code->status,
                    'created' => (string)$code->created,
                    'used' => (string)$code->used,
                    'user' => (string)$code->user,
                    'expiry' => (string)$code->expiry
                ];
            }
        }
        
        return $secrets;
    }

    // READ - Verify
    public function verifySecret($secret) {
        if (!file_exists($this->xmlFile)) {
            return false;
        }
        
        $xml = simplexml_load_file($this->xmlFile);
        if (!$xml) {
            return false;
        }
        
        $secret = strtoupper(trim($secret));
        
        foreach ($xml->code as $code) {
            $codeSecret = strtoupper(trim((string)$code->secret));
            
            if ($codeSecret === $secret) {
                if ((string)$code->status !== 'active') {
                    return false;
                }
                
                // Allow unlimited logins - only check expiry
                $expiryDate = (string)$code->expiry;
                $expiry = strtotime($expiryDate);
                $today = strtotime(date('Y-m-d'));
                
                if ($expiry >= $today) {
                    return true;
                }
            }
        }
        
        return false;
    }

    // UPDATE - Mark used
    public function markAsUsed($secret, $userIdentifier) {
        $xml = new DOMDocument();
        $xml->load($this->xmlFile);
        $xml->formatOutput = true;

        $secret = strtoupper(trim($secret));
        $xpath = new DOMXPath($xml);
        $codes = $xpath->query("//code");
        
        foreach ($codes as $codeNode) {
            $secretNode = $xpath->query('.//secret', $codeNode)->item(0);
            if ($secretNode && strtoupper(trim($secretNode->nodeValue)) === $secret) {
                $usedNode = $xpath->query('.//used', $codeNode)->item(0);
                $usedNode->nodeValue = 'true';
                
                $userNode = $xpath->query('.//user', $codeNode)->item(0);
                $userNode->nodeValue = htmlspecialchars($userIdentifier);
                
                return $xml->save($this->xmlFile);
            }
        }
        
        return false;
    }

    // UPDATE - Status
    public function updateStatus($secret, $newStatus) {
        $xml = new DOMDocument();
        $xml->load($this->xmlFile);
        $xml->formatOutput = true;

        $secret = strtoupper(trim($secret));
        $xpath = new DOMXPath($xml);
        $codes = $xpath->query("//code");
        
        foreach ($codes as $codeNode) {
            $secretNode = $xpath->query('.//secret', $codeNode)->item(0);
            if ($secretNode && strtoupper(trim($secretNode->nodeValue)) === $secret) {
                $statusNode = $xpath->query('.//status', $codeNode)->item(0);
                $statusNode->nodeValue = $newStatus;
                
                return $xml->save($this->xmlFile);
            }
        }
        
        return false;
    }

    // DELETE
    public function deleteSecret($secret) {
        $xml = new DOMDocument();
        $xml->load($this->xmlFile);
        $xml->formatOutput = true;

        $secret = strtoupper(trim($secret));
        $xpath = new DOMXPath($xml);
        $codes = $xpath->query("//code");
        
        foreach ($codes as $codeNode) {
            $secretNode = $xpath->query('.//secret', $codeNode)->item(0);
            if ($secretNode && strtoupper(trim($secretNode->nodeValue)) === $secret) {
                $codeNode->parentNode->removeChild($codeNode);
                return $xml->save($this->xmlFile);
            }
        }
        
        return false;
    }

    // Generate Code
    public function generateSecretCode() {
        $prefix = 'GATEX';
        $random = strtoupper(substr(md5(uniqid(rand(), true)), 0, 8));
        return $prefix . '-' . $random;
    }

    // Get secret code details including expiry
    public function getSecretDetails($secret) {
        if (!file_exists($this->xmlFile)) {
            return null;
        }
        
        $xml = simplexml_load_file($this->xmlFile);
        if (!$xml) {
            return null;
        }
        
        $secret = strtoupper(trim($secret));
        
        foreach ($xml->code as $code) {
            $codeSecret = strtoupper(trim((string)$code->secret));
            
            if ($codeSecret === $secret) {
                return [
                    'secret' => (string)$code->secret,
                    'status' => (string)$code->status,
                    'created' => (string)$code->created,
                    'used' => (string)$code->used,
                    'user' => (string)$code->user,
                    'expiry' => (string)$code->expiry
                ];
            }
        }
        
        return null;
    }
}
?>
