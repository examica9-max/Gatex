<?php
require_once 'auth.php';
adminLogout();
?>
