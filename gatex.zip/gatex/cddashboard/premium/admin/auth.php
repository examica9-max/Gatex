<?php
// Admin Authentication
session_start();

// CHANGE THESE CREDENTIALS!
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'GATEX@2024');

function isAdminLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function adminLogin($username, $password) {
    if ($username === ADMIN_USERNAME && $password === ADMIN_PASSWORD) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $username;
        $_SESSION['admin_login_time'] = time();
        return true;
    }
    return false;
}

function adminLogout() {
    session_destroy();
    header('Location: admin-login.php');
    exit;
}

function requireAdmin() {
    if (!isAdminLoggedIn()) {
        header('Location: admin-login.php');
        exit;
    }
}
?>
