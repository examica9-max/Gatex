# GATE CS Paper Generator - Quick Start Guide
### TechEagles × Rocket Examica × Mahakumbrix Innovation

## 🚀 Super Quick Setup (3 Steps!)

### **Option 1: Single File - EASIEST** ⭐

You only need **2 files**:
1. `index.html` - Landing page
2. `exam.php` - Everything in one file!

**Steps:**

1. **Get API Key**
   - Go to: https://makersuite.google.com/app/apikey
   - Create new API key
   - Copy it

2. **Edit exam.php**
   - Open `exam.php` in text editor
   - Find line 8: `$GEMINI_API_KEY = 'AIzaSyCDGq-3PDTLaGLA9Qukt9SfIxCXJrU3H70';`
   - Replace the API key with YOUR actual API key
   - Save file

3. **Upload & Run**
   - Upload both files to your web server
   - Open `index.html` in browser
   - Click "Start Examination"
   - Done! 🎉

---

## 📁 File Structure

```
your-folder/
├── index.html          ← Landing page
└── exam.php           ← Main exam (all-in-one!)
```

That's it! Just 2 files needed!

---

## 🔧 Configuration (Optional)

All settings are at the top of **exam.php**:

```php
// Change exam duration (minutes)
define('EXAM_DURATION', 180);

// Change number of questions
define('TOTAL_QUESTIONS', 65);

// Change total marks
define('TOTAL_MARKS', 100);

// Change negative marking
define('NEGATIVE_MARKING', 0.33);
```

---

## 🌐 Deployment Options

### **Local Testing (XAMPP/WAMP)**
```
C:\xampp\htdocs\gate-exam\
├── index.html
└── exam.php
```
Access: `http://localhost/gate-exam/`

### **cPanel Hosting**
1. Login to cPanel
2. Open File Manager
3. Go to `public_html`
4. Create folder: `gate-exam`
5. Upload files
6. Done!

Access: `https://yourdomain.com/gate-exam/`

---

## ✅ Features Included

- ✨ AI-powered question generation
- ⏱️ 180-minute timer
- 📊 6 performance charts
- 🎯 65 questions (authentic GATE pattern)
- 📱 Mobile-friendly
- 🖨️ Print results
- 🎨 Premium UI design
- 📈 Detailed analytics

---

## 🐛 Troubleshooting

**Problem:** "Configuration Required" error  
**Solution:** Make sure you replaced the API key in exam.php (line 8)

**Problem:** Questions not generating  
**Solution:** Check your internet connection and API key validity

**Problem:** Page not loading  
**Solution:** Make sure you're running on a PHP-enabled server (not opening directly)

---

## 💡 Pro Tips

1. **Test First:** Generate a test paper before using with students
2. **Stable Internet:** Ensure good connection during paper generation
3. **Modern Browser:** Use Chrome/Firefox for best experience
4. **Backup Key:** Keep your API key saved somewhere safe

---

## 📞 Need Help?

Check these in order:
1. Browser Console (F12) for errors
2. Check API key is correct
3. Verify internet connection
4. Try different browser

---

## 🎯 That's It!

Really just 3 steps:
1. Get API key
2. Put it in exam.php
3. Upload and run

**Happy Testing!** 🚀

---

**© 2025 TechEagles × Rocket Examica × Mahakumbrix Innovation**
