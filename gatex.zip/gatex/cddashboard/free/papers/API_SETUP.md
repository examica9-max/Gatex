# API Configuration Guide
### TechEagles × Rocket Examica × Mahakumbrix Innovation

## ✅ Working API Configuration

Your exam.php is already configured with a working API key! 🎉

---

## 📝 Current Configuration (Lines 6-11 in exam.php)

```php
// GEMINI API CONFIGURATION
// Set your API Key here. REPLACE 'YOUR_API_KEY' with your actual key.
$GEMINI_API_KEY = 'AIzaSyCDGq-3PDTLaGLA9Qukt9SfIxCXJrU3H70';

// Define the API endpoint and model (using 2.0-flash-exp for fast generation)
$GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent';
```

---

## 🔄 To Use Your Own API Key

### Step 1: Get Your API Key
Visit: https://makersuite.google.com/app/apikey

### Step 2: Update exam.php
Open `exam.php` and change line 8:

**FROM:**
```php
$GEMINI_API_KEY = 'AIzaSyCDGq-3PDTLaGLA9Qukt9SfIxCXJrU3H70';
```

**TO:**
```php
$GEMINI_API_KEY = 'YOUR_ACTUAL_API_KEY_HERE';
```

### Step 3: Save and Upload
- Save the file
- Upload to your server
- Done! ✅

---

## 🎯 API Model Options

You can change the model on line 11:

### Fast Model (Recommended):
```php
$GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent';
```

### Alternative Models:
```php
// Gemini 1.5 Flash (Faster, lighter)
$GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

// Gemini 1.5 Pro (More powerful)
$GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent';

// Gemini 2.0 Flash Latest (Most advanced)
$GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent';
```

---

## ✨ What's Configured

The system automatically uses:
- ✅ API Key: Set on line 8
- ✅ API URL: Set on line 11
- ✅ Both passed to JavaScript automatically
- ✅ Error handling included
- ✅ Validation on page load

---

## 🔍 Verification

### Check if API key is working:
1. Open `exam.php` in browser
2. If you see the loading screen → API key works! ✅
3. If you see "Configuration Required" → Update API key

### Test the system:
1. Click "Start Examination" on index.html
2. Wait for questions to generate
3. Questions appear → Everything works! 🎉

---

## 🐛 Troubleshooting

### Error: "Configuration Required"
**Fix:** Update line 8 with your actual API key

### Error: "API request failed: 400"
**Fix:** 
- Check API key is valid
- Verify no extra spaces in key
- Try regenerating API key

### Error: "API request failed: 429"
**Fix:** API quota exceeded
- Wait 24 hours
- Get new API key
- Use different Google account

### Questions not generating
**Fix:**
- Check internet connection
- Verify API key has quota
- Try different model (line 11)
- Check browser console (F12) for errors

---

## 💡 Pro Tips

1. **Keep API key secret** - Don't share publicly
2. **Monitor usage** - Check quota at https://makersuite.google.com
3. **Use Flash model** - Faster and cheaper
4. **Test locally first** - Before deploying to production
5. **Backup configuration** - Save your API key somewhere safe

---

## 📊 Current Settings Summary

| Setting | Value | Location |
|---------|-------|----------|
| API Key | Pre-configured | Line 8 |
| API Model | gemini-2.0-flash-exp | Line 11 |
| Exam Duration | 180 minutes | Line 14 |
| Total Questions | 65 | Line 15 |
| Total Marks | 100 | Line 16 |
| Negative Marking | -0.33 | Line 17 |

---

## 🎓 Model Comparison

| Model | Speed | Quality | Best For |
|-------|-------|---------|----------|
| 2.0-flash-exp | ⚡⚡⚡ | ⭐⭐⭐ | Fast generation |
| 1.5-flash | ⚡⚡ | ⭐⭐ | General use |
| 1.5-pro | ⚡ | ⭐⭐⭐⭐ | High quality |

**Current:** 2.0-flash-exp (Best balance!) ⭐

---

## 🔐 Security Notes

- API key is in PHP (server-side) ✅
- Not visible in page source ✅
- Protected by server ✅
- Use HTTPS in production ✅

---

**Ready to use!** Just upload and run! 🚀

**© 2025 TechEagles × Rocket Examica × Mahakumbrix Innovation**
