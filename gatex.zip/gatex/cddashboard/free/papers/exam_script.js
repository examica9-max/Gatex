// Create star field animation
function createStars() {
    const starsContainer = document.getElementById('stars');
    for (let i = 0; i < 100; i++) {
        const star = document.createElement('div');
        star.className = 'star';
        star.style.left = Math.random() * 100 + '%';
        star.style.top = Math.random() * 100 + '%';
        star.style.width = Math.random() * 3 + 1 + 'px';
        star.style.height = star.style.width;
        star.style.animationDelay = Math.random() * 3 + 's';
        starsContainer.appendChild(star);
    }
}

createStars();

// GATE CS subjects and their weightage
const gateSubjects = {
    "Engineering Mathematics": {
        topics: ["Discrete Mathematics", "Linear Algebra", "Calculus", "Probability"],
        weightage: 15
    },
    "Digital Logic": {
        topics: ["Boolean Algebra", "Combinational Circuits", "Sequential Circuits", "Number Systems"],
        weightage: 6
    },
    "Computer Organization": {
        topics: ["Machine Instructions", "Addressing Modes", "ALU", "Memory Hierarchy", "I/O Interface"],
        weightage: 7
    },
    "Programming": {
        topics: ["C Programming", "Data Structures", "Algorithms", "Complexity Analysis"],
        weightage: 10
    },
    "Data Structures": {
        topics: ["Arrays", "Linked Lists", "Stacks", "Queues", "Trees", "Graphs", "Hashing"],
        weightage: 9
    },
    "Algorithms": {
        topics: ["Searching", "Sorting", "Greedy", "Dynamic Programming", "Graph Algorithms"],
        weightage: 9
    },
    "Theory of Computation": {
        topics: ["Regular Languages", "Context-Free Grammars", "Turing Machines", "Decidability"],
        weightage: 7
    },
    "Compiler Design": {
        topics: ["Lexical Analysis", "Parsing", "Syntax Directed Translation", "Code Generation"],
        weightage: 5
    },
    "Operating Systems": {
        topics: ["Processes", "Threads", "Scheduling", "Memory Management", "File Systems"],
        weightage: 9
    },
    "Databases": {
        topics: ["ER Model", "Relational Model", "SQL", "Normalization", "Transactions", "Indexing"],
        weightage: 9
    },
    "Computer Networks": {
        topics: ["OSI Model", "TCP/IP", "Routing", "Transport Layer", "Application Layer"],
        weightage: 9
    },
    "Software Engineering": {
        topics: ["SDLC", "Design Patterns", "Testing", "Project Management"],
        weightage: 5
    }
};

let examData = {
    questions: [],
    answers: {},
    markedForReview: new Set(),
    startTime: null,
    duration: CONFIG.duration,
    timerInterval: null
};

// Auto-generate paper on page load
window.addEventListener('DOMContentLoaded', function() {
    generatePaper();
});

// Generate paper using Gemini API
async function generatePaper() {
    const apiKey = CONFIG.apiKey;
    const totalQuestions = CONFIG.totalQuestions;
    const duration = CONFIG.duration;

    examData.duration = duration;

    try {
        examData.questions = [];
        
        // Calculate questions per subject based on GATE pattern
        const questionsPerSubject = calculateQuestionDistribution(totalQuestions);

        // Generate questions for each subject
        for (const [subject, data] of Object.entries(questionsPerSubject)) {
            if (data.count > 0) {
                const subjectQuestions = await generateSubjectQuestions(
                    apiKey, 
                    subject, 
                    gateSubjects[subject].topics,
                    data.count
                );
                examData.questions.push(...subjectQuestions);
            }
        }

        // Shuffle questions
        examData.questions = shuffleArray(examData.questions);

        // Assign question numbers
        examData.questions.forEach((q, index) => {
            q.number = index + 1;
        });

        document.getElementById('loadingContainer').style.display = 'none';
        startExam();

    } catch (error) {
        document.getElementById('loadingContainer').style.display = 'none';
        alert('Error generating paper: ' + error.message);
        console.error(error);
        window.location.href = 'index.html';
    }
}

function calculateQuestionDistribution(totalQuestions) {
    const distribution = {};
    let remaining = totalQuestions;

    // Sort subjects by weightage
    const sortedSubjects = Object.entries(gateSubjects)
        .sort((a, b) => b[1].weightage - a[1].weightage);

    const totalWeightage = Object.values(gateSubjects)
        .reduce((sum, s) => sum + s.weightage, 0);

    sortedSubjects.forEach(([subject, data], index) => {
        if (index === sortedSubjects.length - 1) {
            distribution[subject] = { count: remaining };
        } else {
            const count = Math.round((data.weightage / totalWeightage) * totalQuestions);
            distribution[subject] = { count: Math.min(count, remaining) };
            remaining -= distribution[subject].count;
        }
    });

    return distribution;
}

async function generateSubjectQuestions(apiKey, subject, topics, count) {
    const questions = [];
    const questionsPerCall = Math.min(count, 5); // Generate 5 questions per API call
    const calls = Math.ceil(count / questionsPerCall);

    for (let i = 0; i < calls; i++) {
        const questionsToGenerate = Math.min(questionsPerCall, count - questions.length);
        
        const prompt = `Generate ${questionsToGenerate} multiple-choice questions for GATE Computer Science exam on the subject "${subject}".
        
Topics to cover: ${topics.join(', ')}

Requirements:
1. Each question should have exactly 4 options (A, B, C, D)
2. Questions should be of varying difficulty (Easy, Medium, Hard)
3. Include detailed explanations for correct answers
4. Mark values: 1 mark for easy, 2 marks for medium/hard
5. Questions should follow GATE exam pattern

Return ONLY a valid JSON array with this exact structure:
[
  {
    "question": "Question text here",
    "options": {
      "A": "Option A text",
      "B": "Option B text",
      "C": "Option C text",
      "D": "Option D text"
    },
    "correct": "A",
    "explanation": "Detailed explanation",
    "difficulty": "Medium",
    "marks": 2,
    "subject": "${subject}",
    "topic": "Specific topic"
  }
]

Do not include any text before or after the JSON array. Only return valid JSON.`;

        const apiUrl = CONFIG.apiUrl || `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent`;
        const response = await fetch(`${apiUrl}?key=${apiKey}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                contents: [{
                    parts: [{
                        text: prompt
                    }]
                }],
                generationConfig: {
                    temperature: 0.9,
                    topK: 40,
                    topP: 0.95,
                    maxOutputTokens: 8192,
                }
            })
        });

        if (!response.ok) {
            throw new Error(`API request failed: ${response.status}`);
        }

        const data = await response.json();
        const generatedText = data.candidates[0].content.parts[0].text;
        
        // Extract JSON from response
        let jsonText = generatedText.trim();
        
        // Remove markdown code blocks if present
        jsonText = jsonText.replace(/```json\n?/g, '').replace(/```\n?/g, '');
        
        // Find JSON array in the text
        const jsonStart = jsonText.indexOf('[');
        const jsonEnd = jsonText.lastIndexOf(']') + 1;
        
        if (jsonStart !== -1 && jsonEnd > jsonStart) {
            jsonText = jsonText.substring(jsonStart, jsonEnd);
        }

        try {
            const parsedQuestions = JSON.parse(jsonText);
            questions.push(...parsedQuestions);
        } catch (parseError) {
            console.error('JSON Parse Error:', parseError);
            console.log('Generated text:', generatedText);
            // Generate fallback questions
            questions.push(...generateFallbackQuestions(subject, topics, questionsToGenerate));
        }

        // Small delay between API calls
        if (i < calls - 1) {
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
    }

    return questions.slice(0, count);
}

function generateFallbackQuestions(subject, topics, count) {
    const fallbackQuestions = [];
    const difficulties = ['Easy', 'Medium', 'Hard'];
    
    for (let i = 0; i < count; i++) {
        const topic = topics[i % topics.length];
        const difficulty = difficulties[i % difficulties.length];
        const marks = difficulty === 'Easy' ? 1 : 2;
        
        fallbackQuestions.push({
            question: `Question ${i + 1} on ${topic} - This is a sample question for ${subject}. What is the fundamental concept related to ${topic}?`,
            options: {
                A: `Option A - First possible answer for ${topic}`,
                B: `Option B - Second possible answer for ${topic}`,
                C: `Option C - Third possible answer for ${topic}`,
                D: `Option D - Fourth possible answer for ${topic}`
            },
            correct: ['A', 'B', 'C', 'D'][Math.floor(Math.random() * 4)],
            explanation: `This is a fundamental question about ${topic}. The correct answer demonstrates understanding of core concepts.`,
            difficulty: difficulty,
            marks: marks,
            subject: subject,
            topic: topic
        });
    }
    
    return fallbackQuestions;
}

function shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

function startExam() {
    document.getElementById('examContainer').style.display = 'block';
    
    examData.startTime = Date.now();
    examData.answers = {};
    examData.markedForReview = new Set();
    
    renderQuestionNavigation();
    renderQuestions();
    startTimer();
    
    // Show first question
    showQuestion(0);
}

function renderQuestionNavigation() {
    const nav = document.getElementById('questionNav');
    nav.innerHTML = '';
    
    examData.questions.forEach((q, index) => {
        const btn = document.createElement('button');
        btn.className = 'nav-btn';
        btn.textContent = index + 1;
        btn.onclick = () => showQuestion(index);
        nav.appendChild(btn);
    });
}

function renderQuestions() {
    const container = document.getElementById('questionsContainer');
    container.innerHTML = '';
    
    examData.questions.forEach((q, index) => {
        const card = document.createElement('div');
        card.className = 'question-card';
        card.id = `question-${index}`;
        
        card.innerHTML = `
            <div class="question-header">
                <div class="question-number">Question ${q.number}</div>
                <div class="question-marks">
                    <i class="fas fa-star"></i> ${q.marks} Mark${q.marks > 1 ? 's' : ''}
                </div>
            </div>
            
            <div style="background: rgba(99, 102, 241, 0.1); padding: 12px 20px; border-radius: 10px; margin-bottom: 20px; display: inline-block;">
                <strong>Subject:</strong> ${q.subject} | <strong>Topic:</strong> ${q.topic} | <strong>Difficulty:</strong> ${q.difficulty}
            </div>
            
            <div class="question-text">${q.question}</div>
            
            <div class="options-container">
                ${Object.entries(q.options).map(([key, value]) => `
                    <div class="option" onclick="selectOption(${index}, '${key}')">
                        <input type="radio" name="q${index}" value="${key}" id="q${index}${key}">
                        <label class="option-label" for="q${index}${key}">
                            <strong>${key}.</strong> ${value}
                        </label>
                    </div>
                `).join('')}
            </div>
            
            <div class="question-actions">
                <div class="nav-buttons">
                    ${index > 0 ? `<button class="btn-clear" onclick="showQuestion(${index - 1})">
                        <span><i class="fas fa-arrow-left"></i> Previous</span>
                    </button>` : ''}
                    ${index < examData.questions.length - 1 ? `<button class="btn-submit" onclick="showQuestion(${index + 1})">
                        <span>Next <i class="fas fa-arrow-right"></i></span>
                    </button>` : ''}
                </div>
                <button class="btn-mark" onclick="toggleMark(${index})">
                    <span><i class="fas fa-flag"></i> Mark for Review</span>
                </button>
                <button class="btn-clear" onclick="clearAnswer(${index})">
                    <span><i class="fas fa-eraser"></i> Clear</span>
                </button>
            </div>
        `;
        
        container.appendChild(card);
    });
}

function showQuestion(index) {
    // Hide all questions
    document.querySelectorAll('.question-card').forEach(card => {
        card.classList.remove('active');
    });
    
    // Show selected question
    document.getElementById(`question-${index}`).classList.add('active');
    
    // Update navigation
    document.querySelectorAll('.nav-btn').forEach((btn, i) => {
        btn.classList.remove('active');
        if (i === index) {
            btn.classList.add('active');
        }
    });
    
    // Restore selected answer if exists
    if (examData.answers[index]) {
        const radio = document.getElementById(`q${index}${examData.answers[index]}`);
        if (radio) {
            radio.checked = true;
            radio.closest('.option').classList.add('selected');
        }
    }
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function selectOption(questionIndex, option) {
    examData.answers[questionIndex] = option;
    
    // Update visual selection
    const card = document.getElementById(`question-${questionIndex}`);
    card.querySelectorAll('.option').forEach(opt => opt.classList.remove('selected'));
    card.querySelector(`#q${questionIndex}${option}`).closest('.option').classList.add('selected');
    
    // Update navigation button
    updateNavigationButton(questionIndex);
}

function toggleMark(questionIndex) {
    if (examData.markedForReview.has(questionIndex)) {
        examData.markedForReview.delete(questionIndex);
    } else {
        examData.markedForReview.add(questionIndex);
    }
    updateNavigationButton(questionIndex);
}

function clearAnswer(questionIndex) {
    delete examData.answers[questionIndex];
    
    const card = document.getElementById(`question-${questionIndex}`);
    card.querySelectorAll('input[type="radio"]').forEach(radio => radio.checked = false);
    card.querySelectorAll('.option').forEach(opt => opt.classList.remove('selected'));
    
    updateNavigationButton(questionIndex);
}

function updateNavigationButton(questionIndex) {
    const btn = document.querySelectorAll('.nav-btn')[questionIndex];
    btn.classList.remove('answered', 'marked');
    
    if (examData.markedForReview.has(questionIndex)) {
        btn.classList.add('marked');
    } else if (examData.answers[questionIndex]) {
        btn.classList.add('answered');
    }
}

function startTimer() {
    const display = document.getElementById('timerDisplay');
    const timerElement = document.getElementById('timer');
    let timeLeft = examData.duration * 60;
    
    examData.timerInterval = setInterval(() => {
        timeLeft--;
        
        const hours = Math.floor(timeLeft / 3600);
        const minutes = Math.floor((timeLeft % 3600) / 60);
        const seconds = timeLeft % 60;
        
        display.textContent = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        
        // Warning states
        if (timeLeft <= CONFIG.dangerTime) {
            timerElement.classList.add('danger');
            timerElement.classList.remove('warning');
        } else if (timeLeft <= CONFIG.warningTime) {
            timerElement.classList.add('warning');
        }
        
        if (timeLeft <= 0) {
            clearInterval(examData.timerInterval);
            submitExam(true);
        }
    }, 1000);
}

function submitExam(autoSubmit = false) {
    if (!autoSubmit) {
        const unanswered = examData.questions.length - Object.keys(examData.answers).length;
        if (unanswered > 0) {
            if (!confirm(`You have ${unanswered} unanswered questions. Are you sure you want to submit?`)) {
                return;
            }
        }
    }
    
    clearInterval(examData.timerInterval);
    calculateResults();
}

function calculateResults() {
    let correct = 0;
    let wrong = 0;
    let totalMarks = 0;
    let obtainedMarks = 0;
    
    const subjectStats = {};
    const difficultyStats = { Easy: {correct: 0, total: 0}, Medium: {correct: 0, total: 0}, Hard: {correct: 0, total: 0} };
    
    examData.questions.forEach((q, index) => {
        totalMarks += q.marks;
        
        // Initialize subject stats
        if (!subjectStats[q.subject]) {
            subjectStats[q.subject] = { correct: 0, total: 0, marks: 0, obtained: 0 };
        }
        subjectStats[q.subject].total++;
        
        // Initialize difficulty stats
        difficultyStats[q.difficulty].total++;
        
        if (examData.answers[index]) {
            if (examData.answers[index] === q.correct) {
                correct++;
                obtainedMarks += q.marks;
                subjectStats[q.subject].correct++;
                subjectStats[q.subject].obtained += q.marks;
                difficultyStats[q.difficulty].correct++;
            } else {
                wrong++;
                obtainedMarks -= q.marks / 3; // Negative marking
            }
        }
        
        subjectStats[q.subject].marks += q.marks;
    });
    
    const unattempted = examData.questions.length - correct - wrong;
    const percentage = ((obtainedMarks / totalMarks) * 100).toFixed(2);
    const accuracy = correct > 0 ? ((correct / (correct + wrong)) * 100).toFixed(2) : 0;
    
    // Expected rank calculation (approximate)
    const expectedRank = calculateExpectedRank(obtainedMarks, totalMarks);
    
    displayResults(correct, wrong, unattempted, obtainedMarks, totalMarks, percentage, accuracy, expectedRank, subjectStats, difficultyStats);
}

function calculateExpectedRank(obtainedMarks, totalMarks) {
    const percentage = (obtainedMarks / totalMarks) * 100;
    
    if (percentage >= 90) return "1-500";
    if (percentage >= 80) return "500-2000";
    if (percentage >= 70) return "2000-5000";
    if (percentage >= 60) return "5000-10000";
    if (percentage >= 50) return "10000-20000";
    return "20000+";
}

function displayResults(correct, wrong, unattempted, obtainedMarks, totalMarks, percentage, accuracy, expectedRank, subjectStats, difficultyStats) {
    document.getElementById('examContainer').style.display = 'none';
    document.getElementById('resultsContainer').style.display = 'block';
    
    // Update statistics
    document.getElementById('scoreDisplay').textContent = `${obtainedMarks.toFixed(2)} / ${totalMarks}`;
    document.getElementById('correctCount').textContent = correct;
    document.getElementById('wrongCount').textContent = wrong;
    document.getElementById('unattemptedCount').textContent = unattempted;
    document.getElementById('percentageScore').textContent = percentage + '%';
    document.getElementById('rank').textContent = expectedRank;
    document.getElementById('accuracy').textContent = accuracy + '%';
    
    // Create charts
    createPerformanceChart(correct, wrong, unattempted);
    createSubjectChart(subjectStats);
    createDifficultyChart(difficultyStats);
    createDetailedAnalysis(subjectStats, difficultyStats);
}

function createPerformanceChart(correct, wrong, unattempted) {
    const ctx = document.getElementById('performanceChart').getContext('2d');
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Correct', 'Wrong', 'Unattempted'],
            datasets: [{
                data: [correct, wrong, unattempted],
                backgroundColor: [
                    'rgba(16, 185, 129, 0.8)',
                    'rgba(239, 68, 68, 0.8)',
                    'rgba(107, 114, 128, 0.8)'
                ],
                borderColor: [
                    'rgba(16, 185, 129, 1)',
                    'rgba(239, 68, 68, 1)',
                    'rgba(107, 114, 128, 1)'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#ffffff',
                        font: {
                            size: 14,
                            family: 'Rajdhani'
                        },
                        padding: 20
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(15, 23, 42, 0.9)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    borderColor: 'rgba(139, 92, 246, 0.5)',
                    borderWidth: 1,
                    padding: 12,
                    titleFont: {
                        size: 16,
                        family: 'Rajdhani'
                    },
                    bodyFont: {
                        size: 14,
                        family: 'Rajdhani'
                    }
                }
            }
        }
    });
}

function createSubjectChart(subjectStats) {
    const ctx = document.getElementById('subjectChart').getContext('2d');
    
    const subjects = Object.keys(subjectStats);
    const correctData = subjects.map(s => subjectStats[s].correct);
    const totalData = subjects.map(s => subjectStats[s].total);
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: subjects,
            datasets: [
                {
                    label: 'Correct',
                    data: correctData,
                    backgroundColor: 'rgba(16, 185, 129, 0.8)',
                    borderColor: 'rgba(16, 185, 129, 1)',
                    borderWidth: 2
                },
                {
                    label: 'Total Questions',
                    data: totalData,
                    backgroundColor: 'rgba(99, 102, 241, 0.8)',
                    borderColor: 'rgba(99, 102, 241, 1)',
                    borderWidth: 2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#ffffff',
                        font: {
                            size: 12,
                            family: 'Rajdhani'
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#ffffff',
                        font: {
                            size: 11,
                            family: 'Rajdhani'
                        },
                        maxRotation: 45,
                        minRotation: 45
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: '#ffffff',
                        font: {
                            size: 14,
                            family: 'Rajdhani'
                        },
                        padding: 20
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(15, 23, 42, 0.9)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    borderColor: 'rgba(139, 92, 246, 0.5)',
                    borderWidth: 1,
                    padding: 12,
                    titleFont: {
                        size: 16,
                        family: 'Rajdhani'
                    },
                    bodyFont: {
                        size: 14,
                        family: 'Rajdhani'
                    }
                }
            }
        }
    });
}

function createDifficultyChart(difficultyStats) {
    const ctx = document.getElementById('difficultyChart').getContext('2d');
    
    const difficulties = Object.keys(difficultyStats);
    const correctData = difficulties.map(d => difficultyStats[d].correct);
    const totalData = difficulties.map(d => difficultyStats[d].total);
    const accuracyData = difficulties.map(d => 
        difficultyStats[d].total > 0 
            ? ((difficultyStats[d].correct / difficultyStats[d].total) * 100).toFixed(1)
            : 0
    );
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: difficulties,
            datasets: [
                {
                    label: 'Accuracy %',
                    data: accuracyData,
                    borderColor: 'rgba(139, 92, 246, 1)',
                    backgroundColor: 'rgba(139, 92, 246, 0.2)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        color: '#ffffff',
                        font: {
                            size: 12,
                            family: 'Rajdhani'
                        },
                        callback: function(value) {
                            return value + '%';
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                x: {
                    ticks: {
                        color: '#ffffff',
                        font: {
                            size: 14,
                            family: 'Rajdhani'
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: '#ffffff',
                        font: {
                            size: 14,
                            family: 'Rajdhani'
                        },
                        padding: 20
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(15, 23, 42, 0.9)',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    borderColor: 'rgba(139, 92, 246, 0.5)',
                    borderWidth: 1,
                    padding: 12,
                    titleFont: {
                        size: 16,
                        family: 'Rajdhani'
                    },
                    bodyFont: {
                        size: 14,
                        family: 'Rajdhani'
                    }
                }
            }
        }
    });
}

function createDetailedAnalysis(subjectStats, difficultyStats) {
    const container = document.getElementById('detailedAnalysis');
    
    let html = '<h3 class="chart-title"><i class="fas fa-microscope"></i> Detailed Subject-wise Analysis</h3>';
    
    Object.entries(subjectStats).forEach(([subject, stats]) => {
        const percentage = stats.total > 0 ? ((stats.correct / stats.total) * 100).toFixed(1) : 0;
        const marksPercentage = stats.marks > 0 ? ((stats.obtained / stats.marks) * 100).toFixed(1) : 0;
        
        html += `
            <div class="section-analysis">
                <div class="section-header">
                    <i class="fas fa-book"></i> ${subject}
                </div>
                <div style="padding: 15px;">
                    <p style="font-size: 1.1em; margin-bottom: 10px;">
                        <strong>Questions:</strong> ${stats.correct} / ${stats.total} correct (${percentage}%)
                    </p>
                    <p style="font-size: 1.1em; margin-bottom: 10px;">
                        <strong>Marks:</strong> ${stats.obtained.toFixed(2)} / ${stats.marks} (${marksPercentage}%)
                    </p>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${percentage}%">${percentage}%</div>
                    </div>
                </div>
            </div>
        `;
    });
    
    html += '<h3 class="chart-title" style="margin-top: 30px;"><i class="fas fa-layer-group"></i> Difficulty Level Performance</h3>';
    
    Object.entries(difficultyStats).forEach(([difficulty, stats]) => {
        const percentage = stats.total > 0 ? ((stats.correct / stats.total) * 100).toFixed(1) : 0;
        let color = '#6366f1';
        if (difficulty === 'Easy') color = '#10b981';
        if (difficulty === 'Hard') color = '#ef4444';
        
        html += `
            <div class="section-analysis">
                <div class="section-header" style="background: rgba(${difficulty === 'Easy' ? '16, 185, 129' : difficulty === 'Hard' ? '239, 68, 68' : '99, 102, 241'}, 0.2);">
                    <i class="fas fa-signal"></i> ${difficulty}
                </div>
                <div style="padding: 15px;">
                    <p style="font-size: 1.1em; margin-bottom: 10px;">
                        <strong>Performance:</strong> ${stats.correct} / ${stats.total} correct (${percentage}%)
                    </p>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${percentage}%; background: linear-gradient(90deg, ${color}, ${color}dd);">${percentage}%</div>
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// Add print styles
const style = document.createElement('style');
style.textContent = `
    @media print {
        body { background: white !important; }
        .exam-header, footer, header { display: none !important; }
        .results-container { display: block !important; }
        button { display: none !important; }
    }
`;
document.head.appendChild(style);
