<?php
// ============================================
// GATE CS EXAM - ALL-IN-ONE CONFIGURATION
// ============================================

// GEMINI API CONFIGURATION
// Set your API Key here. REPLACE 'YOUR_API_KEY' with your actual key.
$GEMINI_API_KEY = 'AIzaSyCDGq-3PDTLaGLA9Qukt9SfIxCXJrU3H70';

// Define the API endpoint and model (using 2.0-flash-exp for fast generation)
$GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent';

// EXAM CONFIGURATION
define('EXAM_DURATION', 180);           // Duration in minutes
define('TOTAL_QUESTIONS', 65);          // Total number of questions
define('TOTAL_MARKS', 100);             // Total marks
define('NEGATIVE_MARKING', 0.33);       // Negative marking fraction

// QUESTION DISTRIBUTION
define('ONE_MARK_QUESTIONS', 55);
define('TWO_MARK_QUESTIONS', 10);

// TIMER WARNING THRESHOLDS
define('WARNING_TIME', 900);            // 15 minutes in seconds
define('DANGER_TIME', 300);             // 5 minutes in seconds

// BRANDING CONFIGURATION
define('SITE_TITLE', 'GATE CS Paper Generator');
define('BRAND_NAME', 'TechEagles × Rocket Examica × Mahakumbrix Innovation');
define('COPYRIGHT_YEAR', '2025');

// FEATURE FLAGS
define('ENABLE_PRINT_RESULTS', true);

// Validate configuration
if ($GEMINI_API_KEY === 'YOUR_API_KEY' || empty($GEMINI_API_KEY)) {
    die('
    <!DOCTYPE html>
    <html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuration Required</title>
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@600&display=swap" rel="stylesheet">
    <style>body{font-family:Rajdhani,sans-serif;background:linear-gradient(135deg,#0a0e27,#2d1b4e);min-height:100vh;display:flex;align-items:center;justify-content:center;color:#fff;padding:20px}.container{max-width:600px;background:rgba(99,102,241,0.1);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,0.1);border-radius:20px;padding:40px;text-align:center}h1{color:#ef4444;font-size:2.5em;margin-bottom:20px}p{font-size:1.2em;line-height:1.8;margin:15px 0}code{background:rgba(0,0,0,0.3);padding:5px 15px;border-radius:5px;color:#10b981}a{color:#6366f1;text-decoration:none;font-weight:700}a:hover{color:#8b5cf6}</style>
    </head><body><div class="container">
    <h1>⚠️ Configuration Required</h1>
    <p>Please configure your Gemini API key at the top of <code>exam.php</code></p>
    <p>Replace <code>YOUR_API_KEY</code> with your actual API key on line 8.</p>
    <p style="margin-top:30px"><a href="https://makersuite.google.com/app/apikey" target="_blank">Get API Key Here →</a></p>
    </div></body></html>');
}

// Start session
session_start();
if (!isset($_SESSION['exam_id'])) {
    $_SESSION['exam_id'] = uniqid('exam_', true);
}
$examId = $_SESSION['exam_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_TITLE; ?> - Examination</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Rajdhani', sans-serif;
            background: linear-gradient(135deg, #0a0e27 0%, #1a1f3a 25%, #2d1b4e 50%, #1a1f3a 75%, #0a0e27 100%);
            background-size: 400% 400%;
            animation: gradientShift 15s ease infinite;
            min-height: 100vh;
            color: #ffffff;
            overflow-x: hidden;
        }

        @keyframes gradientShift {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .stars {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
        }

        .star {
            position: absolute;
            background: white;
            border-radius: 50%;
            animation: twinkle 3s infinite;
        }

        @keyframes twinkle {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 1; }
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
            position: relative;
            z-index: 1;
        }

        header {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.2) 0%, rgba(139, 92, 246, 0.2) 100%);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 25px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 20px 60px rgba(99, 102, 241, 0.3);
            animation: slideDown 0.8s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            box-shadow: 0 10px 30px rgba(99, 102, 241, 0.5);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        h1 {
            font-family: 'Orbitron', sans-serif;
            font-size: 2.5em;
            font-weight: 800;
            background: linear-gradient(135deg, #6366f1, #8b5cf6, #ec4899);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .brand {
            font-size: 0.9em;
            color: #a78bfa;
            font-weight: 600;
        }

        .exam-header {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.2) 0%, rgba(139, 92, 246, 0.2) 100%);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 25px;
            animation: fadeInUp 0.8s ease-out;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .exam-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .timer {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.8em;
            font-weight: 700;
            color: #10b981;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .timer.warning {
            color: #fbbf24;
            animation: timerPulse 1s infinite;
        }

        .timer.danger {
            color: #ef4444;
            animation: timerPulse 0.5s infinite;
        }

        @keyframes timerPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        .question-nav {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 25px;
            padding: 20px;
            background: rgba(15, 23, 42, 0.4);
            border-radius: 15px;
        }

        .nav-btn {
            width: 45px;
            height: 45px;
            border-radius: 10px;
            border: 2px solid rgba(139, 92, 246, 0.3);
            background: rgba(99, 102, 241, 0.2);
            color: #ffffff;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: 'Rajdhani', sans-serif;
        }

        .nav-btn:hover {
            transform: scale(1.1);
            background: rgba(139, 92, 246, 0.4);
        }

        .nav-btn.active {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            border-color: #6366f1;
            box-shadow: 0 5px 15px rgba(99, 102, 241, 0.5);
        }

        .nav-btn.answered {
            background: linear-gradient(135deg, #10b981, #059669);
            border-color: #10b981;
        }

        .nav-btn.marked {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            border-color: #f59e0b;
        }

        .question-card {
            display: none;
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.15) 0%, rgba(139, 92, 246, 0.15) 100%);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 25px;
            animation: fadeIn 0.5s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .question-card.active {
            display: block;
        }

        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .question-number {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.5em;
            font-weight: 700;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .question-marks {
            background: linear-gradient(135deg, #10b981, #059669);
            padding: 8px 20px;
            border-radius: 20px;
            font-weight: 700;
            font-size: 1.1em;
        }

        .question-meta {
            background: rgba(99, 102, 241, 0.1);
            padding: 12px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: inline-block;
            font-size: 1.05em;
        }

        .question-text {
            font-size: 1.3em;
            line-height: 1.8;
            margin-bottom: 25px;
            color: #e0e7ff;
            font-weight: 500;
        }

        .options-container {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .option {
            background: rgba(15, 23, 42, 0.6);
            border: 2px solid rgba(139, 92, 246, 0.3);
            border-radius: 12px;
            padding: 18px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .option:hover {
            border-color: #8b5cf6;
            background: rgba(139, 92, 246, 0.2);
            transform: translateX(5px);
        }

        .option.selected {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.3) 0%, rgba(139, 92, 246, 0.3) 100%);
            border-color: #6366f1;
            box-shadow: 0 5px 20px rgba(99, 102, 241, 0.4);
        }

        .option input[type="radio"] {
            width: 24px;
            height: 24px;
            cursor: pointer;
        }

        .option-label {
            font-size: 1.2em;
            flex: 1;
            cursor: pointer;
            font-weight: 500;
        }

        .question-actions {
            display: flex;
            gap: 15px;
            margin-top: 25px;
            flex-wrap: wrap;
        }

        button {
            padding: 16px 32px;
            border: none;
            border-radius: 12px;
            font-family: 'Orbitron', sans-serif;
            font-size: 1.1em;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        button::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }

        button:hover::before {
            width: 300px;
            height: 300px;
        }

        button span {
            position: relative;
            z-index: 1;
        }

        .btn-submit {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            box-shadow: 0 10px 30px rgba(16, 185, 129, 0.4);
        }

        .btn-submit:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(16, 185, 129, 0.6);
        }

        .btn-mark {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: white;
        }

        .btn-clear {
            background: linear-gradient(135deg, #6b7280, #4b5563);
            color: white;
        }

        .loader {
            display: block;
            text-align: center;
            padding: 60px 40px;
        }

        .spinner {
            width: 60px;
            height: 60px;
            border: 5px solid rgba(139, 92, 246, 0.3);
            border-top-color: #8b5cf6;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .results-container {
            display: none;
        }

        .score-summary {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.2) 0%, rgba(139, 92, 246, 0.2) 100%);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 40px;
            margin-bottom: 30px;
            text-align: center;
        }

        .score-display {
            font-family: 'Orbitron', sans-serif;
            font-size: 4em;
            font-weight: 900;
            background: linear-gradient(135deg, #10b981, #059669);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin: 20px 0;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }

        .stat-card {
            background: rgba(15, 23, 42, 0.6);
            border: 2px solid rgba(139, 92, 246, 0.3);
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            border-color: #8b5cf6;
            box-shadow: 0 10px 30px rgba(139, 92, 246, 0.4);
        }

        .stat-value {
            font-family: 'Orbitron', sans-serif;
            font-size: 2.5em;
            font-weight: 700;
            margin: 10px 0;
        }

        .stat-label {
            color: #c4b5fd;
            font-size: 1.1em;
            font-weight: 600;
        }

        .chart-container {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.15) 0%, rgba(139, 92, 246, 0.15) 100%);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
        }

        .chart-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.8em;
            font-weight: 700;
            margin-bottom: 20px;
            text-align: center;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .detailed-analysis {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.15) 0%, rgba(139, 92, 246, 0.15) 100%);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
        }

        .section-analysis {
            margin-bottom: 30px;
        }

        .section-header {
            background: rgba(99, 102, 241, 0.2);
            padding: 15px 25px;
            border-radius: 12px;
            margin-bottom: 15px;
            font-size: 1.3em;
            font-weight: 700;
        }

        .progress-bar {
            background: rgba(15, 23, 42, 0.6);
            border-radius: 10px;
            height: 30px;
            overflow: hidden;
            margin: 10px 0;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #6366f1, #8b5cf6);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            transition: width 1s ease-out;
        }

        footer {
            text-align: center;
            padding: 30px;
            margin-top: 50px;
            color: #a78bfa;
            font-size: 1.1em;
        }

        @media (max-width: 768px) {
            h1 {
                font-size: 1.8em;
            }

            .exam-info {
                flex-direction: column;
            }

            .question-nav {
                justify-content: center;
            }

            .score-display {
                font-size: 2.5em;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .question-actions {
                flex-direction: column;
            }

            button {
                width: 100%;
            }
        }

        @media print {
            body { background: white !important; }
            .exam-header, footer, header, button { display: none !important; }
            .results-container { display: block !important; }
            .stars { display: none !important; }
        }
    </style>
</head>
<body>
    <div class="stars" id="stars"></div>

    <div class="container">
        <header>
            <div class="header-content">
                <div class="logo-section">
                    <div class="logo">
                        <i class="fas fa-microchip"></i>
                    </div>
                    <div>
                        <h1><?php echo SITE_TITLE; ?></h1>
                        <div class="brand"><?php echo BRAND_NAME; ?></div>
                    </div>
                </div>
            </div>
        </header>

        <div id="loadingContainer" class="loader">
            <div class="spinner"></div>
            <p style="font-size: 1.3em; color: #c4b5fd;">Generating your GATE CS paper with AI...</p>
            <p style="font-size: 1em; color: #a78bfa; margin-top: 10px;">This may take 1-2 minutes. Please wait...</p>
        </div>

        <div id="examContainer" style="display: none;">
            <div class="exam-header">
                <div class="exam-info">
                    <div>
                        <h2 style="font-family: 'Orbitron', sans-serif; margin-bottom: 10px;">GATE CS Examination</h2>
                        <p style="color: #c4b5fd; font-size: 1.1em;">Computer Science & Information Technology</p>
                    </div>
                    <div class="timer" id="timer">
                        <i class="fas fa-hourglass-half"></i>
                        <span id="timerDisplay">03:00:00</span>
                    </div>
                </div>
            </div>

            <div class="question-nav" id="questionNav"></div>
            <div id="questionsContainer"></div>

            <div style="display: flex; gap: 15px; justify-content: center; margin-top: 30px; flex-wrap: wrap;">
                <button class="btn-submit" onclick="submitExam()">
                    <span><i class="fas fa-check-circle"></i> Submit Exam</span>
                </button>
            </div>
        </div>

        <div class="results-container" id="resultsContainer">
            <div class="score-summary">
                <h2 style="font-family: 'Orbitron', sans-serif; font-size: 2em; margin-bottom: 20px;">Examination Results</h2>
                <div class="score-display" id="scoreDisplay">0 / 100</div>
                <p style="font-size: 1.3em; color: #c4b5fd; margin-top: 10px;">Marks Obtained</p>

                <div class="stats-grid">
                    <div class="stat-card">
                        <i class="fas fa-check-circle" style="font-size: 2em; color: #10b981;"></i>
                        <div class="stat-value" id="correctCount" style="color: #10b981;">0</div>
                        <div class="stat-label">Correct Answers</div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-times-circle" style="font-size: 2em; color: #ef4444;"></i>
                        <div class="stat-value" id="wrongCount" style="color: #ef4444;">0</div>
                        <div class="stat-label">Wrong Answers</div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-minus-circle" style="font-size: 2em; color: #6b7280;"></i>
                        <div class="stat-value" id="unattemptedCount" style="color: #6b7280;">0</div>
                        <div class="stat-label">Unattempted</div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-percentage" style="font-size: 2em; color: #8b5cf6;"></i>
                        <div class="stat-value" id="percentageScore" style="color: #8b5cf6;">0%</div>
                        <div class="stat-label">Percentage</div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-trophy" style="font-size: 2em; color: #f59e0b;"></i>
                        <div class="stat-value" id="rank" style="color: #f59e0b;">--</div>
                        <div class="stat-label">Expected Rank</div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-chart-line" style="font-size: 2em; color: #06b6d4;"></i>
                        <div class="stat-value" id="accuracy" style="color: #06b6d4;">0%</div>
                        <div class="stat-label">Accuracy</div>
                    </div>
                </div>
            </div>

            <div class="chart-container">
                <h3 class="chart-title"><i class="fas fa-chart-pie"></i> Performance Distribution</h3>
                <canvas id="performanceChart"></canvas>
            </div>

            <div class="chart-container">
                <h3 class="chart-title"><i class="fas fa-chart-bar"></i> Subject-wise Analysis</h3>
                <canvas id="subjectChart"></canvas>
            </div>

            <div class="chart-container">
                <h3 class="chart-title"><i class="fas fa-chart-line"></i> Difficulty Level Analysis</h3>
                <canvas id="difficultyChart"></canvas>
            </div>

            <div class="detailed-analysis" id="detailedAnalysis"></div>

            <div style="display: flex; gap: 15px; justify-content: center; margin-top: 30px; flex-wrap: wrap;">
                <button class="btn-submit" onclick="window.location.reload()">
                    <span><i class="fas fa-redo"></i> Generate New Paper</span>
                </button>
                <?php if (ENABLE_PRINT_RESULTS): ?>
                <button class="btn-submit" onclick="window.print()">
                    <span><i class="fas fa-print"></i> Print Results</span>
                </button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <footer>
        <p><strong><?php echo BRAND_NAME; ?></strong></p>
        <p style="margin-top: 10px;">Empowering GATE Aspirants with AI Technology</p>
        <p style="margin-top: 5px;">© <?php echo COPYRIGHT_YEAR; ?> All Rights Reserved</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="exam_script.js"></script>
    <script>
        const CONFIG = {
            apiKey: '<?php echo $GEMINI_API_KEY; ?>',
            apiUrl: '<?php echo $GEMINI_API_URL; ?>',
            duration: <?php echo EXAM_DURATION; ?>,
            totalQuestions: <?php echo TOTAL_QUESTIONS; ?>,
            totalMarks: <?php echo TOTAL_MARKS; ?>,
            negativeMarking: <?php echo NEGATIVE_MARKING; ?>,
            oneMarkQuestions: <?php echo ONE_MARK_QUESTIONS; ?>,
            twoMarkQuestions: <?php echo TWO_MARK_QUESTIONS; ?>,
            warningTime: <?php echo WARNING_TIME; ?>,
            dangerTime: <?php echo DANGER_TIME; ?>,
            examId: '<?php echo $examId; ?>'
        };
    </script>
</body>
</html>
