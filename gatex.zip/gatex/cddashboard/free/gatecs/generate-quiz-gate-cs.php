<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$GEMINI_API_KEY = 'AIzaSyCDGq-3PDTLaGLA9Qukt9SfIxCXJrU3H70'; 

// Define the API endpoint and model (using 2.5-flash for a fast test)
$GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';


// Ensure you replace this with your actual key if testing this block directly
//$GEMINI_API_KEY = 'AIzaSyCDGq-3PDTLaGLA9Qukt9SfIxCXJrU3H70'; 
// FIX: Switched to gemini-1.5-flash, resolving the 404 error
//$GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['subject']) || !isset($input['topic']) || !isset($input['difficulty'])) {
    echo json_encode([
        'success' => false,
        'error' => 'Missing required parameters'
    ]);
    exit;
}

$subject = $input['subject'];
$topic = $input['topic'];
$difficulty = $input['difficulty'];
$questionCount = isset($input['count']) ? intval($input['count']) : 10;

$difficultyInstructions = [
    'easy' => 'Create questions testing basic concepts and fundamental understanding. Suitable for beginners.',
    'medium' => 'Create questions requiring analytical thinking, problem-solving, and application of concepts. Suitable for intermediate level.',
    'hard' => 'Create advanced questions requiring deep conceptual understanding, complex problem-solving, and synthesis of multiple topics. GATE exam level difficulty.'
];

$difficultyPrompt = $difficultyInstructions[$difficulty] ?? $difficultyInstructions['medium'];

// Optimized Prompt
$prompt = "You are an expert GATE (Graduate Aptitude Test in Engineering) Computer Science question creator.

Generate EXACTLY {$questionCount} questions for GATE CS exam preparation.

Subject: {$subject}
Topic: {$topic}
Difficulty: {$difficulty}

{$difficultyPrompt}

CRITICAL REQUIREMENTS FOR GATE CS PATTERN:

1. QUESTION TYPES (Mix them appropriately):
   - MCQ (Multiple Choice Questions): Single correct answer, 1 or 2 marks
   - MSQ (Multiple Select Questions): Multiple correct answers possible, 2 marks
   - NAT (Numerical Answer Type): Numerical answer only, 1 or 2 marks

2. DISTRIBUTION:
   - Approximately 60% MCQ
   - Approximately 20% MSQ
   - Approximately 20% NAT

3. MARKS ALLOCATION:
   - Easy questions: 1 mark
   - Medium/Hard questions: 2 marks

4. MCQ FORMAT:
   - Exactly 4 options
   - One correct answer (index 0-3)

5. MSQ FORMAT:
   - Exactly 4 options
   - Multiple correct answers (array of indices)
   - At least 2 correct answers

6. NAT FORMAT:
   - Numerical answer only
   - Can be integer or decimal (up to 2 decimal places)
   - No options array needed

7. QUESTION QUALITY:
   - Must follow actual GATE CS exam pattern
   - Include technical depth and problem-solving
   - Cover different aspects of the topic
   - Professional and clear wording

Your ENTIRE response MUST be a single JSON object conforming to this schema, containing EXACTLY {$questionCount} questions:

{
    \"questions\": [
        {
            \"type\": \"MCQ\",
            \"question\": \"Question text?\",
            \"options\": [\"Option A\", \"Option B\", \"Option C\", \"Option D\"],
            \"correctAnswer\": 0,
            \"marks\": 1
        },
        {
            \"type\": \"MSQ\",
            \"question\": \"Question text?\",
            \"options\": [\"Option A\", \"Option B\", \"Option C\", \"Option D\"],
            \"correctAnswer\": [0, 2],
            \"marks\": 2
        },
        {
            \"type\": \"NAT\",
            \"question\": \"Question text?\",
            \"correctAnswer\": 42.5,
            \"marks\": 2
        }
        // ... {$questionCount} total questions
    ]
}

DO NOT include any markdown formatting (like ```json) or any explanation outside the required JSON object.
";

$requestData = [
    'contents' => [
        [
            'parts' => [
                ['text' => $prompt]
            ]
        ]
    ],
    'generationConfig' => [
        'temperature' => 0.7,
        'topK' => 40,
        'topP' => 0.95,
        'maxOutputTokens' => 8192,
        'responseMimeType' => 'application/json' // Crucial for reliable JSON output
    ]
];

$ch = curl_init($GEMINI_API_URL . '?key=' . $GEMINI_API_KEY);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($httpCode !== 200) {
    echo json_encode([
        'success' => false,
        'error' => 'API request failed: ' . $httpCode,
        'details' => $response ? json_decode($response, true) : $curlError
    ]);
    exit;
}

$apiResponse = json_decode($response, true);

if (!isset($apiResponse['candidates'][0]['content']['parts'][0]['text'])) {
    echo json_encode([
        'success' => false,
        'error' => 'Invalid API response structure',
        'debug' => $apiResponse
    ]);
    exit;
}

$generatedText = $apiResponse['candidates'][0]['content']['parts'][0]['text'];
// Less aggressive cleanup since responseMimeType is used, but kept for safety
$generatedText = preg_replace('/```json\s*/i', '', $generatedText);
$generatedText = preg_replace('/```\s*$/', '', $generatedText);
$generatedText = trim($generatedText);

$questionsData = json_decode($generatedText, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode([
        'success' => false,
        'error' => 'JSON parse error: ' . json_last_error_msg(),
        'raw_response' => $generatedText
    ]);
    exit;
}

if (!isset($questionsData['questions']) || !is_array($questionsData['questions'])) {
    echo json_encode([
        'success' => false,
        'error' => 'Invalid questions structure'
    ]);
    exit;
}

$validatedQuestions = [];

foreach ($questionsData['questions'] as $question) {
    if (!isset($question['type']) || !isset($question['question']) || !isset($question['marks'])) {
        continue;
    }

    $type = strtoupper($question['type']);
    
    if ($type === 'MCQ') {
        if (!isset($question['options']) || !is_array($question['options']) || count($question['options']) !== 4) {
            continue;
        }
        if (!isset($question['correctAnswer']) || !is_numeric($question['correctAnswer'])) {
            continue;
        }
        
        $correctAnswer = intval($question['correctAnswer']);
        if ($correctAnswer < 0 || $correctAnswer > 3) {
            continue;
        }

        $validatedQuestions[] = [
            'type' => 'MCQ',
            'question' => trim($question['question']),
            'options' => array_map('trim', $question['options']),
            'correctAnswer' => $correctAnswer,
            'marks' => intval($question['marks'])
        ];
    } 
    elseif ($type === 'MSQ') {
        if (!isset($question['options']) || !is_array($question['options']) || count($question['options']) !== 4) {
            continue;
        }
        if (!isset($question['correctAnswer']) || !is_array($question['correctAnswer'])) {
            continue;
        }
        
        $correctAnswers = array_map('intval', $question['correctAnswer']);
        $valid = true;
        foreach ($correctAnswers as $ans) {
            if ($ans < 0 || $ans > 3) {
                $valid = false;
                break;
            }
        }
        
        if (!$valid || count($correctAnswers) < 2) {
            continue;
        }

        $validatedQuestions[] = [
            'type' => 'MSQ',
            'question' => trim($question['question']),
            'options' => array_map('trim', $question['options']),
            'correctAnswer' => $correctAnswers,
            'marks' => intval($question['marks'])
        ];
    } 
    elseif ($type === 'NAT') {
        if (!isset($question['correctAnswer']) || !is_numeric($question['correctAnswer'])) {
            continue;
        }

        $validatedQuestions[] = [
            'type' => 'NAT',
            'question' => trim($question['question']),
            'correctAnswer' => floatval($question['correctAnswer']),
            'marks' => intval($question['marks'])
        ];
    }
}

if (count($validatedQuestions) < $questionCount) {
    echo json_encode([
        'success' => false,
        'error' => 'Not enough valid questions generated. Expected ' . $questionCount . ', got ' . count($validatedQuestions)
    ]);
    exit;
}

$finalQuestions = array_slice($validatedQuestions, 0, $questionCount);

$mcqCount = count(array_filter($finalQuestions, fn($q) => $q['type'] === 'MCQ'));
$msqCount = count(array_filter($finalQuestions, fn($q) => $q['type'] === 'MSQ'));
$natCount = count(array_filter($finalQuestions, fn($q) => $q['type'] === 'NAT'));
$totalMarks = array_sum(array_column($finalQuestions, 'marks'));

echo json_encode([
    'success' => true,
    'questions' => $finalQuestions,
    'metadata' => [
        'exam' => 'GATE CS',
        'subject' => $subject,
        'topic' => $topic,
        'difficulty' => $difficulty,
        'totalQuestions' => count($finalQuestions),
        'mcqCount' => $mcqCount,
        'msqCount' => $msqCount,
        'natCount' => $natCount,
        'totalMarks' => $totalMarks
    ]
]);
?>
